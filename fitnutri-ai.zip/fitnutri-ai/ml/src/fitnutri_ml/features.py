"""Feature engineering shared by training and inference (single source of truth)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def build_features(df: pd.DataFrame, nutrients: dict) -> pd.DataFrame:
    """`nutrients` maps canonical names -> columns of df. Only features computable from the available columns are created."""
    X = pd.DataFrame(index=df.index)
    for canon, col in nutrients.items():
        X[canon] = pd.to_numeric(df[col], errors="coerce")
    for c in ("fiber_g", "sugar_g", "sodium_mg"):
        if c in X:
            X[f"{c}_missing"] = X[c].isna().astype(int)
    if "calories" in X:
        kcal = X["calories"].replace(0, np.nan)
        for canon, mult, name in (("protein_g", 4, "protein_kcal_pct"), ("fat_g", 9, "fat_kcal_pct"), ("carbs_g", 4, "carb_kcal_pct")):
            if canon in X:
                X[name] = (X[canon] * mult / kcal).clip(0, 1.5)
    if "carbs_g" in X:
        carbs = X["carbs_g"].replace(0, np.nan)
        for canon, name in (("fiber_g", "fiber_to_carb"), ("sugar_g", "sugar_to_carb")):
            if canon in X:
                X[name] = (X[canon] / carbs).clip(0, 1)
    if "sodium_mg" in X:
        X["log_sodium"] = np.log1p(X["sodium_mg"].clip(lower=0))
    return X


def align(X: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    """Reorders/creates columns so inference input matches the training feature list (missing -> NaN -> imputed)."""
    out = X.copy()
    for f in features:
        if f not in out:
            out[f] = np.nan
    return out[features]
