"""Evaluation figures (Matplotlib/Seaborn)."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


def make_plots(out: Path, results: dict, cm, names, importance, history, serve):
    out.mkdir(parents=True, exist_ok=True)
    order = sorted(results, key=lambda n: -results[n]["test"]["macro_f1"])
    fig, ax = plt.subplots(figsize=(9, 4.5))
    x = np.arange(len(order)); w = 0.38
    ax.bar(x - w / 2, [results[n]["test"]["accuracy"] for n in order], w, label="Accuracy")
    ax.bar(x + w / 2, [results[n]["test"]["macro_f1"] for n in order], w, label="Macro-F1")
    ax.set_xticks(x); ax.set_xticklabels(order, rotation=35, ha="right"); ax.set_ylim(0, 1); ax.set_title("Model comparison (test set)"); ax.legend()
    plt.tight_layout(); plt.savefig(out / "model_comparison.png", dpi=150); plt.close()
    cmn = np.array(cm, dtype=float); cmn = cmn / np.maximum(cmn.sum(1, keepdims=True), 1)
    plt.figure(figsize=(8, 6.5)); sns.heatmap(cmn, annot=len(names) <= 6, fmt=".2f", cmap="Blues", xticklabels=names, yticklabels=names)
    plt.title(f"Normalised confusion matrix - {serve} (test)"); plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.tight_layout()
    plt.savefig(out / "confusion_matrix.png", dpi=150); plt.close()
    if importance:
        items = list(importance["values"].items())[:15][::-1]
        plt.figure(figsize=(7, 5)); plt.barh([k for k, _ in items], [v for _, v in items]); plt.title(f"Feature importance ({importance['model']})")
        plt.tight_layout(); plt.savefig(out / "feature_importance.png", dpi=150); plt.close()
    if history:
        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        for a, k in zip(ax, ("accuracy", "loss")):
            a.plot(history[k], label="train"); a.plot(history["val_" + k], label="validation"); a.set_title(f"ANN {k}"); a.set_xlabel("epoch"); a.legend()
        plt.tight_layout(); plt.savefig(out / "ann_curves.png", dpi=150); plt.close()
