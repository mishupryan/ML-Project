"""Loading saved artifacts and predicting."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from .features import align, build_features

CANON = ["calories", "protein_g", "fat_g", "carbs_g", "fiber_g", "sugar_g", "sodium_mg"]


class Artifacts:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.model = joblib.load(self.path / "model.joblib")
        self.pre = joblib.load(self.path / "preprocessor.joblib")
        self.classes = json.loads((self.path / "label_encoder.json").read_text())["classes"]
        feat = json.loads((self.path / "features.json").read_text())
        self.features = feat["features"]
        self.nutrient_map = feat.get("nutrient_map", {c: c for c in CANON})
        self.metrics = json.loads((self.path / "metrics.json").read_text()) if (self.path / "metrics.json").exists() else {}
        self.metadata = json.loads((self.path / "metadata.json").read_text()) if (self.path / "metadata.json").exists() else {}


def artifacts_exist(path: Path) -> bool:
    return all((Path(path) / f).exists() for f in ("model.joblib", "preprocessor.joblib", "label_encoder.json", "features.json"))


def predict(art: Artifacts, nutrients: dict, top_k: int = 3) -> dict:
    row = {c: nutrients.get(c) for c in art.nutrient_map}
    df = pd.DataFrame([row]).astype(float)
    X = align(build_features(df, {c: c for c in art.nutrient_map}), art.features)
    proba = art.model.predict_proba(art.pre.transform(X))[0]
    order = np.argsort(proba)[::-1][:top_k]
    classes = [art.classes[int(c)] for c in art.model.classes_]
    return {"prediction": classes[int(order[0])], "probabilities": [{"label": classes[int(i)], "probability": round(float(proba[i]), 4)} for i in order],
            "n_missing_inputs": int(sum(v is None for v in row.values()))}
