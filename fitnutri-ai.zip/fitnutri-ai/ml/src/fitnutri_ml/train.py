"""Training pipeline: leakage-safe grouped/stratified split, preprocessing fitted on train only, model comparison, artifact saving.

Usage:
    python -m fitnutri_ml.train --csv ../data/healthy_foods_database.csv --target food_type --task food_category --out ../ml/models
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import RandomizedSearchCV, StratifiedGroupKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils.class_weight import compute_class_weight, compute_sample_weight

from . import __version__
from .data import detect_columns, load_csv, validate_and_clean
from .features import build_features

try:
    from xgboost import XGBClassifier
except Exception:  # optional dependency
    XGBClassifier = None
try:
    import tensorflow as tf
except Exception:  # optional dependency
    tf = None

SEED = 42


def _metrics(y_true, proba) -> dict:
    y_pred = proba.argmax(1)
    present = np.unique(y_true)
    m = {"accuracy": accuracy_score(y_true, y_pred), "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
         "macro_precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
         "macro_recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
         "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0), "weighted_f1": f1_score(y_true, y_pred, average="weighted", zero_division=0)}
    try:   # one-vs-rest AUC only over classes that are present in y_true and not everywhere
        aucs = []
        for c in present:
            pos = (y_true == c)
            if 0 < pos.sum() < len(pos):
                aucs.append(roc_auc_score(pos, proba[:, c]))
        m["roc_auc_macro_ovr"] = float(np.mean(aucs)) if aucs else None
    except Exception:
        m["roc_auc_macro_ovr"] = None
    return {k: (None if v is None else round(float(v), 4)) for k, v in m.items()}


def _make_ann(n_in: int, n_cls: int, seed: int):
    tf.keras.utils.set_random_seed(seed)
    m = tf.keras.Sequential([tf.keras.layers.Input(shape=(n_in,)), tf.keras.layers.Dense(128, activation="relu"), tf.keras.layers.BatchNormalization(),
                             tf.keras.layers.Dropout(0.3), tf.keras.layers.Dense(64, activation="relu"), tf.keras.layers.BatchNormalization(),
                             tf.keras.layers.Dropout(0.2), tf.keras.layers.Dense(n_cls, activation="softmax")])
    m.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return m


class _AnnWrapper:
    """Minimal predict_proba wrapper so the ANN is evaluated exactly like the sklearn models."""
    def __init__(self, model, n_cls):
        self.model, self.classes_ = model, np.arange(n_cls)

    def predict_proba(self, X):
        return self.model.predict(X, verbose=0)


def train_task(df: pd.DataFrame, target: str, task: str, out_dir: Path, *, fast: bool = False, tune: bool = False, seed: int = SEED,
               min_class_count: int = 3, group_col: str | None = "auto", reports_dir: Path | None = None, log=print) -> dict:
    out_dir = Path(out_dir) / task
    out_dir.mkdir(parents=True, exist_ok=True)
    det = detect_columns(df)
    nutrients = det["nutrients"]
    if target not in df.columns:
        raise ValueError(f"target column '{target}' not found. Candidates: {det['candidate_targets']}")
    if not nutrients:
        raise ValueError("no nutrient columns detected")
    if target in nutrients.values():
        raise ValueError("target is itself a nutrient column")
    df, quality = validate_and_clean(df, nutrients)
    for w in quality["warnings"]:
        log("WARNING:", w)
    df = df.dropna(subset=[target]).reset_index(drop=True)
    df[target] = df[target].astype(str)
    counts = df[target].value_counts()
    rare = counts[counts < min_class_count].index.tolist()
    if rare:
        quality["warnings"].append(f"Classes with fewer than {min_class_count} samples were excluded from training: {rare}")
        df = df[~df[target].isin(rare)].reset_index(drop=True)
    names = sorted(df[target].unique())
    y_all = df[target].map({n: i for i, n in enumerate(names)}).values
    gcol = det["name_col"] if group_col == "auto" else group_col
    groups = df[gcol].astype(str).str.lower().values if gcol and gcol in df.columns else np.arange(len(df))
    X_all = build_features(df, nutrients)
    features = list(X_all.columns)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        tr_idx, te_idx = next(StratifiedGroupKFold(5, shuffle=True, random_state=seed).split(X_all, y_all, groups))
        fit_rel, va_rel = next(StratifiedGroupKFold(6, shuffle=True, random_state=seed).split(X_all.iloc[tr_idx], y_all[tr_idx], groups[tr_idx]))
    fit_idx, va_idx = tr_idx[fit_rel], tr_idx[va_rel]
    # classes must exist in the fit split (XGBoost/ANN need contiguous labels); rows of unseen classes are reported, not hidden
    present = np.unique(y_all[fit_idx])
    remap = {int(c): i for i, c in enumerate(present)}
    names_fit = [names[c] for c in present]
    dropped = {}

    def keep(idx, nm):
        k = np.array([int(y_all[i]) in remap for i in idx])
        if (~k).any():
            dropped[nm] = int((~k).sum())
        return idx[k]
    va_idx, te_idx = keep(va_idx, "validation"), keep(te_idx, "test")
    if dropped:
        quality["warnings"].append(f"Rows whose class is absent from the training split were set aside (unseen categories): {dropped}")
    y = np.array([remap.get(int(v), -1) for v in y_all])
    K = len(present)

    pre = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]).fit(X_all.iloc[fit_idx])   # fit on TRAIN only
    T = lambda idx: pre.transform(X_all.iloc[idx])
    Xf, Xv, Xt = T(fit_idx), T(va_idx), T(te_idx)
    yf, yv, yt = y[fit_idx], y[va_idx], y[te_idx]
    sw = compute_sample_weight("balanced", yf)
    cw = dict(zip(range(K), compute_class_weight("balanced", classes=np.arange(K), y=yf)))
    baseline = float((yt == np.bincount(yf).argmax()).mean())
    log(f"[{task}] target={target} classes={K} train/val/test = {len(fit_idx)}/{len(va_idx)}/{len(te_idx)}  majority-baseline acc={baseline:.3f}")

    n_trees = 60 if fast else 200
    models: dict = {
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=14, class_weight="balanced", random_state=seed),
        "KNN": KNeighborsClassifier(n_neighbors=15, weights="distance"),
        "SVM": SVC(C=5, gamma="scale", probability=True, class_weight="balanced", random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=n_trees, min_samples_leaf=2, class_weight="balanced_subsample", random_state=seed, n_jobs=-1),
    }
    if XGBClassifier is not None:
        models["XGBoost"] = XGBClassifier(n_estimators=60 if fast else 250, max_depth=6, learning_rate=0.08, subsample=0.9, colsample_bytree=0.9,
                                          objective="multi:softprob", eval_metric="mlogloss", random_state=seed, n_jobs=-1)
    else:
        log("XGBoost not installed - skipped")
    if tune:
        cv = list(StratifiedGroupKFold(3, shuffle=True, random_state=seed).split(Xf, yf, groups[fit_idx]))
        spaces = {"Random Forest": {"n_estimators": [100, 200, 300], "max_depth": [None, 12, 20], "min_samples_leaf": [1, 2, 4], "max_features": ["sqrt", 0.5]},
                  "XGBoost": {"max_depth": [4, 6, 8], "learning_rate": [0.05, 0.1, 0.2], "n_estimators": [150, 250], "subsample": [0.8, 1.0]}}
        for name, space in spaces.items():
            if name in models:
                t0 = time.time()
                rs = RandomizedSearchCV(models[name], space, n_iter=2 if fast else 6, cv=cv, scoring="f1_macro", random_state=seed, n_jobs=1)
                rs.fit(Xf, yf, **({"sample_weight": sw} if name == "XGBoost" else {}))
                models[name] = rs.best_estimator_
                quality.setdefault("tuning", {})[name] = {"best_params": {k: v for k, v in rs.best_params_.items()}, "cv_macro_f1": round(float(rs.best_score_), 4),
                                                         "seconds": round(time.time() - t0, 1)}
                log(f"  tuned {name}: {rs.best_params_} cv macro-F1={rs.best_score_:.3f}")

    results, fitted, history = {}, {}, None
    for name, mdl in models.items():
        t0 = time.time()
        try:
            mdl.fit(Xf, yf, sample_weight=sw) if name == "XGBoost" else mdl.fit(Xf, yf)
        except Exception as e:
            log(f"  {name} failed: {e}"); continue
        secs = time.time() - t0
        fitted[name] = mdl
        pv, pt = mdl.predict_proba(Xv), mdl.predict_proba(Xt)
        results[name] = {"validation": _metrics(yv, pv), "test": _metrics(yt, pt), "train_seconds": round(secs, 1), "framework": "sklearn"}
        log(f"  {name:20s} val macro-F1={results[name]['validation']['macro_f1']:.3f}  test acc={results[name]['test']['accuracy']:.3f} macro-F1={results[name]['test']['macro_f1']:.3f} ({secs:.1f}s)")
    ann_saved = False
    if tf is not None:
        try:
            t0 = time.time()
            ann = _make_ann(Xf.shape[1], K, seed)
            cb = [tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
                  tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4, min_lr=1e-5)]
            h = ann.fit(Xf, yf, validation_data=(Xv, yv), epochs=5 if fast else 100, batch_size=64, class_weight=cw, callbacks=cb, verbose=0)
            history = {k: [float(x) for x in v] for k, v in h.history.items()}
            w = _AnnWrapper(ann, K)
            secs = time.time() - t0
            pv, pt = w.predict_proba(Xv), w.predict_proba(Xt)
            results["ANN"] = {"validation": _metrics(yv, pv), "test": _metrics(yt, pt), "train_seconds": round(secs, 1), "framework": "keras", "epochs_run": len(history["loss"])}
            fitted["ANN"] = w
            ann.save(out_dir / "ann.keras"); ann_saved = True
            log(f"  {'ANN':20s} val macro-F1={results['ANN']['validation']['macro_f1']:.3f}  test acc={results['ANN']['test']['accuracy']:.3f} macro-F1={results['ANN']['test']['macro_f1']:.3f} ({secs:.1f}s)")
        except Exception as e:
            log(f"  ANN failed: {e}")
    else:
        log("TensorFlow not installed - ANN skipped")

    best = max(results, key=lambda n: results[n]["validation"]["macro_f1"])               # selection uses VALIDATION macro-F1, never the test set
    serve = max((n for n in results if results[n]["framework"] == "sklearn"), key=lambda n: results[n]["validation"]["macro_f1"])
    log(f"  best overall (validation macro-F1): {best} | serving model (no TensorFlow needed at runtime): {serve}")

    st = fitted[serve]
    pt = st.predict_proba(Xt)
    cm = confusion_matrix(yt, pt.argmax(1), labels=np.arange(K)).tolist()
    rep = classification_report(yt, pt.argmax(1), labels=np.arange(K), target_names=names_fit, output_dict=True, zero_division=0)
    importance = None
    for nm in ("Random Forest", "XGBoost"):
        if nm in fitted and hasattr(fitted[nm], "feature_importances_"):
            importance = {"model": nm, "values": {f: round(float(v), 4) for f, v in sorted(zip(features, fitted[nm].feature_importances_), key=lambda x: -x[1])}}
            break
    meta = {"task": task, "target": target, "version": f"{__version__}-{dt.datetime.now(dt.timezone.utc):%Y%m%d%H%M}", "trained_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "seed": seed, "fast_mode": fast, "tuned": tune, "serving_model": serve, "best_model_by_validation_macro_f1": best, "ann_saved": ann_saved,
            "n_rows_after_cleaning": int(len(df)), "n_train": int(len(fit_idx)), "n_validation": int(len(va_idx)), "n_test": int(len(te_idx)),
            "n_classes": K, "classes": names_fit, "majority_baseline_test_accuracy": round(baseline, 4),
            "libraries": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "tensorflow": getattr(tf, "__version__", None)},
            "data_hash": hashlib.sha1(pd.util.hash_pandas_object(df, index=False).values.tobytes()).hexdigest()[:12]}
    metrics = {"models": results, "serving_model_test_confusion_matrix": cm, "serving_model_test_report": rep, "feature_importance": importance,
               "data_quality": quality, "ann_history": history, "limitations": [
                   "Metrics come from a single grouped train/validation/test split; differences of ~1 percentage point are within sampling error.",
                   "Food records sharing a name were kept in the same partition to avoid leakage between near-duplicates.",
                   "health_score appears to be rule-derived (4 values, ~76% in one class) - high accuracy may reflect recovery of a scoring rule." if task == "health_score" else
                   "The 'Other' category is heterogeneous and very small classes (e.g. Beverages) have unreliable per-class metrics."]}
    joblib.dump(st, out_dir / "model.joblib", compress=3)
    joblib.dump(pre, out_dir / "preprocessor.joblib")
    (out_dir / "label_encoder.json").write_text(json.dumps({"classes": names_fit}, indent=2))
    (out_dir / "features.json").write_text(json.dumps({"features": features, "nutrient_map": {k: k for k in nutrients}, "source_columns": nutrients}, indent=2))
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=2, default=str))
    (out_dir / "metadata.json").write_text(json.dumps(meta, indent=2))
    if reports_dir:
        try:
            from .plots import make_plots
            make_plots(Path(reports_dir) / task, results, cm, names_fit, importance, history, serve)
        except Exception as e:
            log("plots skipped:", e)
    return {"metadata": meta, "metrics": metrics}


def main():
    ap = argparse.ArgumentParser(description="Train FitNutri AI models")
    ap.add_argument("--csv", required=True)
    ap.add_argument("--target", default="food_type")
    ap.add_argument("--task", default="food_category")
    ap.add_argument("--out", default="models")
    ap.add_argument("--reports", default="reports")
    ap.add_argument("--fast", action="store_true")
    ap.add_argument("--tune", action="store_true")
    a = ap.parse_args()
    train_task(load_csv(a.csv), a.target, a.task, Path(a.out), fast=a.fast, tune=a.tune, reports_dir=Path(a.reports))


if __name__ == "__main__":
    main()
