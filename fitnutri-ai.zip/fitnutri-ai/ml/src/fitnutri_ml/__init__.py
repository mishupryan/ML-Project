"""FitNutri AI machine-learning package: data validation, feature engineering, training, prediction."""
__version__ = "1.0.0"
