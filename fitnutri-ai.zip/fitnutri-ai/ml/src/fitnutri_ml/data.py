"""Dataset loading, column detection and validation. Never assumes a column exists - everything adapts to the real CSV."""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

NUTRIENT_PATTERNS = {
    "calories": ["calories", "kcal", "energy"],
    "protein_g": ["protein"],
    "fat_g": ["fat"],
    "carbs_g": ["carb"],
    "fiber_g": ["fiber", "fibre"],
    "sugar_g": ["sugar"],
    "sodium_mg": ["sodium"],
}


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [re.sub(r"[^0-9a-z]+", "_", str(c).strip().lower()).strip("_") for c in out.columns]
    return out


def _is_text(s: pd.Series) -> bool:
    return s.dtype == object or pd.api.types.is_string_dtype(s)


def detect_columns(df: pd.DataFrame) -> dict:
    """Maps canonical nutrient names to real columns and lists candidate classification targets."""
    cols = list(df.columns)
    nutrients = {}
    for canon, pats in NUTRIENT_PATTERNS.items():
        if canon in cols:
            nutrients[canon] = canon
            continue
        matches = [c for c in cols if any(p in c for p in pats) and pd.api.types.is_numeric_dtype(df[c]) and "sat" not in c]
        if matches:
            nutrients[canon] = sorted(matches, key=len)[0]
    name_col = next((c for c in cols if c.endswith("name")), None)
    used = set(nutrients.values()) | ({name_col} if name_col else set())
    targets = []
    for c in cols:
        if c in used:
            continue
        nun = df[c].nunique(dropna=True)
        if _is_text(df[c]) and 2 <= nun <= 60:
            targets.append(c)
        elif pd.api.types.is_integer_dtype(df[c]) and 2 <= nun <= 10:
            targets.append(c)
        elif pd.api.types.is_float_dtype(df[c]) and 2 <= nun <= 10 and (df[c].dropna() % 1 == 0).all():
            targets.append(c)
    return {"nutrients": nutrients, "name_col": name_col, "candidate_targets": targets}


def load_csv(path: str | Path) -> pd.DataFrame:
    return normalize_columns(pd.read_csv(path))


def validate_and_clean(df: pd.DataFrame, nutrients: dict, per_100g: bool = True, max_removed_warn: float = 0.05) -> tuple[pd.DataFrame, dict]:
    """Removes exact duplicates and physically impossible rows, and REPORTS every removal (nothing is dropped silently)."""
    rep: dict = {"rows_in": int(len(df)), "missing_values": {c: int(df[c].isna().sum()) for c in df.columns if df[c].isna().any()},
                 "warnings": [], "rules": []}
    d = df.copy()
    n0 = len(d)
    d = d.drop_duplicates()
    rep["exact_duplicates_removed"] = int(n0 - len(d))
    ncols = list(nutrients.values())
    neg = int((d[ncols] < 0).any(axis=1).sum()) if ncols else 0
    rep["rows_with_negative_values_clipped_to_zero"] = neg
    d[ncols] = d[ncols].clip(lower=0)
    bad = pd.Series(False, index=d.index)
    if per_100g:
        c = nutrients
        if "calories" in c:
            m = d[c["calories"]] > 900
            rep["rules"].append({"rule": "calories > 900 per 100 g", "rows": int(m.sum())}); bad |= m
        grams = [c[k] for k in ("protein_g", "fat_g", "carbs_g", "fiber_g", "sugar_g") if k in c]
        if grams:
            m = (d[grams] > 100).any(axis=1)
            rep["rules"].append({"rule": "any macronutrient > 100 g per 100 g", "rows": int(m.sum())}); bad |= m
        mac = [c[k] for k in ("protein_g", "fat_g", "carbs_g") if k in c]
        if len(mac) == 3:
            m = d[mac].fillna(0).sum(axis=1) > 110
            rep["rules"].append({"rule": "protein+fat+carbs > 110 g per 100 g", "rows": int(m.sum())}); bad |= m
        if "sugar_g" in c and "carbs_g" in c:
            m = d[c["sugar_g"]] > d[c["carbs_g"]] + 1
            rep["rules"].append({"rule": "sugar > carbs + 1 g", "rows": int(m.sum())}); bad |= m
        if "fiber_g" in c and "carbs_g" in c:
            m = d[c["fiber_g"]] > d[c["carbs_g"]] + 1
            rep["rules"].append({"rule": "fibre > carbs + 1 g", "rows": int(m.sum())}); bad |= m
        if "sodium_mg" in c:
            m = d[c["sodium_mg"]] > 40000
            rep["rules"].append({"rule": "sodium > 40,000 mg per 100 g", "rows": int(m.sum())}); bad |= m
    rep["impossible_rows_removed"] = int(bad.sum())
    d = d[~bad]
    rep["rows_out"] = int(len(d))
    frac = 1 - rep["rows_out"] / max(rep["rows_in"], 1)
    rep["fraction_removed"] = round(frac, 4)
    if frac > max_removed_warn:
        rep["warnings"].append(f"{frac:.1%} of the rows were removed ({rep['exact_duplicates_removed']} duplicates + {rep['impossible_rows_removed']} impossible rows). Inspect the rules above.")
    return d.reset_index(drop=True), rep
