"""Create/upgrade the database schema (Alembic), load foods, and create a clearly-marked DEMO account.

    python scripts/seed_database.py                 # migrate + sample foods + imported dataset + demo account
    python scripts/seed_database.py --no-import     # skip the 8k imported records (faster)
    python scripts/seed_database.py --no-demo       # no demo account

Demo login:  demo@fitnutri.ai / DemoPass123!   (display name "Demo User (sample data)")
The demo diary, weights and workouts are SYNTHETIC sample data generated for screenshots/testing - not real user behaviour."""
import argparse
import datetime as dt
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "ml" / "src"))

from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402

from app.database import SessionLocal  # noqa: E402
from app.models import User, UserProfile, Workout, WorkoutExercise, WeightLog, WaterLog  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.services import diary as dsvc, planner, targets as tsvc  # noqa: E402
from app.services.seed import load_imported_foods, load_sample_foods  # noqa: E402
from app.utils.dates import today_for  # noqa: E402

DEMO_EMAIL, DEMO_PASSWORD = "demo@fitnutri.ai", "DemoPass123!"


def migrate():
    cfg = Config(str(ROOT / "backend" / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "backend" / "alembic"))
    command.upgrade(cfg, "head")


def make_demo(db):
    if db.query(User).filter_by(email=DEMO_EMAIL).first():
        print("demo account already exists")
        return
    u = User(email=DEMO_EMAIL, password_hash=hash_password(DEMO_PASSWORD), display_name="Demo User (sample data)", is_demo=True)
    u.profile = UserProfile(age=26, sex="male", height_cm=176, weight_kg=72, target_weight_kg=78, activity_level="moderate", goal="lean_bulk",
                            diet_preference="vegetarian", allergies=[], liked_foods=["paneer", "dal"], disliked_foods=[], meals_per_day=4, daily_budget=300,
                            workout_days=["mon", "wed", "fri"], workout_time="18:00", water_enabled=True, timezone="Asia/Kolkata")
    db.add(u); db.commit(); db.refresh(u)
    tsvc.recompute_targets(db, u)
    plan = planner.generate_plan(db, u, {"plan_type": "vegetarian_muscle_gain", "days": 7, "name": "Demo vegetarian bulk (sample)"})
    plan.is_saved = True
    today = today_for(u.profile)
    rng = random.Random(7)
    for back in range(1, 11):                       # 10 past days of synthetic logging
        day = today - dt.timedelta(days=back)
        if back in (4, 8):                          # a couple of days with NOTHING logged (shows missing != zero)
            continue
        pd_ = plan.days[back % 7]
        for m in pd_.meals:
            if m.slot == "dinner" and rng.random() < 0.25:
                continue
            for it in m.items:
                dsvc.create_entry(db, u, it.food, log_date=day, meal_type=m.slot, quantity_g=round(it.quantity_g * rng.uniform(0.9, 1.1), 1))
        db.add(WaterLog(user_id=u.id, log_date=day, amount_ml=rng.choice([1500, 2000, 2500])))
    for i, back in enumerate(range(28, -1, -7)):
        db.add(WeightLog(user_id=u.id, log_date=today - dt.timedelta(days=back), weight_kg=round(71.2 + 0.35 * i, 1)))
    for back in (2, 4, 7, 9):
        w = Workout(user_id=u.id, workout_date=today - dt.timedelta(days=back), workout_type="strength", duration_min=60, perceived_exertion=7, notes="sample data")
        w.exercises.append(WorkoutExercise(name="Squat", sets=4, reps=6, weight_kg=60 + 2.5 * (10 - back)))
        w.exercises.append(WorkoutExercise(name="Bench press", sets=4, reps=8, weight_kg=40))
        db.add(w)
    db.commit()
    print(f"demo account created: {DEMO_EMAIL} / {DEMO_PASSWORD}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-import", action="store_true")
    ap.add_argument("--no-demo", action="store_true")
    a = ap.parse_args()
    migrate()
    with SessionLocal() as db:
        print("curated foods added:", load_sample_foods(db))
        if not a.no_import:
            print("imported dataset:", load_imported_foods(db))
        if not a.no_demo:
            make_demo(db)
    print("database ready")
