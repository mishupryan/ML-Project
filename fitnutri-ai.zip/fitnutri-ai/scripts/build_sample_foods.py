"""Generates data/sample_foods.csv - a curated set of GENERIC foods with APPROXIMATE per-100 g values.
All rows are illustrative (typical reference-table magnitudes, e.g. USDA/IFCT-style), NOT lab-verified and NOT branded products.
Prices are illustrative Indian retail estimates per 100 g AS PURCHASED and should be edited by the user."""
import csv, pathlib
H = ["name","category","serving_desc","serving_g","unit_g","unit_name","calories","protein_g","carbs_g","fat_g","sat_fat_g","fiber_g","sugar_g","sodium_mg",
     "diet_class","allergens","cuisine","meal_roles","tags","prep_time_min","price_per_100g","purchase_factor","prep_note"]
BP, MP, SP, BC, SC, LG, VG, FR, FB, DR, SU, SB = ("breakfast_protein","main_protein","snack_protein","breakfast_carb","staple_carb","legume","veg","fruit","fat_boost","drink","supplement","snack_carb")
R = lambda *a: ";".join(a)
rows = [
("Egg, whole, boiled","Eggs & Dairy","1 large egg (50 g)",50,50,"egg",155,12.6,1.1,10.6,3.3,0,1.1,124,"eggetarian","egg","international",R(BP,MP,SP),R("high_protein"),10,14,1.0,"Boil 8-10 minutes, cool in cold water and peel."),
("Egg white, boiled","Eggs & Dairy","1 egg white (33 g)",33,33,"egg white",52,10.9,0.7,0.2,0,0,0.7,166,"eggetarian","egg","international",R(BP,SP),R("high_protein"),10,20,1.0,"Boil whole eggs 8-10 minutes, peel and discard the yolk."),
("Chicken breast, cooked","Meat & Poultry","1 palm-size portion (120 g)",120,None,None,165,31.0,0,3.6,1.0,0,0,74,"non_vegetarian","","international",R(MP),R("high_protein","post_workout"),20,30,1.35,"Marinate with spices, grill or pan-cook until no pink remains and the thickest part reaches 74 C (165 F)."),
("Fish fillet, white, cooked (generic)","Fish & Seafood","1 fillet (120 g)",120,None,None,105,22.8,0,0.9,0.2,0,0,78,"pescatarian","fish","international",R(MP),R("high_protein"),15,40,1.25,"Season and pan-grill or steam 8-10 minutes until it flakes easily."),
("Tuna, canned in water (generic)","Fish & Seafood","1 small can, drained (100 g)",100,None,None,116,25.5,0,0.8,0.2,0,0,247,"pescatarian","fish","international",R(MP,SP,BP),R("high_protein","no_cook"),2,100,1.0,"Drain and mix with lemon, pepper and chopped vegetables."),
("Prawns, cooked","Fish & Seafood","100 g",100,None,None,99,24.0,0.2,0.3,0.1,0,0,111,"pescatarian","shellfish","indian",R(MP),R("high_protein"),12,60,1.25,"Saute with garlic and spices 4-6 minutes until pink and opaque."),
("Paneer","Eggs & Dairy","1 portion (100 g)",100,None,None,265,18.3,1.2,20.8,13.0,0,1.2,18,"vegetarian","milk","indian",R(BP,MP,SP),R("high_protein"),10,35,1.0,"Cube and pan-sear, or crumble into bhurji / add to curry."),
("Tofu, firm","Plant Protein","1 portion (100 g)",100,None,None,144,17.3,2.8,8.7,1.3,2.3,0.6,14,"vegan","soy","international",R(BP,MP,SP),R("high_protein"),12,30,1.0,"Press, cube and pan-sear or crumble into a scramble."),
("Soya chunks, cooked","Plant Protein","1 cup rehydrated (100 g)",100,None,None,120,17.0,11.0,0.2,0.1,4.0,1.0,10,"vegan","soy","indian",R(MP),R("high_protein","budget"),15,15,0.33,"Soak in hot water 10-15 minutes, squeeze dry, then cook in curry or stir-fry."),
("Curd (dahi), plain","Eggs & Dairy","1 katori (150 g)",150,None,None,61,3.5,4.7,3.3,2.1,0,4.7,46,"vegetarian","milk","indian",R(BP,SP),R("no_cook","budget"),2,8,1.0,"Serve chilled; can be flavoured with fruit or roasted cumin."),
("Greek yogurt, plain, low-fat","Eggs & Dairy","1 cup (170 g)",170,None,None,73,10.0,3.9,1.9,1.2,0,3.6,34,"vegetarian","milk","international",R(BP,SP),R("high_protein","no_cook"),2,25,1.0,"Serve with fruit or nuts."),
("Milk, toned","Eggs & Dairy","1 glass (250 g)",250,None,None,58,3.1,4.8,3.0,1.9,0,4.8,43,"vegetarian","milk","indian",R(DR,BP),R("no_cook","budget"),2,5.2,1.0,"Boil and serve warm or chilled."),
("Buttermilk (chaas)","Eggs & Dairy","1 glass (250 g)",250,None,None,40,3.3,4.8,0.9,0.6,0,4.8,105,"vegetarian","milk","indian",R(DR),R("no_cook","budget"),1,3,1.0,"Whisk curd with water and roasted cumin."),
("Whey protein powder (generic, illustrative)","Supplements","1 scoop (30 g)",30,30,"scoop",400,80.0,8.0,6.0,3.0,0,5.0,300,"vegetarian","milk","international",R(SU),R("high_protein","post_workout","no_cook"),2,250,1.0,"Values vary widely by product - check your own label before relying on these numbers."),
("Soy milk, unsweetened","Plant Protein","1 glass (250 g)",250,None,None,33,2.9,1.7,1.6,0.2,0.5,0.4,12,"vegan","soy","international",R(DR,BP),R("no_cook"),2,10,1.0,"Shake and serve chilled."),
("Moong sprouts","Legumes & Pulses","1 bowl (100 g)",100,None,None,30,3.0,5.9,0.2,0,1.8,4.1,6,"vegan","","indian",R(VG,SP,BP),R("no_cook","budget"),3,8,1.0,"Rinse well; eat raw with lemon or steam briefly. Cook thoroughly if immunocompromised."),
("Chickpeas (chana), boiled","Legumes & Pulses","1 katori (100 g)",100,None,None,164,8.9,27.4,2.6,0.3,7.6,4.8,7,"vegan","","indian",R(LG,MP,SP),R("budget"),30,10,0.38,"Soak overnight and pressure-cook until soft."),
("Rajma (kidney beans), boiled","Legumes & Pulses","1 katori (100 g)",100,None,None,127,8.7,22.8,0.5,0.1,6.4,0.3,2,"vegan","","indian",R(LG,MP),R("budget"),35,14,0.38,"Soak overnight and pressure-cook until very soft (undercooked kidney beans are unsafe)."),
("Dal, cooked (generic lentil)","Legumes & Pulses","1 katori (150 g)",150,None,None,116,9.0,20.1,0.4,0.1,7.9,1.8,2,"vegan","","indian",R(LG,MP),R("budget"),25,13,0.3,"Wash, pressure-cook with turmeric and finish with a light tempering."),
("Green peas, boiled","Vegetables","1 katori (80 g)",80,None,None,84,5.4,15.6,0.2,0.1,5.5,5.9,3,"vegan","","indian",R(VG,LG),R("budget"),10,10,1.0,"Boil 5 minutes or steam from frozen."),
("Peanut butter (generic)","Nuts & Seeds","1 tbsp (16 g)",16,16,"tbsp",588,25.0,20.0,50.0,10.0,6.0,9.0,426,"vegan","peanut","international",R(FB),R("no_cook"),1,40,1.0,"Spread on bread or stir into oats. Check label for added sugar and salt."),
("Peanuts, roasted","Nuts & Seeds","1 handful (30 g)",30,None,None,585,23.7,21.5,49.7,6.9,8.0,4.2,6,"vegan","peanut","indian",R(SP,FB),R("no_cook","budget"),0,15,1.0,"Eat plain; unsalted keeps sodium low."),
("Almonds","Nuts & Seeds","1 handful (30 g)",30,None,None,579,21.2,21.6,49.9,3.8,12.5,4.4,1,"vegan","tree_nut","international",R(SP,FB),R("no_cook"),0,80,1.0,"Eat plain or soaked overnight."),
("Roasted chana (dry snack)","Snacks","1 handful (30 g)",30,None,None,364,19.3,60.9,6.0,0.6,17.4,10.7,24,"vegan","","indian",R(SP,SB),R("no_cook","budget","pre_workout"),0,12,1.0,"Eat as is; pairs well with fruit."),
("Rice, white, cooked","Grains","1 katori (150 g)",150,None,None,130,2.7,28.2,0.3,0.1,0.4,0.1,1,"vegan","","indian",R(SC),R("budget"),20,6,0.35,"Rinse and simmer with 2 parts water until tender."),
("Rice, brown, cooked","Grains","1 katori (150 g)",150,None,None,123,2.7,25.6,1.0,0.2,1.6,0.2,4,"vegan","","indian",R(SC),R(),40,8,0.37,"Soak 30 minutes and simmer 35-40 minutes (or pressure-cook)."),
("Roti / chapati (whole wheat)","Grains","1 roti (40 g)",40,40,"roti",297,9.8,49.6,7.5,1.3,5.1,1.5,270,"vegan","gluten","indian",R(SC,BC),R("budget"),15,4.5,0.7,"Knead whole-wheat dough, roll thin and cook on a hot tawa."),
("Oats, rolled, dry","Grains","1 bowl dry (40 g)",40,None,None,379,13.2,67.7,6.5,1.1,10.1,1.0,6,"vegan","gluten","international",R(BC),R(),5,20,1.0,"Cook with milk or water 3-5 minutes. Treated as gluten-containing (cross-contact is common)."),
("Bread, whole wheat","Grains","1 slice (28 g)",28,28,"slice",247,13.0,41.0,3.4,0.7,7.0,6.0,450,"vegan","gluten","international",R(BC),R("no_cook"),2,12,1.0,"Toast if desired. Recipes vary - check your own loaf."),
("Potato, boiled","Vegetables","1 medium (150 g)",150,None,None,87,1.9,20.1,0.1,0,1.8,0.9,4,"vegan","","indian",R(SC),R("budget"),20,3,1.0,"Boil whole with skin until a knife slides in easily."),
("Sweet potato, boiled","Vegetables","1 medium (150 g)",150,None,None,76,1.4,17.7,0.1,0,2.5,5.7,27,"vegan","","indian",R(SC,SB),R("pre_workout"),25,5,1.0,"Boil or roast until soft."),
("Quinoa, cooked","Grains","1 cup (150 g)",150,None,None,120,4.4,21.3,1.9,0.2,2.8,0.9,7,"vegan","","international",R(SC),R(),20,40,0.35,"Rinse, then simmer 1:2 with water for 15 minutes."),
("Pasta, whole wheat, cooked","Grains","1 cup (140 g)",140,None,None,124,5.3,26.5,0.5,0.1,3.9,0.6,4,"vegan","gluten","international",R(SC),R(),15,10,0.4,"Boil in salted water per packet time."),
("Idli, steamed (generic)","Breakfast Items","2 idli (80 g)",80,40,"idli",150,4.5,30.0,0.4,0.1,1.0,0.5,120,"vegan","","indian",R(BC),R(),15,10,1.0,"Homemade values vary; steam fermented batter 10-12 minutes."),
("Banana","Fruits","1 medium (118 g)",118,118,"banana",89,1.1,22.8,0.3,0.1,2.6,12.2,1,"vegan","","indian",R(FR,SB),R("no_cook","pre_workout"),0,6,1.0,"Eat fresh."),
("Apple","Fruits","1 medium (180 g)",180,180,"apple",52,0.3,13.8,0.2,0,2.4,10.4,1,"vegan","","international",R(FR),R("no_cook"),0,15,1.0,"Wash and eat with skin."),
("Orange","Fruits","1 medium (130 g)",130,130,"orange",47,0.9,11.8,0.1,0,2.4,9.4,0,"vegan","","indian",R(FR),R("no_cook"),0,8,1.0,"Peel and eat."),
("Papaya","Fruits","1 bowl (150 g)",150,None,None,43,0.5,10.8,0.3,0.1,1.7,7.8,8,"vegan","","indian",R(FR),R("no_cook","budget"),0,4,1.0,"Cube and eat fresh."),
("Dates, dried","Fruits","3 dates (24 g)",24,8,"date",282,2.5,75.0,0.4,0,8.0,63.0,2,"vegan","","indian",R(SB,FR),R("no_cook","pre_workout"),0,30,1.0,"Eat as is; energy-dense, portion with care."),
("Spinach (palak), cooked","Vegetables","1 katori (100 g)",100,None,None,23,3.0,3.8,0.3,0.1,2.4,0.4,70,"vegan","","indian",R(VG),R("budget"),10,4,1.0,"Wilt in a pan 3-4 minutes with garlic."),
("Broccoli, cooked","Vegetables","1 cup (100 g)",100,None,None,35,2.4,7.2,0.4,0.1,3.3,1.4,41,"vegan","","international",R(VG),R(),10,12,1.0,"Steam or saute 4-5 minutes."),
("Mixed vegetables, cooked (generic)","Vegetables","1 katori (100 g)",100,None,None,60,2.5,11.0,0.5,0.1,3.5,4.0,40,"vegan","","indian",R(VG),R("budget"),15,5,1.0,"Stir-fry or steam seasonal vegetables with light spices."),
("Cauliflower, cooked","Vegetables","1 katori (100 g)",100,None,None,23,1.8,4.1,0.5,0.1,2.3,2.1,15,"vegan","","indian",R(VG),R("budget"),12,4,1.0,"Steam or saute 6-8 minutes."),
("Carrot, raw","Vegetables","1 medium (80 g)",80,None,None,41,0.9,9.6,0.2,0,2.8,4.7,69,"vegan","","indian",R(VG),R("no_cook","budget"),3,5,1.0,"Wash, peel and slice."),
("Cucumber","Vegetables","1 medium (100 g)",100,None,None,15,0.7,3.6,0.1,0,0.5,1.7,2,"vegan","","indian",R(VG),R("no_cook","budget"),2,4,1.0,"Wash and slice."),
("Tomato","Vegetables","1 medium (100 g)",100,None,None,18,0.9,3.9,0.2,0,1.2,2.6,5,"vegan","","indian",R(VG),R("no_cook","budget"),2,4,1.0,"Wash and slice."),
("Ghee","Fats & Oils","1 tsp (5 g)",5,5,"tsp",900,0,0,100.0,62.0,0,0,0,"vegetarian","milk","indian",R(FB),R("no_cook"),0,60,1.0,"Use sparingly; very energy-dense."),
("Olive oil","Fats & Oils","1 tsp (5 g)",5,5,"tsp",884,0,0,100.0,14.0,0,0,2,"vegan","","international",R(FB),R("no_cook"),0,90,1.0,"Use sparingly; very energy-dense."),
]
out = pathlib.Path(__file__).resolve().parent.parent / "data" / "sample_foods.csv"
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(H)
    for r in rows:
        assert len(r) == len(H), (r[0], len(r), len(H))
        w.writerow(["" if v is None else v for v in r])
print("wrote", out, len(rows), "foods")
