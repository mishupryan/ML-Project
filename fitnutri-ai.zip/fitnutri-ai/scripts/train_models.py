"""Train all FitNutri AI models (food-category classifier + health-score classifier).

    python scripts/train_models.py                 # full run (a few minutes on CPU)
    python scripts/train_models.py --fast          # quick smoke test
    python scripts/train_models.py --tune          # adds a small randomized hyper-parameter search
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "ml" / "src"))
from fitnutri_ml.data import detect_columns, load_csv  # noqa: E402
from fitnutri_ml.train import train_task  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default=str(ROOT / "data" / "healthy_foods_database.csv"))
ap.add_argument("--fast", action="store_true")
ap.add_argument("--tune", action="store_true")
a = ap.parse_args()
df = load_csv(a.csv)
info = detect_columns(df)
print("Detected nutrient columns:", info["nutrients"])
print("Candidate targets:", info["candidate_targets"])
for target, task in (("food_type", "food_category"), ("health_score", "health_score")):
    if target not in df.columns:
        print(f"skipping {task}: column '{target}' not in the CSV")
        continue
    train_task(df, target, task, ROOT / "ml" / "models", fast=a.fast, tune=a.tune, reports_dir=ROOT / "ml" / "reports")
print("Done. Artifacts in ml/models, figures in ml/reports.")
