# FitNutri AI

Diet tracker, bodybuilding nutrition planner and ML platform.

* **Backend:** FastAPI + SQLAlchemy + Alembic (PostgreSQL in production, SQLite for local dev)
* **Frontend:** React (Vite). Built into `frontend/dist` and served by the backend, so it deploys as **one container**
* **ML:** scikit-learn / XGBoost models trained on the Healthy Foods dataset (food-category and health-score classifiers)

> Nutrition numbers are estimates, not medical advice. Food values are approximate generic references, and prices are illustrative.

## Deploy

### Option A: Docker Compose (any VPS)

```bash
cp .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(48))"   # paste the output as SECRET_KEY in .env
# also set POSTGRES_PASSWORD in .env
docker compose up -d --build
```

Open `http://<server>:8000`. The first start migrates the database and loads about 8,000 foods (roughly 30 to 60 s). Put a reverse proxy with HTTPS in front (Caddy, nginx, Cloudflare Tunnel, or your host's load balancer); the app already honours `X-Forwarded-*` headers.

### Option B: Render

Push this repo to GitHub, then Render, **New + Blueprint**, select the repo. `render.yaml` creates the PostgreSQL database and the web service, and generates `SECRET_KEY` for you. Free instances have limited memory, so `WEB_CONCURRENCY` is set to 1.

### Option C: Any container host (Railway, Fly.io, Cloud Run, ...)

Build from the `Dockerfile` and set:

| Variable | Required | Notes |
|---|---|---|
| `SECRET_KEY` | yes | 32+ random characters. The app **refuses to start** in production with the default key |
| `DATABASE_URL` | yes | `postgresql://user:pass@host:5432/db` (`postgres://` is accepted too) |
| `PORT` | no | default 8000 (most hosts set this for you) |
| `WEB_CONCURRENCY` | no | worker processes, default 2 |
| `IMPORT_DATASET` | no | `true` (default) loads the 8k imported records; `false` for a faster first boot |
| `SEED_DEMO` | no | `true` creates `demo@fitnutri.ai` with synthetic data. Leave `false` in production |
| `CORS_ORIGINS` | no | only if the frontend is hosted on a different origin |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | no | default 720 |

The container's entrypoint runs `alembic upgrade head` and the (idempotent) seed on every start, then launches the server. Set `RUN_MIGRATIONS=false` if you want to run migrations as a separate release step.

## Local development

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cd .. && python scripts/seed_database.py          # creates backend/fitnutri.db + demo account
cd backend && uvicorn app.main:app --reload        # http://localhost:8000 (API docs at /docs)

# frontend (second terminal)
cd frontend && npm install && npm run dev          # http://localhost:5173, proxies /api to :8000
```

Demo login (local only): `demo@fitnutri.ai` / `DemoPass123!`

Tests: `cd backend && python -m pytest -q` (74 tests).

## Retraining the models

```bash
pip install -r ml/requirements.txt
python scripts/train_models.py        # writes ml/models/* and ml/reports/*
```

`backend/requirements.txt` pins scikit-learn 1.8.0, numpy 2.4.4 and pandas 3.0.2 because those trained the shipped model files. If you retrain with other versions, update the pins to match, otherwise the model files may fail to load or give wrong predictions. The API serves only the scikit-learn / XGBoost model; the TensorFlow ANN (`ann.keras`) is for research and is excluded from the image.

## Operations notes

* **Backups:** back up the PostgreSQL volume (`pgdata`) or use your host's managed backups. Everything the users create lives there.
* **Health check:** `GET /api/health`.
* **Updating:** `git pull && docker compose up -d --build`. New migrations apply automatically on start.
* **Logging out** revokes the token server-side (`revoked_tokens` table). Tokens are stored in the browser's `localStorage`.

## Known limitations

* No rate limiting or account lockout on login. Put the app behind a proxy or WAF that provides it if exposed publicly.
* No email verification or password reset flow.
* The web UI covers diary, foods, meal plans, groceries, progress, workouts, recommendations, weekly report, assistant, ML and profile. **Recipes, custom meals, saved foods and diary meal-duplication exist in the API but have no screens yet** (see `/docs`).
* The chat assistant is rule-based, not a language model.
* Imported dataset records have unverified allergens and diet class; the planner and recommender never use them.
