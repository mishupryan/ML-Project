"""FastAPI application entry point."""
import importlib
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .database import Base, engine
from .errors import register_error_handlers

log = logging.getLogger("fitnutri")
ROUTERS = ["auth", "profile", "nutrition", "foods", "diary", "library", "meal_plans", "recommendations", "recipes", "grocery",
           "progress", "workouts", "water", "reports", "ml", "chat"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    if settings.auto_create_tables:
        Base.metadata.create_all(engine)
    try:
        from .services.ml_service import sync_model_metadata
        sync_model_metadata()
    except Exception as e:  # metadata sync is best-effort
        log.debug("model metadata sync skipped: %s", e)
    yield


def create_app() -> FastAPI:
    settings.validate_for_production()
    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan,
                  description="Diet tracker, bodybuilding nutrition planner and ML platform. Nutrition outputs are estimates, not medical advice.")
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    register_error_handlers(app)
    for name in ROUTERS:
        mod = importlib.import_module(f"app.routers.{name}")
        app.include_router(mod.router)

    @app.get("/api/health", tags=["meta"])
    def health():
        return {"status": "ok", "app": settings.app_name}

    dist = settings.frontend_dist
    if dist.exists() and (dist / "index.html").exists():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

        @app.get("/{full_path:path}", include_in_schema=False)
        def spa(full_path: str):
            if full_path.startswith("api/"):
                from fastapi import HTTPException
                raise HTTPException(404, "Not found")
            f = dist / full_path
            return FileResponse(f if f.is_file() else dist / "index.html")
    return app


app = create_app()
