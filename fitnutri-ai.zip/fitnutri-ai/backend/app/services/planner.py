"""Constraint-based meal planner (not an LLM).

Hard constraints (diet, allergens, lactose/gluten flags, dislikes, no-cook / prep time, cuisine, excluded foods) filter the food pool.
For every meal slot the planner samples compositions (e.g. protein + staple carb + vegetable), solves bounded least-squares for the gram
amounts that best match the slot's calorie/macro target, rounds them to practical portions and picks the best-scoring candidate.
Remaining daily targets are redistributed over the following slots, repeated meals are penalised, and the closest feasible plan is returned
together with an explanation of any target that could not be met."""
from __future__ import annotations

import random
import zlib
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.optimize import lsq_linear
from sqlalchemy.orm import Session

from ..errors import ApiError
from ..models import Food, MealPlan, MealPlanDay, MealPlanItem, MealPlanMeal, User
from ..utils.foodlogic import Constraints, cost_for
from . import context as cx
from . import nutrition_calc as nc
from . import substitutions as subs
from . import targets as tsvc

PLAN_TYPES: dict[str, dict] = {
    "lean_bulk": dict(label="Lean bulk", goal="lean_bulk", desc="Small calorie surplus with high protein to build muscle while limiting fat gain."),
    "muscle_gain": dict(label="General muscle gain", goal="muscle_gain", desc="Moderate surplus with high protein for muscle growth."),
    "fat_loss": dict(label="Fat loss (preserve muscle)", goal="fat_loss", desc="Conservative deficit with high protein and fibre."),
    "recomposition": dict(label="Body recomposition", goal="recomposition", desc="Maintenance calories with high protein."),
    "maintenance": dict(label="Weight maintenance", goal="maintenance", desc="Balanced maintenance-calorie plan."),
    "vegetarian_muscle_gain": dict(label="Vegetarian muscle gain", goal="muscle_gain", diet="vegetarian", desc="Dairy-friendly vegetarian plan for muscle gain."),
    "vegan_high_protein": dict(label="Vegan high-protein", goal=None, diet="vegan", protein_gkg=2.0, desc="Fully plant-based, protein-focused plan."),
    "eggetarian_bodybuilding": dict(label="Eggetarian bodybuilding", goal="muscle_gain", diet="eggetarian", desc="Vegetarian plus eggs."),
    "nonveg_bodybuilding": dict(label="Non-vegetarian bodybuilding", goal="muscle_gain", diet="non_vegetarian", desc="Meat, fish, eggs and dairy allowed."),
    "budget_bodybuilding": dict(label="Budget bodybuilding", goal="muscle_gain", budget=True, desc="Prefers low-cost protein (eggs, dal, soya, curd, milk) and respects a daily budget."),
    "indian_home": dict(label="Indian home-food plan", goal=None, cuisine="indian", desc="Everyday Indian ingredients only."),
    "high_fiber_balanced": dict(label="High-fibre balanced", goal=None, fiber_boost=True, desc="Balanced plan that favours high-fibre foods."),
    "lactose_free": dict(label="Lactose-free", goal=None, lactose_free=True, desc="Excludes milk-containing foods."),
    "gluten_free": dict(label="Gluten-free", goal=None, gluten_free=True, desc="Excludes gluten-containing foods."),
    "student_quick": dict(label="Quick meals for students", goal=None, max_prep=15, desc="Every food takes 15 minutes or less."),
    "no_cook": dict(label="No-cook / low-cooking", goal=None, no_cook=True, desc="Only foods that need no cooking."),
    "custom": dict(label="Custom plan", goal=None, desc="Use your own calories, macros, diet and food lists."),
}

SLOT_SETS = {3: ["breakfast", "lunch", "dinner"], 4: ["breakfast", "lunch", "evening_snack", "dinner"],
             5: ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner"],
             6: ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner", "custom"]}
SLOT_SHARES = {3: [0.30, 0.40, 0.30], 4: [0.27, 0.33, 0.12, 0.28], 5: [0.25, 0.10, 0.30, 0.10, 0.25], 6: [0.22, 0.10, 0.27, 0.10, 0.23, 0.08]}
TEMPLATES = {
    "breakfast": [("breakfast_protein", 1.0), ("breakfast_carb", 1.0), ("fruit", 0.5), ("drink", 0.25), ("fat_boost", 0.2)],
    "mid_morning_snack": [("snack_protein", 1.0), ("fruit", 0.6)],
    "lunch": [("main_protein", 1.0), ("staple_carb", 1.0), ("veg", 1.0), ("legume", 0.5), ("fat_boost", 0.2)],
    "evening_snack": [("snack_protein", 1.0), ("snack_carb", 0.5), ("fruit", 0.4)],
    "dinner": [("main_protein", 1.0), ("staple_carb", 0.9), ("veg", 1.0), ("legume", 0.4), ("fat_boost", 0.15)],
    "custom": [("snack_protein", 1.0), ("fruit", 0.5)],
}
ROLE_BOUNDS = {"breakfast_protein": (60, 250), "main_protein": (80, 250), "snack_protein": (25, 200), "breakfast_carb": (30, 200),
               "staple_carb": (80, 350), "veg": (80, 250), "fruit": (80, 200), "legume": (80, 200), "fat_boost": (5, 30), "drink": (150, 300),
               "snack_carb": (20, 120)}
POOL_ALIASES = {"snack_protein": ["snack_protein", "supplement"]}
MACRO_W = np.array([1.2, 1.5, 0.8, 0.6])
CHOICES = 48


@dataclass
class PlanContext:
    cons: Constraints
    targets: dict
    slots: list
    shares: list
    budget: Optional[float] = None
    budget_mode: bool = False
    fiber_boost: bool = False
    liked: list = field(default_factory=list)
    seed: int = 0
    pools: dict = field(default_factory=dict)


def _dict_targets(r) -> dict:
    return {"calories": r.calories, "protein_g": r.protein_g, "carbs_g": r.carbs_g, "fat_g": r.fat_g, "fiber_g": r.fiber_g}


def _vec(food: Food):
    return np.array([food.calories or 0, food.protein_g or 0, food.carbs_g or 0, food.fat_g or 0]) / 100.0


def build_pools(foods: list[Food]) -> dict[str, list[Food]]:
    pools: dict[str, list[Food]] = {}
    for role in ROLE_BOUNDS:
        names = POOL_ALIASES.get(role, [role])
        pools[role] = [f for f in foods if set(f.meal_roles or []) & set(names)]
    return pools


def _bounds(food: Food, role: str):
    lo, hi = ROLE_BOUNDS[role]
    if food.unit_g:
        lo = max(lo, food.unit_g) if role != "fat_boost" else food.unit_g
        hi = max(lo, min(hi, food.unit_g * 8))
    return float(lo), float(max(hi, lo))


def _meal_prep(prep_times) -> int:
    ts = [t or 0 for t in prep_times]
    return int(round(max(ts) + 0.3 * (sum(ts) - max(ts)))) if ts else 0


def _choose(rng: random.Random, pool: list[Food], role: str, ctx: PlanContext, uses: dict, taken: set) -> Optional[Food]:
    cand = [f for f in pool if f.id not in taken]
    if not cand:
        return None
    ws = []
    for f in cand:
        w = 1.0
        if cx.liked_match(f, ctx.liked):
            w *= 1.8
        if role.endswith("protein"):
            w *= 1 + (f.protein_g or 0) / max(f.calories, 1) * 10
        if ctx.budget_mode:
            w *= 1 / (0.3 + (cost_for(f, 100) or 20) / 20)
        w /= 1 + 0.7 * uses.get(f.id, 0)
        ws.append(w)
    return rng.choices(cand, weights=ws, k=1)[0]


def _slot_candidates(slot: str, slot_target: dict, ctx: PlanContext, rng: random.Random, uses: dict, used_combos: set, last_same_slot,
                     n: int = CHOICES) -> list[dict]:
    template = TEMPLATES[slot]
    b = np.array([slot_target["calories"], slot_target["protein_g"], slot_target["carbs_g"], slot_target["fat_g"]], dtype=float)
    scale = MACRO_W / np.maximum(b, 1.0)
    out, seen = [], set()
    idx = ctx.slots.index(slot) if slot in ctx.slots else 0
    slot_budget = ctx.budget * ctx.shares[idx] if ctx.budget else None
    for _ in range(n):
        chosen: list[tuple[str, Food]] = []
        taken: set = set()
        for k, (role, p) in enumerate(template):
            if not ctx.pools.get(role):
                continue
            prob = p
            if role == "legume" and ctx.cons.diet in ("vegan", "vegetarian", "eggetarian"):
                prob = min(1.0, p + 0.35)
            if role == "fat_boost" and slot_target["fat_g"] < 8:
                continue
            if k > 0 and rng.random() > prob:
                continue
            f = _choose(rng, ctx.pools[role], role, ctx, uses, taken)
            if f:
                chosen.append((role, f)); taken.add(f.id)
        if not chosen or not any(r.endswith("protein") for r, _ in chosen):
            continue
        key = frozenset(f.id for _, f in chosen)
        if key in seen or key in used_combos:
            continue
        seen.add(key)
        A = np.stack([_vec(f) for _, f in chosen], axis=1)
        lbub = [_bounds(f, r) for r, f in chosen]
        lb, ub = np.array([x[0] for x in lbub]), np.array([x[1] for x in lbub])
        ub = np.maximum(ub, lb + 1e-3)               # lsq_linear needs lb < ub strictly
        sol = lsq_linear(A * scale[:, None], b * scale, bounds=(lb, ub), method="bvls")
        grams = [cx.round_qty(f, float(g)) for (_, f), g in zip(chosen, sol.x)]
        grams = [g if f.unit_g else min(max(g, lo), hi) for g, (lo, hi), (_, f) in zip(grams, lbub, chosen)]
        tot = sum(_vec(f) * g for (_, f), g in zip(chosen, grams))
        err = float(np.sum(MACRO_W * np.abs(tot - b) / np.maximum(b, 1.0)) / MACRO_W.sum())
        cost = sum(cost_for(f, g) or 0 for (_, f), g in zip(chosen, grams))
        pen = sum(0.06 * uses.get(f.id, 0) for _, f in chosen) + (0.12 if key == last_same_slot else 0)
        pen -= 0.03 * sum(1 for _, f in chosen if cx.liked_match(f, ctx.liked))
        if slot_budget and cost > slot_budget:
            pen += 0.5 * (cost - slot_budget) / slot_budget
        if ctx.budget_mode:
            pen += 0.002 * cost
        if ctx.fiber_boost:
            pen -= 0.003 * sum((f.fiber_g or 0) * g / 100 for (_, f), g in zip(chosen, grams))
        out.append({"items": [(r, f, g) for (r, f), g in zip(chosen, grams)], "err": err, "score": err + pen, "cost": cost, "key": key,
                    "totals": tot.tolist(), "prep": _meal_prep([f.prep_time_min for _, f in chosen])})
    out.sort(key=lambda c: c["score"])
    return out


def _instructions(items) -> str:
    steps = []
    for i, (role, f, g) in enumerate(items, 1):
        note = f.prep_note or ("No preparation needed." if "no_cook" in (f.tags or []) else "Prepare as usual.")
        steps.append(f"{i}. {f.name} - {cx.display_qty(f, g)}: {note}")
    steps.append("Plate everything together; adjust salt, spices and cooking oil to taste and log what you actually eat.")
    return "\n".join(steps)


def _rationale(slot, items, tot, slot_target, cost, ctx: PlanContext) -> str:
    p_pct = 100 * tot[1] / max(slot_target["protein_g"], 1)
    parts = [f"Provides {tot[1]:.0f} g protein ({p_pct:.0f}% of this meal's {slot_target['protein_g']:.0f} g target) and {tot[0]:.0f} kcal "
             f"(target {slot_target['calories']:.0f})."]
    parts.append(f"Fits your {ctx.cons.diet.replace('_', '-')} diet" + (f", avoids {', '.join(sorted(ctx.cons.allergies))}" if ctx.cons.allergies else "") + ".")
    liked = [f.name for _, f, _ in items if cx.liked_match(f, ctx.liked)]
    if liked:
        parts.append("Includes foods you like: " + ", ".join(liked) + ".")
    parts.append(f"Estimated prep ~{_meal_prep([f.prep_time_min for _, f, _ in items])} min; approx. cost INR {cost:.0f} (illustrative prices).")
    return " ".join(parts)


def _meal_name(items) -> str:
    names = [f.name.split(",")[0].split("(")[0].strip() for _, f, _ in items[:3]]
    return " + ".join(names)[:120]


def _sub_options(db, user, ctx, items, limit=2) -> list[dict]:
    res = []
    for role, f, g in items:
        opts = subs.substitute(db, user, f, g, limit=limit, cons=ctx.cons)
        res.append({"for_food_id": f.id, "for_food": f.name, "options": [{"food_id": o["food"]["id"], "name": o["food"]["name"], "display_qty": o["display_qty"],
                                                                      "quantity_g": o["quantity_g"], "caveat": o["caveat"]} for o in opts]})
    return res


def _persist_meal(db, day_row, slot, order, cand, slot_target, ctx, user) -> MealPlanMeal:
    items = cand["items"]
    m = MealPlanMeal(day_id=day_row.id, slot=slot, sort_order=order, name=_meal_name(items), instructions=_instructions(items), prep_time_min=cand["prep"],
                     rationale=_rationale(slot, items, cand["totals"], slot_target, cand["cost"], ctx), substitutions=_sub_options(db, user, ctx, items))
    for role, f, g in items:
        m.items.append(MealPlanItem(food_id=f.id, quantity_g=g, role=role))
    return m


def build_context(db: Session, user: User, req: dict) -> tuple[PlanContext, dict]:
    p = user.profile
    reasons = nc.is_restricted(p)
    if reasons:
        raise ApiError(409, "plan_not_available", "Meal-plan generation is disabled for your profile. " + " ".join(reasons))
    ptype = req.get("plan_type", "muscle_gain")
    if ptype not in PLAN_TYPES:
        raise ApiError(422, "invalid_plan_type", f"plan_type must be one of {list(PLAN_TYPES)}")
    spec = PLAN_TYPES[ptype]
    manual = {k: req.get(k) for k in ("calories", "protein_g", "carbs_g", "fat_g")}
    if manual["calories"] and manual["protein_g"]:
        cal, pr = float(manual["calories"]), float(manual["protein_g"])
        fat = float(manual["fat_g"] or cal * 0.25 / 9)
        carbs = float(manual["carbs_g"] or max((cal - pr * 4 - fat * 9) / 4, 50))
        targets = {"calories": cal, "protein_g": pr, "carbs_g": carbs, "fat_g": fat, "fiber_g": max(25, 14 * cal / 1000)}
    else:
        if not tsvc.profile_ready(p):
            raise ApiError(422, "profile_incomplete", "Add age, height and weight to your profile (or pass calories and protein_g) to generate a plan.")
        goal = spec.get("goal")
        stored = tsvc.get_targets(db, user)
        if goal is None and spec.get("protein_gkg") is None and stored:
            targets = {"calories": stored.calories, "protein_g": stored.protein_g, "carbs_g": stored.carbs_g, "fat_g": stored.fat_g, "fiber_g": stored.fiber_g}
        else:
            targets = _dict_targets(tsvc.estimate_for_profile(p, goal_override=goal, protein_g_per_kg=spec.get("protein_gkg")))
    if spec.get("fiber_boost"):
        targets["fiber_g"] = round(targets["fiber_g"] * 1.3)
    over = {}
    if spec.get("diet"):
        over["diet"] = spec["diet"]
    if req.get("diet"):
        over["diet"] = req["diet"]
    if spec.get("lactose_free"):
        over["lactose_free"] = True
    if spec.get("gluten_free"):
        over["gluten_free"] = True
    if spec.get("cuisine"):
        over["cuisine_only"] = spec["cuisine"]
    if spec.get("max_prep"):
        over["max_prep_min"] = spec["max_prep"]
    if spec.get("no_cook"):
        over["require_no_cook"] = True
    if p.cooking_time_pref_min and "max_prep_min" not in over and ptype != "custom":
        over["max_prep_min"] = max(p.cooking_time_pref_min, 20)
    over["strict"] = True
    cons = Constraints.from_profile(p, **over)
    foods = cx.candidate_foods(db, user, cons, require_roles=True)
    excl = [e.strip().lower() for e in (req.get("exclude_foods") or []) if e.strip()]
    if excl:
        foods = [f for f in foods if not any(e in f.name.lower() for e in excl)]
    inc = [e.strip().lower() for e in (req.get("include_only") or []) if e.strip()]
    if inc:
        foods = [f for f in foods if any(e in f.name.lower() for e in inc)]
    n = min(max(int(req.get("meals_per_day") or p.meals_per_day or 4), 3), 6)
    budget = req.get("daily_budget_inr") or (p.daily_budget if (spec.get("budget") or p.daily_budget) else None)
    if spec.get("budget") and not budget:
        budget = 250.0
    seed = req.get("seed")
    if seed is None:
        seed = zlib.crc32(f"{user.id}|{ptype}|{req.get('days', 1)}|{round(targets['calories'])}|{n}".encode())
    ctx = PlanContext(cons=cons, targets=targets, slots=SLOT_SETS[n], shares=SLOT_SHARES[n], budget=budget, budget_mode=bool(spec.get("budget")),
                      fiber_boost=bool(spec.get("fiber_boost")), liked=p.liked_foods or [], seed=int(seed), pools=build_pools(foods))
    info = {"plan_type": ptype, "spec": spec, "foods_available": len(foods), "meals_per_day": n}
    return ctx, info


def active_constraints(ctx: PlanContext, spec: dict) -> list[str]:
    c = ctx.cons
    out = [f"diet: {c.diet.replace('_', '-')}"]
    if c.allergies:
        out.append("allergies: " + ", ".join(sorted(c.allergies)))
    if c.lactose_free:
        out.append("lactose-free")
    if c.gluten_free:
        out.append("gluten-free")
    if c.disliked:
        out.append("dislikes: " + ", ".join(c.disliked))
    if c.max_prep_min:
        out.append(f"max {c.max_prep_min} min preparation per food")
    if c.require_no_cook:
        out.append("no-cook foods only")
    if c.cuisine_only:
        out.append(f"{c.cuisine_only} cuisine only")
    if ctx.budget:
        out.append(f"budget INR {ctx.budget:.0f}/day")
    return out


def generate_plan(db: Session, user: User, req: dict) -> MealPlan:
    ctx, info = build_context(db, user, req)
    days = int(req.get("days", 1))
    if not 1 <= days <= 7:
        raise ApiError(422, "invalid_days", "days must be between 1 and 7.")
    spec = info["spec"]
    warnings: list[str] = []
    if not any(ctx.pools.get(r) for r in ("main_protein", "breakfast_protein", "snack_protein")):
        raise ApiError(422, "no_foods_available", "No foods satisfy your diet, allergy and preference constraints, so no plan can be built.",
                       {"active_constraints": active_constraints(ctx, spec)})
    for role, label in (("main_protein", "lunch/dinner proteins"), ("staple_carb", "staple carbohydrates"), ("veg", "vegetables")):
        if not ctx.pools.get(role):
            warnings.append(f"No {label} are available under your constraints; those parts of the meals are skipped.")
    rng = random.Random(ctx.seed)
    uses: dict[int, int] = {}
    used_combos: dict[str, set] = {s: set() for s in ctx.slots}
    last_same: dict[str, frozenset] = {}
    plan = MealPlan(user_id=user.id, name=req.get("name") or f"{spec['label']} - {days}-day plan", plan_type=info["plan_type"], num_days=days,
                    meals_per_day=info["meals_per_day"], calories=round(ctx.targets["calories"]), protein_g=round(ctx.targets["protein_g"]),
                    carbs_g=round(ctx.targets["carbs_g"]), fat_g=round(ctx.targets["fat_g"]), fiber_g=round(ctx.targets["fiber_g"]),
                    params={"request": {k: v for k, v in req.items() if v is not None}, "seed": ctx.seed, "regen": 0,
                            "targets": ctx.targets, "budget": ctx.budget, "constraints": active_constraints(ctx, spec)})
    db.add(plan); db.flush()
    total_cost = 0.0
    tgt = np.array([ctx.targets["calories"], ctx.targets["protein_g"], ctx.targets["carbs_g"], ctx.targets["fat_g"]])
    for d in range(days):
        day = MealPlanDay(plan_id=plan.id, day_index=d)
        db.add(day); db.flush()
        consumed = np.zeros(4)
        day_cost = 0.0
        for si, slot in enumerate(ctx.slots):
            rem_shares = sum(ctx.shares[si:])
            slot_vec = np.maximum(tgt - consumed, 0) * ctx.shares[si] / rem_shares
            slot_target = dict(zip(("calories", "protein_g", "carbs_g", "fat_g"), map(float, slot_vec)))
            cands = _slot_candidates(slot, slot_target, ctx, rng, uses, used_combos[slot], last_same.get(slot, frozenset()))
            if not cands:
                warnings.append(f"Day {d + 1}: could not build a {slot.replace('_', ' ')} from the allowed foods (constraints too tight).")
                continue
            cand = cands[0]
            db.add(_persist_meal(db, day, slot, si, cand, slot_target, ctx, user))
            consumed += np.array(cand["totals"])
            day_cost += cand["cost"]
            used_combos[slot].add(cand["key"]); last_same[slot] = cand["key"]
            for _, f, _ in cand["items"]:
                uses[f.id] = uses.get(f.id, 0) + 1
        total_cost += day_cost
        for label, idx, key in (("calories", 0, "calories"), ("protein", 1, "protein_g"), ("fat", 3, "fat_g")):
            tv = ctx.targets[key]
            if tv and abs(consumed[idx] - tv) / tv > 0.10:
                warnings.append(f"Day {d + 1}: {label} is {consumed[idx]:.0f} vs target {tv:.0f} ({100 * (consumed[idx] - tv) / tv:+.0f}%). "
                                "Closest feasible plan returned; limiting constraints: " + "; ".join(active_constraints(ctx, spec)) +
                                ". Try relaxing one of them or editing the target.")
        if ctx.budget and day_cost > ctx.budget * 1.05:
            warnings.append(f"Day {d + 1}: estimated cost INR {day_cost:.0f} exceeds your budget of INR {ctx.budget:.0f} (illustrative prices).")
    plan.total_cost_inr = round(total_cost, 2)
    plan.warnings = list(dict.fromkeys(warnings))[:30]
    db.commit(); db.refresh(plan)
    return plan


def plan_dict(plan: MealPlan, detail: bool = True) -> dict:
    t = {"calories": plan.calories, "protein_g": plan.protein_g, "carbs_g": plan.carbs_g, "fat_g": plan.fat_g, "fiber_g": plan.fiber_g}
    base = {"id": plan.id, "name": plan.name, "plan_type": plan.plan_type, "plan_label": PLAN_TYPES.get(plan.plan_type, {}).get("label", plan.plan_type),
            "num_days": plan.num_days, "meals_per_day": plan.meals_per_day, "targets": t, "total_cost_inr": plan.total_cost_inr, "is_saved": plan.is_saved,
            "created_at": plan.created_at.isoformat(), "warnings": plan.warnings or [], "constraints_applied": (plan.params or {}).get("constraints", [])}
    if not detail:
        return base
    days = []
    for d in plan.days:
        dtot = {"calories": 0.0, "protein_g": 0.0, "carbs_g": 0.0, "fat_g": 0.0, "fiber_g": 0.0}
        dcost, meals = 0.0, []
        for m in d.meals:
            mt = {"calories": 0.0, "protein_g": 0.0, "carbs_g": 0.0, "fat_g": 0.0, "fiber_g": 0.0}
            mcost, items, miss = 0.0, [], set()
            for it in m.items:
                n = cx.nutrient_summary(it.food, it.quantity_g)
                c = cost_for(it.food, it.quantity_g)
                for k in mt:
                    mt[k] += n[k] or 0
                mcost += c or 0
                miss |= set(n["missing"])
                items.append({"id": it.id, "food_id": it.food_id, "food_name": it.food.name, "role": it.role, "quantity_g": it.quantity_g,
                              "display_qty": cx.display_qty(it.food, it.quantity_g), "nutrients": n, "cost_inr": c})
            for k in dtot:
                dtot[k] += mt[k]
            dcost += mcost
            meals.append({"id": m.id, "slot": m.slot, "name": m.name, "items": items, "totals": {k: round(v, 1) for k, v in mt.items()},
                          "cost_inr": round(mcost, 1), "prep_time_min": m.prep_time_min, "instructions": m.instructions, "rationale": m.rationale,
                          "substitutions": m.substitutions or [], "missing_data": sorted(miss)})
        days.append({"day_index": d.day_index, "totals": {k: round(v, 1) for k, v in dtot.items()}, "cost_inr": round(dcost, 1),
                     "fit_pct": {k: round(100 * dtot[k] / t[k]) if t.get(k) else None for k in dtot}, "meals": meals})
    base["days"] = days
    base["disclaimer"] = "Generated by a rule-based constraint planner from approximate generic food data; not medical advice. Adjust to your needs and log what you actually eat."
    return base


def _rebuild(db: Session, user: User, plan: MealPlan) -> tuple[PlanContext, dict]:
    req = dict((plan.params or {}).get("request", {}))
    req["seed"] = (plan.params or {}).get("seed")
    ctx, info = build_context(db, user, req)
    ctx.targets = (plan.params or {}).get("targets", ctx.targets)
    return ctx, info


def _slot_target(plan: MealPlan, slot: str, ctx: PlanContext) -> dict:
    n = plan.meals_per_day
    share = dict(zip(SLOT_SETS[n], SLOT_SHARES[n])).get(slot, 0.15)
    t = ctx.targets
    return {"calories": t["calories"] * share, "protein_g": t["protein_g"] * share, "carbs_g": t["carbs_g"] * share, "fat_g": t["fat_g"] * share}


def alternatives(db: Session, user: User, plan: MealPlan, meal: MealPlanMeal, count: int = 3) -> list[dict]:
    ctx, _ = _rebuild(db, user, plan)
    slot_target = _slot_target(plan, meal.slot, ctx)
    regen = (plan.params or {}).get("regen", 0) + 1
    rng = random.Random(ctx.seed * 7919 + regen * 104729 + meal.id)
    current = frozenset(i.food_id for i in meal.items)
    cands = _slot_candidates(meal.slot, slot_target, ctx, rng, {}, {current}, frozenset(), n=90)
    out, seen_main = [], set()
    for c in cands:
        mains = frozenset(f.id for r, f, g in c["items"] if r.endswith("protein"))
        if mains in seen_main:
            continue
        seen_main.add(mains)
        out.append({"name": _meal_name(c["items"]), "prep_time_min": c["prep"], "cost_inr": round(c["cost"], 1),
                    "totals": dict(zip(("calories", "protein_g", "carbs_g", "fat_g"), [round(x, 1) for x in c["totals"]])),
                    "items": [{"food_id": f.id, "food_name": f.name, "quantity_g": g, "display_qty": cx.display_qty(f, g), "role": r} for r, f, g in c["items"]],
                    "rationale": _rationale(meal.slot, c["items"], c["totals"], slot_target, c["cost"], ctx), "slot_target": {k: round(v) for k, v in slot_target.items()}})
        if len(out) >= count:
            break
    return out


def apply_meal_items(db: Session, user: User, plan: MealPlan, meal: MealPlanMeal, items: list[dict]):
    """Replace a meal's contents (used by 'regenerate / use this alternative'). Items are re-validated against the user's constraints."""
    ctx, _ = _rebuild(db, user, plan)
    new_items = []
    for it in items:
        f = db.get(Food, it["food_id"])
        if not f:
            raise ApiError(404, "food_not_found", "Food not found.")
        ok, why = ctx.cons.check(f)
        if not ok:
            raise ApiError(422, "constraint_violation", f"{f.name} conflicts with your constraints: {', '.join(why)}.")
        new_items.append((it.get("role") or (f.meal_roles or ["custom"])[0], f, float(it["quantity_g"])))
    meal.items.clear(); db.flush()
    for r, f, g in new_items:
        meal.items.append(MealPlanItem(food_id=f.id, quantity_g=g, role=r))
    meal.name = _meal_name(new_items)
    meal.instructions = _instructions(new_items)
    meal.prep_time_min = _meal_prep([f.prep_time_min for _, f, _ in new_items])
    tot = [sum((_vec(f) * g)[i] for _, f, g in new_items) for i in range(4)]
    st = _slot_target(plan, meal.slot, ctx)
    meal.rationale = _rationale(meal.slot, new_items, tot, st, sum(cost_for(f, g) or 0 for _, f, g in new_items), ctx)
    meal.substitutions = _sub_options(db, user, ctx, new_items)
    plan.params = {**(plan.params or {}), "regen": (plan.params or {}).get("regen", 0) + 1}
    db.flush()


def replace_ingredient(db: Session, user: User, plan: MealPlan, item: MealPlanItem, new_food: Food, quantity_g: float | None):
    ctx, _ = _rebuild(db, user, plan)
    ok, why = ctx.cons.check(new_food)
    if not ok:
        raise ApiError(422, "constraint_violation", f"{new_food.name} conflicts with your constraints: {', '.join(why)}.")
    if quantity_g is None:
        ref = (item.food.calories or 0) * item.quantity_g / 100
        quantity_g = cx.round_qty(new_food, ref / max(new_food.calories, 1) * 100)
    old = item.food.name
    item.food_id, item.food, item.quantity_g = new_food.id, new_food, quantity_g
    return {"replaced": old, "with": new_food.name, "quantity_g": quantity_g,
            "note": "Quantity was matched on calories; protein and other nutrients will differ - check the updated meal totals."}


def recompute_cost(plan: MealPlan):
    tot = 0.0
    for d in plan.days:
        for m in d.meals:
            for it in m.items:
                tot += cost_for(it.food, it.quantity_g) or 0
    plan.total_cost_inr = round(tot, 2)
