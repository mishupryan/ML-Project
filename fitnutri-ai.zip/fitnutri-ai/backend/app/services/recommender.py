"""Transparent, rule-based food recommendation engine.

score = sum(weight_i * component_i) * 100, every component in [0, 1] and returned to the caller together with a text explanation.
There is no hidden model: the only 'learning' is a small, visible adjustment from the user's own thumbs-up/down feedback."""
from __future__ import annotations

import datetime as dt
from collections import Counter

from sqlalchemy.orm import Session

from ..models import FoodDiaryEntry, User
from ..utils.dates import tz_for
from ..utils.foodlogic import Constraints, completeness, cost_for, protein_per_100kcal
from . import context as cx

BASE_WEIGHTS = {"fit": 0.50, "preference": 0.15, "price": 0.10, "prep": 0.10, "variety": 0.10, "completeness": 0.05}
CONTEXT_WEIGHTS = {
    "budget": {"fit": 0.40, "preference": 0.10, "price": 0.30, "prep": 0.05, "variety": 0.10, "completeness": 0.05},
    "quick": {"fit": 0.40, "preference": 0.10, "price": 0.05, "prep": 0.30, "variety": 0.10, "completeness": 0.05},
}
CONTEXTS = ["general", "pre_workout", "post_workout", "budget", "quick", "high_fiber", "high_protein"]


def _clip(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def remaining_gap(targets: dict | None, consumed: dict | None) -> dict:
    if not targets:
        return {"calories": 600.0, "protein_g": 30.0, "carbs_g": 60.0, "fat_g": 20.0, "fiber_g": 8.0, "assumed": True}
    c = consumed or {}
    return {k: round(targets[k] - c.get(k, 0), 1) for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")} | {"assumed": False}


def portion_for(food, rem: dict, context: str) -> float:
    rem_kcal = rem["calories"]
    kcal_target = _clip(0.35 * rem_kcal if rem_kcal > 0 else 150, 90, 450)
    kcal100 = max(food.calories or 1, 1)
    g = kcal_target / kcal100 * 100
    lo, hi = 0.5 * food.serving_g, 2.0 * food.serving_g
    return cx.round_qty(food, _clip(g, lo, hi))


def score_food(food, rem: dict, context: str, *, liked: list, fb: dict, recent: Counter, w: dict | None = None) -> dict:
    g = portion_for(food, rem, context)
    n = cx.nutrient_summary(food, g)
    p, kcal, carbs, fat, fiber = (n["protein_g"] or 0), (n["calories"] or 0), (n["carbs_g"] or 0), (n["fat_g"] or 0), (n["fiber_g"] or 0)
    protein_gap = max(rem["protein_g"], 0)
    protein_cov = _clip(p / max(8, min(protein_gap, 35))) if protein_gap > 0 else 0.3
    density = _clip((protein_per_100kcal(food) or 0) / 15)
    rem_kcal = rem["calories"]
    overshoot = _clip((kcal - max(rem_kcal, 0)) / max(rem_kcal, 100)) if rem_kcal > 0 else 1.0
    fiber_cov = _clip(fiber / max(4, min(max(rem["fiber_g"], 0), 10))) if rem["fiber_g"] > 0 else 0.5
    carb_cov = _clip(carbs / max(15, min(max(rem["carbs_g"], 0), 50)))
    if context == "pre_workout":
        fit = 0.5 * carb_cov + 0.25 * (1 - _clip(fat / 10)) + 0.15 * (1 - _clip(fiber / 8)) + 0.10 * (1 - overshoot)
    elif context == "post_workout":
        fit = 0.4 * protein_cov + 0.3 * carb_cov + 0.15 * density + 0.15 * (1 - overshoot)
    elif context == "high_fiber":
        fit = 0.5 * fiber_cov + 0.2 * protein_cov + 0.15 * density + 0.15 * (1 - overshoot)
    else:
        fit = 0.45 * protein_cov + 0.25 * density + 0.15 * fiber_cov + 0.15 * (1 - overshoot)
    is_liked = cx.liked_match(food, liked)
    fbv = fb.get(food.id, 0.0)
    pref = _clip(0.5 + 0.25 * (1 if is_liked else 0) + 0.25 * fbv)
    ppr = cx.protein_per_rupee(food)
    price = 0.5 if ppr is None else _clip(ppr / 3.0)
    prep = 0.5 if food.prep_time_min is None else 1 - _clip(food.prep_time_min / 45)
    variety = 1 - 0.8 * _clip(recent.get(food.id, 0) / 3)
    comp = completeness(food)
    comps = {"fit": fit, "preference": pref, "price": price, "prep": prep, "variety": variety, "completeness": comp}
    weights = w or BASE_WEIGHTS
    score = round(100 * sum(weights[k] * comps[k] for k in weights), 1)
    cost = cost_for(food, g)
    bits = [f"adds {p:.0f} g protein" + (f" ({100 * p / protein_gap:.0f}% of your remaining {protein_gap:.0f} g)" if protein_gap > 0 else ""),
            f"for {kcal:.0f} kcal", f"({protein_per_100kcal(food) or 0:.1f} g protein per 100 kcal)"]
    if fiber >= 3:
        bits.append(f"and {fiber:.0f} g fibre")
    extra = []
    if is_liked:
        extra.append("matches a food you like")
    if fbv > 0.2:
        extra.append("you rated similar suggestions helpful")
    if fbv < -0.2:
        extra.append("ranked lower because you marked it not helpful before")
    if recent.get(food.id, 0) == 0:
        extra.append("adds variety (not eaten in the last 3 days)")
    if cost is not None:
        extra.append(f"about INR {cost:.0f} per portion (illustrative price)")
    if food.prep_time_min is not None:
        extra.append(f"ready in about {food.prep_time_min} min" if food.prep_time_min else "no preparation needed")
    if overshoot > 0.5:
        extra.append("note: this portion is large relative to your remaining calories")
    explanation = (food.name + " " + " ".join(bits) + ". " + "; ".join(extra) + ".").replace("..", ".")
    return {"food": cx.compact_food(food), "quantity_g": g, "display_qty": cx.display_qty(food, g), "nutrients": n, "cost_inr": cost,
            "score": score, "breakdown": {k: round(v, 3) for k, v in comps.items()}, "weights": weights, "explanation": explanation,
            "warnings": [] if completeness(food) == 1 else ["Some nutrient values are missing for this food."]}


def recent_counts(db: Session, user: User, day: dt.date, days: int = 3) -> Counter:
    rows = db.query(FoodDiaryEntry).filter(FoodDiaryEntry.user_id == user.id, FoodDiaryEntry.log_date >= day - dt.timedelta(days=days),
                                           FoodDiaryEntry.log_date <= day, FoodDiaryEntry.food_id.isnot(None)).all()
    return Counter(r.food_id for r in rows)


def recommend(db: Session, user: User, *, rem: dict, day: dt.date, context: str = "general", limit: int = 8, max_prep_min: int | None = None,
              budget_mode: bool = False, category: str | None = None) -> dict:
    p = user.profile
    cons = Constraints.from_profile(p, max_prep_min=max_prep_min)
    foods = cx.candidate_foods(db, user, cons)
    if category:
        foods = [f for f in foods if f.category == category]
    if context == "high_protein":
        foods = [f for f in foods if (protein_per_100kcal(f) or 0) >= 8]
    fb, recent = cx.feedback_prior(db, user), recent_counts(db, user, day)
    wctx = "budget" if (budget_mode or context == "budget") else "quick" if context == "quick" else None
    w = CONTEXT_WEIGHTS.get(wctx) if wctx else None
    ctx = "general" if context in ("budget", "quick", "high_protein") else context
    items = [score_food(f, rem, ctx, liked=p.liked_foods or [], fb=fb, recent=recent, w=w) for f in foods]
    items.sort(key=lambda x: -x["score"])
    notes = ["Scores are a transparent weighted sum (see 'weights' and 'breakdown'); they are not medical advice.",
             "Only foods with verified diet/allergen information are considered; imported unverified records are skipped."]
    if rem.get("assumed"):
        notes.append("No calorie/macro targets are set, so a typical remaining gap (600 kcal, 30 g protein) was assumed.")
    if not items:
        notes.append("No foods match your diet, allergy and preference constraints. Relax a restriction or add custom foods.")
    return {"context": context, "remaining": {k: v for k, v in rem.items() if k != "assumed"}, "method": "rule-based weighted scoring (transparent)",
            "weights": w or BASE_WEIGHTS, "items": items[:limit], "total_candidates": len(items), "notes": notes,
            "ml_note": "A learned ranking model is a future extension; it needs real labelled interaction data. Your thumbs up/down feedback is stored and already nudges the preference score."}


def slot_for_now(p, logged: list[str], now: dt.datetime) -> tuple[str, str]:
    h = now.hour
    order = [("breakfast", 0, 11), ("mid_morning_snack", 10, 12), ("lunch", 12, 16), ("evening_snack", 16, 19), ("dinner", 19, 24)]
    n = p.meals_per_day or 4
    allowed = {3: {"breakfast", "lunch", "dinner"}, 4: {"breakfast", "lunch", "evening_snack", "dinner"}}.get(n, {s for s, _, _ in order})
    for slot, a, b in order:
        if slot in allowed and a <= h < b and slot not in logged:
            return slot, "next planned meal for this time of day"
    for slot, _, _ in order:
        if slot in allowed and slot not in logged:
            return slot, "first meal slot not logged yet"
    return "evening_snack", "all planned meals are logged; here are options if you are still short of your targets"


def next_meal_suggestion(db: Session, user: User, day: dt.date, day_totals: dict, targets: dict | None) -> dict:
    p = user.profile
    logged = [m["meal_type"] for m in day_totals["meals"]]
    now = dt.datetime.now(tz_for(p))
    slot, why = slot_for_now(p, logged, now)
    ctx = "post_workout" if slot == "evening_snack" and p.workout_time and p.workout_time < "19:00" else "general"
    rem = remaining_gap(targets, day_totals["totals"])
    res = recommend(db, user, rem=rem, day=day, context=ctx, limit=3)
    return {"slot": slot, "reason": why, "remaining": res["remaining"],
            "suggestions": [{"name": i["food"]["name"], "display_qty": i["display_qty"], "calories": i["nutrients"]["calories"],
                             "protein_g": i["nutrients"]["protein_g"], "score": i["score"], "explanation": i["explanation"]} for i in res["items"]]}


GOAL_RANK_NOTES = {
    "muscle_gain": "Ranks foods by protein per calorie, absolute protein per 100 g and usefulness as an energy source.",
    "lean_bulk": "Ranks foods by protein per calorie, absolute protein per 100 g and usefulness as an energy source.",
    "fat_loss": "Ranks foods by protein per calorie, low energy density and fibre (for fullness).",
    "general": "Ranks foods by overall nutrient density: protein and fibre up, sugar and sodium down.",
}


def top_foods_for_goal(db: Session, user: User, goal: str, limit: int = 15) -> dict:
    cons = Constraints.from_profile(user.profile)
    foods = cx.candidate_foods(db, user, cons)
    res = []
    for f in foods:
        ppk = _clip((protein_per_100kcal(f) or 0) / 15)
        p100 = _clip((f.protein_g or 0) / 25)
        fib = _clip((f.fiber_g or 0) / 8)
        dens = 1 - _clip(f.calories / 300)
        energy = _clip(f.calories / 400) if f.calories < 600 else 0.5
        if goal in ("muscle_gain", "lean_bulk", "recomposition"):
            s = 0.45 * ppk + 0.30 * p100 + 0.15 * energy + 0.10 * fib
        elif goal == "fat_loss":
            s = 0.40 * ppk + 0.25 * dens + 0.25 * fib + 0.10 * p100
        else:
            s = 0.35 * ppk + 0.25 * fib + 0.20 * (1 - _clip((f.sugar_g or 0) / 25)) + 0.20 * (1 - _clip((f.sodium_mg or 0) / 600))
        res.append({"food": cx.compact_food(f), "score": round(100 * s, 1), "protein_per_100kcal": protein_per_100kcal(f), "protein_per_100g": f.protein_g,
                    "calories_per_100g": f.calories, "fiber_per_100g": f.fiber_g, "price_per_100g_eaten": cost_for(f, 100),
                    "serving_desc": f.serving_desc,
                    "why": f"{f.protein_g or 0:.0f} g protein and {f.calories:.0f} kcal per 100 g ({protein_per_100kcal(f) or 0:.1f} g protein per 100 kcal), {f.fiber_g or 0:.0f} g fibre."})
    res.sort(key=lambda x: -x["score"])
    key = goal if goal in GOAL_RANK_NOTES else "general"
    return {"goal": goal, "method": GOAL_RANK_NOTES[key], "items": res[:limit], "total_candidates": len(res),
            "note": "Respects your diet, allergy and dislike settings. Illustrative generic values - not a prescription."}
