"""Persisting and recomputing a user's nutrition targets."""
from sqlalchemy.orm import Session

from ..errors import ApiError
from ..models import NutritionTarget, User, UserProfile
from . import nutrition_calc as nc


def profile_ready(p: UserProfile | None) -> bool:
    return bool(p and p.age and p.height_cm and p.weight_kg)


def estimate_for_profile(p: UserProfile, goal_override: str | None = None, protein_g_per_kg: float | None = None) -> nc.TargetResult:
    return nc.calculate_targets(age=p.age, sex=p.sex, height_cm=p.height_cm, weight_kg=p.weight_kg, activity_level=p.activity_level,
                                goal=goal_override or p.goal, restricted_reasons=nc.is_restricted(p), protein_g_per_kg=protein_g_per_kg,
                                workout_days_per_week=len(p.workout_days or []))


def get_targets(db: Session, user: User) -> NutritionTarget | None:
    return db.query(NutritionTarget).filter_by(user_id=user.id).first()


def recompute_targets(db: Session, user: User, force: bool = False) -> NutritionTarget | None:
    """Auto targets follow the profile; manual targets are kept unless force=True."""
    p = user.profile
    if not profile_ready(p):
        return get_targets(db, user)
    t = get_targets(db, user)
    if t and t.is_manual and not force:
        return t
    try:
        res = estimate_for_profile(p)
    except ValueError as e:
        raise ApiError(422, "invalid_profile", str(e))
    if t is None:
        t = NutritionTarget(user_id=user.id, calories=0, protein_g=0, carbs_g=0, fat_g=0)
        db.add(t)
    t.calories, t.protein_g, t.carbs_g, t.fat_g, t.fiber_g = res.calories, res.protein_g, res.carbs_g, res.fat_g, res.fiber_g
    t.water_ml = p.water_target_ml or res.water_ml
    t.bmr, t.tdee, t.is_manual = res.bmr, res.tdee, False
    t.notes = " | ".join(res.warnings) or None
    db.commit()
    db.refresh(t)
    return t


def target_dict(t: NutritionTarget | None) -> dict | None:
    if t is None:
        return None
    return {"calories": t.calories, "protein_g": t.protein_g, "carbs_g": t.carbs_g, "fat_g": t.fat_g, "fiber_g": t.fiber_g,
            "water_ml": t.water_ml, "is_manual": t.is_manual, "bmr": t.bmr, "tdee": t.tdee, "notes": t.notes}
