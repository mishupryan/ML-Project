"""Nutrition target estimation (Mifflin-St Jeor BMR -> TDEE -> goal-adjusted calories and macros).

These are *estimates* for a starting point, not clinical prescriptions. Calorie changes are deliberately conservative."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

ACTIVITY_MULTIPLIERS = {"sedentary": 1.2, "light": 1.375, "moderate": 1.55, "very_active": 1.725, "extra_active": 1.9}
GOALS = {
    # goal: (calorie adjustment as fraction of TDEE, protein g/kg, label)
    "muscle_gain": (0.10, 1.8, "Muscle gain"),
    "lean_bulk": (0.07, 1.8, "Lean bulking"),
    "fat_loss": (-0.15, 2.0, "Fat loss"),
    "recomposition": (0.0, 2.0, "Body recomposition"),
    "maintenance": (0.0, 1.4, "Weight maintenance"),
    "general_fitness": (0.0, 1.2, "General fitness"),
    "improve_protein": (0.0, 1.6, "Improve protein intake"),
    "healthy_habits": (0.0, 1.2, "Build healthier eating habits"),
}
MAX_SURPLUS, MAX_DEFICIT = 0.15, -0.20       # hard safety caps (fraction of TDEE)
MAX_PROTEIN_G_PER_KG = 2.2
FAT_FRACTION = 0.25
MIN_CAL = {"male": 1500, "female": 1200, "other": 1350}

LIMITATIONS = [
    "BMR/TDEE equations are population averages and can be off by 10-20% for an individual; treat targets as a starting point and adjust using your weight trend.",
    "Protein suggestions follow commonly cited sports-nutrition ranges (about 1.2-2.2 g per kg body weight per day); they are not medical advice.",
    "Not suitable for under-18s, pregnancy, eating-disorder history or medical conditions without guidance from a qualified professional.",
]


@dataclass
class TargetResult:
    bmr: float = 0
    tdee: float = 0
    calories: float = 0
    calorie_range: tuple = (0, 0)
    protein_g: float = 0
    carbs_g: float = 0
    fat_g: float = 0
    fiber_g: float = 0
    water_ml: int = 0
    goal: str = "maintenance"
    restricted: bool = False
    warnings: list = field(default_factory=list)
    limitations: list = field(default_factory=lambda: list(LIMITATIONS))
    method: str = "Mifflin-St Jeor"

    def to_dict(self):
        return asdict(self)


def mifflin_st_jeor(sex: str, weight_kg: float, height_cm: float, age: int) -> float:
    """BMR in kcal/day. 'other' uses the midpoint of the male (+5) and female (-161) constants."""
    const = {"male": 5, "female": -161}.get((sex or "other").lower(), -78)
    return 10 * weight_kg + 6.25 * height_cm - 5 * age + const


def is_restricted(profile) -> list[str]:
    reasons = []
    if profile is None:
        return reasons
    if profile.age is not None and profile.age < 18:
        reasons.append("Users under 18 should not follow bodybuilding or weight-manipulation diets; please speak with a doctor or registered dietitian.")
    if profile.medical_or_pregnancy_flag:
        reasons.append("Pregnancy or a relevant medical condition was flagged; please get personalised advice from a qualified professional.")
    if profile.eating_disorder_concern:
        reasons.append("An eating-disorder concern was flagged; calorie-target and weight-change plans are disabled. Please seek professional support.")
    return reasons


def calculate_targets(*, age, sex, height_cm, weight_kg, activity_level="moderate", goal="maintenance",
                      workout_days_per_week: int | None = None, restricted_reasons: list[str] | None = None,
                      protein_g_per_kg: float | None = None) -> TargetResult:
    if None in (age, height_cm, weight_kg):
        raise ValueError("age, height_cm and weight_kg are required to estimate targets")
    if not (10 <= age <= 100 and 100 <= height_cm <= 250 and 25 <= weight_kg <= 400):
        raise ValueError("age, height or weight is outside the supported range")
    sex = (sex or "other").lower()
    activity = activity_level if activity_level in ACTIVITY_MULTIPLIERS else "moderate"
    if workout_days_per_week is not None and activity_level not in ACTIVITY_MULTIPLIERS:
        activity = "sedentary" if workout_days_per_week <= 1 else "light" if workout_days_per_week <= 3 else "moderate" if workout_days_per_week <= 5 else "very_active"
    goal = goal if goal in GOALS else "maintenance"
    res = TargetResult(goal=goal)
    reasons = restricted_reasons or []
    if reasons:
        res.restricted = True
        res.warnings.extend(reasons)
        goal = "maintenance"                      # never push weight change for restricted users
        res.goal = "maintenance"
    adj, pgkg, _ = GOALS[goal]
    adj = max(MAX_DEFICIT, min(MAX_SURPLUS, adj))
    bmr = mifflin_st_jeor(sex, weight_kg, height_cm, age)
    tdee = bmr * ACTIVITY_MULTIPLIERS[activity]
    cal = tdee * (1 + adj)
    floor = max(bmr, MIN_CAL.get(sex, 1350))
    if adj < 0 and cal < floor:
        cal = floor
        res.warnings.append("Calories were raised to a safe minimum (never below your estimated BMR).")
    pgkg = min(protein_g_per_kg or pgkg, MAX_PROTEIN_G_PER_KG)
    protein = pgkg * weight_kg
    fat = max(FAT_FRACTION * cal / 9, 0.6 * weight_kg)
    carbs = max((cal - protein * 4 - fat * 9) / 4, 50)
    if protein * 4 + fat * 9 + carbs * 4 > cal * 1.05:   # carbs floor pushed us over; trim protein toward a sane share
        protein = max((cal - fat * 9 - carbs * 4) / 4, 0.8 * weight_kg)
    res.bmr, res.tdee, res.calories = round(bmr), round(tdee), round(cal)
    res.calorie_range = (round(cal * 0.95), round(cal * 1.05))
    res.protein_g, res.fat_g, res.carbs_g = round(protein), round(fat), round(carbs)
    res.fiber_g = round(max(25, 14 * cal / 1000))
    res.water_ml = int(round(weight_kg * 35 / 50) * 50)
    return res
