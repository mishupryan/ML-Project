"""Food diary logic: creating entries with nutrient snapshots, totals and daily summaries."""
from __future__ import annotations

import datetime as dt
from collections import defaultdict

from sqlalchemy.orm import Session

from ..errors import ApiError
from ..models import Food, FoodDiaryEntry, User
from ..schemas.food import MEAL_ORDER
from ..utils.foodlogic import cost_for, scale_nutrients

TOTAL_KEYS = ["calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg"]


def visible_food(db: Session, user: User, food_id: int) -> Food:
    f = db.get(Food, food_id)
    if not f or (f.owner_user_id is not None and f.owner_user_id != user.id):
        raise ApiError(404, "food_not_found", "Food not found.")
    return f


def fill_entry_from_food(entry: FoodDiaryEntry, food: Food):
    n = scale_nutrients(food, entry.quantity_g)
    entry.calories, entry.protein_g, entry.carbs_g, entry.fat_g = n["calories"] or 0, n["protein_g"] or 0, n["carbs_g"] or 0, n["fat_g"] or 0
    entry.fiber_g, entry.sugar_g, entry.sodium_mg = n["fiber_g"], n["sugar_g"], n["sodium_mg"]
    entry.missing_nutrients = n["missing"]
    entry.cost_inr = cost_for(food, entry.quantity_g)


def create_entry(db: Session, user: User, food: Food, *, log_date, meal_type, quantity_g=None, servings=None, notes=None) -> FoodDiaryEntry:
    if quantity_g is None:
        quantity_g = round(servings * food.serving_g, 2)
    e = FoodDiaryEntry(user_id=user.id, food_id=food.id, label=food.name, log_date=log_date, meal_type=meal_type,
                       quantity_g=quantity_g, servings=servings, notes=notes)
    fill_entry_from_food(e, food)
    db.add(e)
    return e


def entry_dict(e: FoodDiaryEntry) -> dict:
    return {"id": e.id, "food_id": e.food_id, "recipe_id": e.recipe_id, "label": e.label, "log_date": e.log_date.isoformat(),
            "meal_type": e.meal_type, "quantity_g": e.quantity_g, "servings": e.servings, "calories": round(e.calories, 1),
            "protein_g": round(e.protein_g, 1), "carbs_g": round(e.carbs_g, 1), "fat_g": round(e.fat_g, 1),
            "fiber_g": None if e.fiber_g is None else round(e.fiber_g, 1), "sugar_g": None if e.sugar_g is None else round(e.sugar_g, 1),
            "sodium_mg": None if e.sodium_mg is None else round(e.sodium_mg, 1), "cost_inr": e.cost_inr,
            "missing_nutrients": e.missing_nutrients or [], "notes": e.notes}


def totals(entries) -> dict:
    t = {k: 0.0 for k in TOTAL_KEYS}
    incomplete = defaultdict(int)
    for e in entries:
        for k in TOTAL_KEYS:
            v = getattr(e, k)
            if v is None:
                incomplete[k] += 1
            else:
                t[k] += v
    t = {k: round(v, 1) for k, v in t.items()}
    t["incomplete_entries"] = dict(incomplete)
    return t


def entries_between(db: Session, user_id: int, start: dt.date, end: dt.date):
    return (db.query(FoodDiaryEntry).filter(FoodDiaryEntry.user_id == user_id, FoodDiaryEntry.log_date >= start, FoodDiaryEntry.log_date <= end)
            .order_by(FoodDiaryEntry.log_date, FoodDiaryEntry.id).all())


def by_day(entries) -> dict:
    d = defaultdict(list)
    for e in entries:
        d[e.log_date].append(e)
    return d


def build_day(db: Session, user: User, day: dt.date) -> dict:
    ents = entries_between(db, user.id, day, day)
    meals = defaultdict(list)
    for e in ents:
        meals[e.meal_type].append(e)
    ordered = [m for m in MEAL_ORDER if m in meals] + [m for m in meals if m not in MEAL_ORDER]
    return {"date": day.isoformat(), "totals": totals(ents), "entries_count": len(ents),
            "meals": [{"meal_type": m, "totals": totals(meals[m]), "entries": [entry_dict(e) for e in meals[m]]} for m in ordered]}
