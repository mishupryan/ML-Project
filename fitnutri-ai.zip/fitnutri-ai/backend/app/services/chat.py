"""Rule-based nutrition assistant. All numbers come from application functions (never from free-text generation),
every suggested food is validated against the database and the user's allergy/diet constraints, and safety topics are not negotiable."""
from __future__ import annotations

import re

from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..errors import ApiError
from ..models import Food, User
from ..services import context as cx
from ..services import diary as dsvc
from ..services import planner, recommender as rec, reports as rpt, substitutions as subs, targets as tsvc
from ..utils.dates import today_for
from ..utils.foodlogic import Constraints, cost_for, protein_per_100kcal

SAFETY_WORDS = ["starve", "starving", "crash diet", "steroid", "anabolic", "laxative", "purge", "vomit", "pro-ana", "fast for 3", "lose 10 kg in a week",
                "lose 10kg in a week", "dehydrate", "water cut"]
DISCLAIMER = "Rule-based assistant using your profile, food log and the food database. Estimates only - not medical advice."
HELP = ("I can help with things like:\n- \"What can I eat to reach my protein target today?\"\n- \"Suggest a vegetarian muscle-gain meal\"\n- \"Give me three inexpensive high-protein dinner options\"\n"
        "- \"Replace eggs in my breakfast\"\n- \"Create a meal plan using rice, dal, paneer and vegetables\"\n- \"Compare paneer and tofu\"\n- \"Why am I missing my fiber target?\"\n- \"What should I eat before / after a workout?\"")


def find_food(db: Session, user: User, text: str) -> Food | None:
    text = text.strip(" .?!,'\"").lower()
    toks = [t for t in re.split(r"[^a-z]+", text) if len(t) > 1 and t not in {"the", "my", "some", "of", "a", "an"}]
    if not toks:
        return None
    stems = [t.rstrip("s") if len(t) > 3 else t for t in toks]
    best, score = None, 1e9
    q = db.query(Food).filter(or_(Food.owner_user_id.is_(None), Food.owner_user_id == user.id))
    pool = q.filter(Food.data_confidence.in_(["curated-approximate", "user-custom"])).all() + q.filter(Food.data_confidence == "imported-unverified", Food.name.ilike(f"%{stems[0]}%")).limit(50).all()
    for f in pool:
        n = f.name.lower()
        if all(s in n for s in stems):
            sc = len(n) + (0 if f.data_confidence != "imported-unverified" else 100)
            if sc < score:
                best, score = f, sc
    return best


def _fmt(n, unit="", nd=0):
    return "-" if n is None else f"{n:.{nd}f}{unit}"


def respond(db: Session, user: User, message: str) -> dict:
    m = message.lower().strip()
    p = user.profile
    day = today_for(p)
    base = {"source": "rule-based assistant", "disclaimer": DISCLAIMER}
    if any(w in m for w in SAFETY_WORDS):
        return {**base, "intent": "safety", "reply": "I can't help with extreme or unsafe approaches (starving, crash diets, dehydration/water cutting, laxatives, purging or steroid use). "
                "Sustainable progress comes from modest calorie changes, enough protein, sleep and training. If you are struggling with food or body image, please talk to a doctor, "
                "a registered dietitian or a trusted person; in India you can also contact a local mental-health helpline."}
    mt = re.search(r"compare\s+(.+?)\s+(?:and|vs\.?|versus|with|to)\s+(.+)", m) or re.search(r"^(.+?)\s+vs\.?\s+(.+)$", m)
    if mt:
        a, b = find_food(db, user, mt.group(1)), find_food(db, user, mt.group(2))
        if not a or not b:
            return {**base, "intent": "compare", "reply": "I couldn't find both foods in the database. Try the exact names from Food Search."}
        rows = [{"nutrient": k, a.name: getattr(a, k), b.name: getattr(b, k)} for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")]
        rows.append({"nutrient": "protein per 100 kcal", a.name: protein_per_100kcal(a), b.name: protein_per_100kcal(b)})
        txt = f"Per 100 g - {a.name}: {a.calories:.0f} kcal, {_fmt(a.protein_g,' g protein')}, {_fmt(a.carbs_g,' g carbs')}, {_fmt(a.fat_g,' g fat')}.\n" \
              f"{b.name}: {b.calories:.0f} kcal, {_fmt(b.protein_g,' g protein')}, {_fmt(b.carbs_g,' g carbs')}, {_fmt(b.fat_g,' g fat')}.\n"
        pa, pb = protein_per_100kcal(a) or 0, protein_per_100kcal(b) or 0
        txt += f"{(a if pa >= pb else b).name} gives more protein per calorie ({max(pa, pb):.1f} vs {min(pa, pb):.1f} g per 100 kcal). Values are approximate; the foods also differ in micronutrients and taste."
        return {**base, "intent": "compare", "reply": txt, "data": {"table": rows}}
    mt = re.search(r"(?:meal\s*plan|plan|menu|meals?).*?\b(?:using|with|from)\b\s+(.+)", m)
    if mt and ("plan" in m or "create" in m or "make" in m):
        raw = re.split(r",|\band\b|&", mt.group(1))
        names = [re.sub(r"[^a-z ]", "", x).strip() for x in raw if x.strip()]
        names = [n.rstrip("s") if len(n) > 4 else n for n in names if n]
        try:
            plan = planner.generate_plan(db, user, {"plan_type": "custom", "days": 1, "include_only": names, "name": "Plan from my ingredients"})
        except ApiError as e:
            return {**base, "intent": "ingredient_plan", "reply": f"I couldn't build that plan: {e.message}"}
        d = planner.plan_dict(plan)
        lines = [f"Here is a one-day plan using only: {', '.join(names)} (saved as plan #{plan.id})."]
        for mm in d["days"][0]["meals"]:
            lines.append(f"- {mm['slot'].replace('_', ' ').title()}: " + ", ".join(i["display_qty"] + " " + i["food_name"] for i in mm["items"]) + f" ({mm['totals']['calories']:.0f} kcal, {mm['totals']['protein_g']:.0f} g protein)")
        t = d["days"][0]["totals"]
        lines.append(f"Day total: {t['calories']:.0f} kcal, {t['protein_g']:.0f} g protein vs target {d['targets']['calories']:.0f} kcal / {d['targets']['protein_g']:.0f} g.")
        if d["warnings"]:
            lines.append("Note: " + d["warnings"][0])
        return {**base, "intent": "ingredient_plan", "reply": "\n".join(lines), "data": {"plan_id": plan.id}}
    mt = re.search(r"\b(vegetarian|vegan|eggetarian)\b.*\b(muscle|bulk|gain|bodybuild)", m)
    if mt:
        key = {"vegetarian": "vegetarian_muscle_gain", "vegan": "vegan_high_protein", "eggetarian": "eggetarian_bodybuilding"}[mt.group(1)]
        try:
            plan = planner.generate_plan(db, user, {"plan_type": key, "days": 1})
        except ApiError as e:
            return {**base, "intent": "plan_meal", "reply": f"I couldn't build that plan: {e.message}"}
        d = planner.plan_dict(plan)
        meal = next((x for x in d["days"][0]["meals"] if x["slot"] == "lunch"), d["days"][0]["meals"][0])
        txt = (f"Try this {mt.group(1)} {meal['slot'].replace('_', ' ')}: " + ", ".join(i["display_qty"] + " " + i["food_name"] for i in meal["items"]) +
               f". It gives about {meal['totals']['calories']:.0f} kcal and {meal['totals']['protein_g']:.0f} g protein. {meal['rationale']}  (Full day saved as plan #{plan.id}.)")
        return {**base, "intent": "plan_meal", "reply": txt, "data": {"plan_id": plan.id}}
    if re.search(r"(cheap|inexpensive|budget|low[- ]cost|affordable)", m) and re.search(r"(protein|dinner|lunch|meal)", m):
        cons = Constraints.from_profile(p)
        foods = [f for f in cx.candidate_foods(db, user, cons) if "main_protein" in (f.meal_roles or []) and cx.protein_per_rupee(f)]
        foods.sort(key=lambda f: -cx.protein_per_rupee(f))
        if not foods:
            return {**base, "intent": "budget", "reply": "No priced protein foods match your diet and allergy settings."}
        lines = ["Most protein per rupee among foods that fit your diet (illustrative prices):"]
        for f in foods[:3]:
            g = cx.round_qty(f, f.serving_g)
            lines.append(f"- {f.name}: {cx.display_qty(f, g)} = {cx.nutrient_summary(f, g)['protein_g']:.0f} g protein for about INR {cost_for(f, g):.0f}")
        lines.append("Pair with a staple (rice/roti) and vegetables for a full dinner. Generate a Budget bodybuilding plan in the Meal Planner for complete meals.")
        return {**base, "intent": "budget", "reply": "\n".join(lines)}
    mt = re.search(r"(?:replace|substitute|swap|alternative (?:to|for)|instead of|can't eat|cannot eat|without)\s+(.+?)(?:\s+(?:in|with|from|for)\b.*)?$", m)
    if mt:
        f = find_food(db, user, mt.group(1))
        if not f:
            return {**base, "intent": "substitute", "reply": "I couldn't find that food. Try the name as it appears in Food Search."}
        g = cx.round_qty(f, f.serving_g)
        opts = subs.substitute(db, user, f, g, limit=3)
        if not opts:
            return {**base, "intent": "substitute", "reply": f"No compatible replacement for {f.name} was found under your diet and allergy settings."}
        n0 = cx.nutrient_summary(f, g)
        lines = [f"Instead of {cx.display_qty(f, g)} {f.name} ({n0['calories']:.0f} kcal, {n0['protein_g']:.0f} g protein) you could use:"]
        for o in opts:
            lines.append(f"- {o['display_qty']} {o['food']['name']} ({o['nutrients']['calories']:.0f} kcal, {o['nutrients']['protein_g']:.0f} g protein). {o['caveat']}")
        return {**base, "intent": "substitute", "reply": "\n".join(lines)}
    if re.search(r"fib(er|re)", m) and re.search(r"(miss|low|why|short|not enough|reach|increase)", m):
        r = rpt.weekly_report(db, user, day)
        a, t = r["averages_logged_days"]["fiber_g"], (r["targets"] or {}).get("fiber_g")
        if a is None:
            return {**base, "intent": "fiber", "reply": "I can't tell yet - no food has been logged in the last 7 days."}
        recs = rec.recommend(db, user, rem=rec.remaining_gap(r["targets"], None), day=day, context="high_fiber", limit=3)
        txt = f"On the {r['days_logged']} day(s) you logged this week your average fibre was {a:.0f} g" + (f" vs a target of about {t:.0f} g." if t else ".")
        txt += " Fibre totals can look low if some logged foods have no fibre data. High-fibre options that fit your diet: " + "; ".join(f"{i['display_qty']} {i['food']['name']} ({i['nutrients']['fiber_g'] or 0:.0f} g)" for i in recs["items"]) + "."
        return {**base, "intent": "fiber", "reply": txt}
    mt = re.search(r"(pre|post)[- ]?workout|before (?:a |my )?(?:workout|gym|training)|after (?:a |my )?(?:workout|gym|training)", m)
    if mt:
        ctx = "pre_workout" if ((mt.group(1) == "pre") or "before" in m) else "post_workout"
        td = dsvc.build_day(db, user, day)
        res = rec.recommend(db, user, rem=rec.remaining_gap(tsvc.target_dict(tsvc.get_targets(db, user)), td["totals"]), day=day, context=ctx, limit=3)
        txt = f"Flexible {ctx.replace('_', '-')} ideas for you (timing is a guide, not a rule):\n" + "\n".join(f"- {i['display_qty']} {i['food']['name']}: {i['explanation']}" for i in res["items"])
        return {**base, "intent": ctx, "reply": txt}
    if "protein" in m and re.search(r"(reach|target|remaining|need|more|left|hit|goal|eat)", m):
        td = dsvc.build_day(db, user, day)
        t = tsvc.target_dict(tsvc.get_targets(db, user))
        rem = rec.remaining_gap(t, td["totals"])
        if t is None:
            return {**base, "intent": "protein", "reply": "Set your targets first (Profile or Nutrition targets) so I can compute what is left today."}
        if rem["protein_g"] <= 0:
            return {**base, "intent": "protein", "reply": f"You have already logged {td['totals']['protein_g']:.0f} g protein today - your target of {t['protein_g']:.0f} g is met."}
        res = rec.recommend(db, user, rem=rem, day=day, context="high_protein", limit=3)
        txt = f"You've logged {td['totals']['protein_g']:.0f} g of {t['protein_g']:.0f} g protein today ({rem['protein_g']:.0f} g to go, {rem['calories']:.0f} kcal left). Options that fit your diet:\n"
        txt += "\n".join(f"- {i['display_qty']} {i['food']['name']}: {i['explanation']}" for i in res["items"])
        if td["entries_count"] == 0:
            txt = "Note: nothing is logged yet today, so the gap shown is the full target.\n" + txt
        return {**base, "intent": "protein", "reply": txt}
    return {**base, "intent": "help", "reply": "I didn't recognise that request. " + HELP}
