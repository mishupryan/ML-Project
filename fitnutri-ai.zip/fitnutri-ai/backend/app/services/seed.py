"""Loads the curated sample foods and (optionally) the imported Healthy Foods dataset into the database."""
from __future__ import annotations

import datetime as dt
import math
from pathlib import Path

import pandas as pd
from sqlalchemy.orm import Session

from ..config import REPO_DIR
from ..models import Food

SAMPLE_CSV = REPO_DIR / "data" / "sample_foods.csv"
IMPORT_CSV = REPO_DIR / "data" / "healthy_foods_database.csv"
PRICE_DATE = dt.date(2026, 10, 14)


def _nz(v):
    return None if v is None or (isinstance(v, float) and math.isnan(v)) else v


def load_sample_foods(db: Session, path: Path = SAMPLE_CSV) -> int:
    if db.query(Food).filter(Food.data_confidence == "curated-approximate").count():
        return 0
    df = pd.read_csv(path)
    n = 0
    for r in df.to_dict("records"):
        r = {k: _nz(v) for k, v in r.items()}
        split = lambda s: [x for x in str(s or "").split(";") if x]
        db.add(Food(
            name=r["name"], category=r["category"], serving_desc=r["serving_desc"], serving_g=float(r["serving_g"]),
            unit_g=r.get("unit_g"), unit_name=r.get("unit_name"), calories=float(r["calories"]), protein_g=r["protein_g"], carbs_g=r["carbs_g"],
            fat_g=r["fat_g"], sat_fat_g=r.get("sat_fat_g"), fiber_g=r["fiber_g"], sugar_g=r["sugar_g"], sodium_mg=r["sodium_mg"],
            allergens=split(r.get("allergens")), allergen_verified=True, diet_class=r["diet_class"], diet_verified=True,
            cuisine=r.get("cuisine"), meal_roles=split(r.get("meal_roles")), tags=split(r.get("tags")),
            prep_time_min=None if r.get("prep_time_min") is None else int(r["prep_time_min"]), prep_note=r.get("prep_note"),
            price_per_100g=r.get("price_per_100g"), purchase_factor=float(r.get("purchase_factor") or 1.0),
            price_source="illustrative estimate (India retail, as purchased)", price_updated=PRICE_DATE,
            data_source="sample_foods.csv (approximate generic values)", data_confidence="curated-approximate", is_illustrative=True))
        n += 1
    db.commit()
    return n


def load_imported_foods(db: Session, path: Path = IMPORT_CSV) -> dict:
    """Imports the Healthy Foods CSV. Exact duplicates and physically impossible rows are skipped and COUNTED (never silent)."""
    if db.query(Food).filter(Food.data_source == "healthy_foods_database.csv").count():
        return {"skipped": "already imported"}
    df = pd.read_csv(path)
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    rep = {"rows_in": len(df)}
    df = df.dropna(subset=["food_name", "calories"])
    before = len(df); df = df.drop_duplicates(); rep["exact_duplicates_removed"] = before - len(df)
    num = [c for c in ["calories", "protein_g", "fat_g", "carbs_g", "fiber_g", "sugar_g", "sodium_mg"] if c in df.columns]
    df[num] = df[num].clip(lower=0)
    bad = (df.calories > 900) | (df[[c for c in ["protein_g", "fat_g", "carbs_g", "fiber_g", "sugar_g"] if c in df.columns]] > 100).any(axis=1)
    if {"protein_g", "fat_g", "carbs_g"} <= set(df.columns):
        bad |= (df.protein_g.fillna(0) + df.fat_g.fillna(0) + df.carbs_g.fillna(0)) > 110
    if "sodium_mg" in df.columns:
        bad |= df.sodium_mg > 40000
    rep["impossible_rows_removed"] = int(bad.sum()); df = df[~bad]
    rep["rows_imported"] = len(df)
    rows = []
    for r in df.to_dict("records"):
        r = {k: _nz(v) for k, v in r.items()}
        rows.append(dict(name=str(r["food_name"])[:255], category=str(r.get("food_type") or "Other")[:60], serving_desc="100 g", serving_g=100.0,
                         calories=float(r["calories"]), protein_g=r.get("protein_g"), carbs_g=r.get("carbs_g"), fat_g=r.get("fat_g"),
                         fiber_g=r.get("fiber_g"), sugar_g=r.get("sugar_g"), sodium_mg=r.get("sodium_mg"), allergens=[], allergen_verified=False,
                         diet_class="unknown", diet_verified=False, meal_roles=[], tags=[], purchase_factor=1.0,
                         data_source="healthy_foods_database.csv", data_confidence="imported-unverified", is_custom=False, is_illustrative=False,
                         created_at=dt.datetime.now(dt.timezone.utc)))
    db.bulk_insert_mappings(Food, rows)
    db.commit()
    return rep
