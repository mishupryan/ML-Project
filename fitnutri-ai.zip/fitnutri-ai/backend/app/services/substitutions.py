"""Ingredient substitution: compatible foods in the same role/category with quantities re-scaled and honest nutrient deltas."""
from __future__ import annotations

from sqlalchemy.orm import Session

from ..models import Food, User
from ..utils.foodlogic import Constraints, cost_for, protein_per_100kcal
from . import context as cx

KEYS = ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")


def similarity(a: Food, b: Food) -> float:
    ra, rb = set(a.meal_roles or []), set(b.meal_roles or [])
    role = len(ra & rb) / max(len(ra | rb), 1) if (ra or rb) else 0
    cat = 1.0 if a.category == b.category else 0.0
    pa = (a.protein_g or 0) * 4 / max(a.calories, 1)
    pb = (b.protein_g or 0) * 4 / max(b.calories, 1)
    ca = (a.carbs_g or 0) * 4 / max(a.calories, 1)
    cb = (b.carbs_g or 0) * 4 / max(b.calories, 1)
    macro = 1 - min(1, (abs(pa - pb) + abs(ca - cb)) / 1.0)
    return 0.45 * role + 0.2 * cat + 0.35 * macro


def substitute(db: Session, user: User, food: Food, quantity_g: float, *, match: str = "calories", limit: int = 4, cons: Constraints | None = None,
               only_roles: bool = True) -> list[dict]:
    cons = cons or Constraints.from_profile(user.profile)
    orig = cx.nutrient_summary(food, quantity_g)
    out = []
    for cand in cx.candidate_foods(db, user, cons):
        if cand.id == food.id:
            continue
        if only_roles and (food.meal_roles or cand.meal_roles) and not (set(food.meal_roles or []) & set(cand.meal_roles or [])):
            continue
        ref = (orig["protein_g"] or 0) if match == "protein" else (orig["calories"] or 0)
        per100 = (cand.protein_g or 0) if match == "protein" else cand.calories
        if per100 <= 0 or ref <= 0:
            continue
        q = cx.round_qty(cand, ref / per100 * 100)
        q = max(min(q, 600), 5)
        n = cx.nutrient_summary(cand, q)
        delta = {k: round((n[k] or 0) - (orig[k] or 0), 1) for k in KEYS}
        diffs = [f"{'+' if v > 0 else ''}{v:g} {k.replace('_g', ' g').replace('calories', 'kcal')}" for k, v in delta.items() if abs(v) >= (30 if k == "calories" else 3)]
        out.append({"food": cx.compact_food(cand), "quantity_g": q, "display_qty": cx.display_qty(cand, q), "nutrients": n, "delta_vs_original": delta,
                    "similarity": round(similarity(food, cand), 3), "cost_inr": cost_for(cand, q), "matched_on": match,
                    "caveat": ("Not nutritionally identical - differences: " + ", ".join(diffs)) if diffs else "Close match on the main macros, but micronutrients and texture differ.",
                    "protein_per_100kcal": protein_per_100kcal(cand)})
    out.sort(key=lambda x: -x["similarity"])
    return out[:limit]
