"""Shared helpers for planner / recommender / substitutions."""
from __future__ import annotations

from typing import Optional

from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..models import Food, RecommendationFeedback, User
from ..utils.foodlogic import Constraints, cost_for, scale_nutrients


def round_qty(food: Food, grams: float) -> float:
    if food.unit_g:
        return round(max(1, round(grams / food.unit_g)) * food.unit_g, 1)
    return float(max(5, int(round(grams / 5.0)) * 5))


def display_qty(food: Food, grams: float) -> str:
    if food.unit_g and food.unit_name:
        n = grams / food.unit_g
        name = food.unit_name
        plural = name if (n == 1 or name.endswith("s")) else name + "s"
        return f"{n:g} {plural} ({grams:g} g)"
    return f"{grams:g} g"


def candidate_foods(db: Session, user: User, cons: Constraints, *, include_custom: bool = True, require_roles: bool = False) -> list[Food]:
    """Foods usable for recommendations / planning: curated generic foods (+ the user's own custom foods).
    Imported-unverified records are never used here - their diet class and allergens are unknown."""
    conf = ["curated-approximate"] + (["user-custom"] if include_custom else [])
    q = db.query(Food).filter(Food.data_confidence.in_(conf), or_(Food.owner_user_id.is_(None), Food.owner_user_id == user.id))
    out = []
    for f in q.all():
        if require_roles and not f.meal_roles:
            continue
        ok, _ = cons.check(f)
        if ok:
            out.append(f)
    return out


def feedback_prior(db: Session, user: User) -> dict[int, float]:
    """Per-food score in [-1, 1] from the user's OWN explicit feedback (Laplace-smoothed)."""
    pos: dict[int, int] = {}
    neg: dict[int, int] = {}
    for fb in db.query(RecommendationFeedback).filter_by(user_id=user.id).all():
        d = pos if fb.rating > 0 else neg
        d[fb.food_id] = d.get(fb.food_id, 0) + 1
    ids = set(pos) | set(neg)
    return {i: (pos.get(i, 0) - neg.get(i, 0)) / (pos.get(i, 0) + neg.get(i, 0) + 2) for i in ids}


def liked_match(food: Food, liked: list[str]) -> bool:
    n = food.name.lower()
    return any(l.strip().lower() in n for l in liked if l and l.strip())


def nutrient_summary(food: Food, grams: float) -> dict:
    n = scale_nutrients(food, grams)
    return {k: n[k] for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg")} | {"missing": n["missing"]}


def compact_food(food: Food) -> dict:
    return {"id": food.id, "name": food.name, "category": food.category, "serving_desc": food.serving_desc, "diet_class": food.diet_class,
            "prep_time_min": food.prep_time_min, "data_confidence": food.data_confidence, "is_illustrative": food.is_illustrative}


def protein_per_rupee(food: Food) -> Optional[float]:
    c = cost_for(food, 100)
    if not c or food.protein_g is None:
        return None
    return food.protein_g / c
