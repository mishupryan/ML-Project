"""Runtime ML inference: loads saved artifacts, predicts, and falls back gracefully when no trained model exists."""
from __future__ import annotations

import datetime as dt
import json
import sys
import threading
from pathlib import Path

import numpy as np
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Food, ModelMetadata

if str(settings.ml_src_dir) not in sys.path:
    sys.path.insert(0, str(settings.ml_src_dir))

TASKS = {"food_category": "Food category classifier", "health_score": "Health-score classifier (research)"}
_cache: dict = {}
_lock = threading.Lock()


def _dir(task: str) -> Path:
    return Path(settings.ml_model_dir) / task


def reset_cache():
    with _lock:
        _cache.clear()


def load(task: str):
    """Returns Artifacts or None when the model has not been trained yet."""
    from fitnutri_ml.predict import Artifacts, artifacts_exist
    p = _dir(task)
    with _lock:
        key = (task, str(p))
        if key in _cache:
            return _cache[key]
        art = None
        if artifacts_exist(p):
            try:
                art = Artifacts(p)
            except Exception:
                art = None
        _cache[key] = art
        return art


def status() -> dict:
    out = {}
    for task, label in TASKS.items():
        art = load(task)
        if art is None:
            out[task] = {"label": label, "available": False,
                         "message": "No trained model found. Run `python scripts/train_models.py` (or the Colab notebook) to create one.",
                         "fallback": "nearest-centroid on database foods" if task == "food_category" else None}
        else:
            md = art.metadata
            best = art.metrics.get("models", {}).get(md.get("serving_model"), {})
            out[task] = {"label": label, "available": True, "version": md.get("version"), "trained_at": md.get("trained_at"), "serving_model": md.get("serving_model"),
                         "best_model_by_validation_macro_f1": md.get("best_model_by_validation_macro_f1"), "classes": md.get("classes"),
                         "test_metrics_serving_model": best.get("test"), "majority_baseline_test_accuracy": md.get("majority_baseline_test_accuracy")}
    return out


def metrics(task: str) -> dict | None:
    art = load(task)
    return None if art is None else {"metadata": art.metadata, "metrics": art.metrics}


def _centroid_fallback(db: Session, nutrients: dict, top_k: int) -> dict:
    """No trained model: nearest category centroid (z-scored nutrients) over the foods in the database. Clearly labelled as a fallback."""
    keys = ["calories", "protein_g", "carbs_g", "fat_g"]
    foods = db.query(Food).filter(Food.protein_g.isnot(None), Food.carbs_g.isnot(None), Food.fat_g.isnot(None)).limit(20000).all()
    if len(foods) < 10:
        return {"available": False, "message": "No trained model and too little data for the fallback."}
    M = np.array([[getattr(f, k) or 0 for k in keys] for f in foods], dtype=float)
    mu, sd = M.mean(0), M.std(0) + 1e-9
    z = (M - mu) / sd
    cats = np.array([f.category for f in foods])
    cent = {c: z[cats == c].mean(0) for c in set(cats) if (cats == c).sum() >= 3}
    if not cent:
        return {"available": False, "message": "No trained model and too little data for the fallback."}
    x = (np.array([nutrients.get(k) or 0 for k in keys], dtype=float) - mu) / sd
    w = {c: 1 / (float(np.linalg.norm(x - v)) + 1e-6) for c, v in cent.items()}
    tot = sum(w.values())
    top = sorted(w.items(), key=lambda kv: -kv[1])[:top_k]
    return {"available": True, "prediction": top[0][0], "probabilities": [{"label": c, "probability": round(v / tot, 4)} for c, v in top],
            "method": "nearest-centroid fallback (no trained model artifact found)", "warning": "This is a crude fallback, not a trained model."}


def predict(task: str, nutrients: dict, db: Session | None = None, top_k: int = 3) -> dict:
    from fitnutri_ml.predict import predict as _predict
    art = load(task)
    if art is None:
        if task == "food_category" and db is not None:
            return _centroid_fallback(db, nutrients, top_k)
        return {"available": False, "message": "No trained model found for this task. Train it first (scripts/train_models.py)."}
    r = _predict(art, nutrients, top_k)
    md = art.metadata
    mm = art.metrics.get("models", {}).get(md.get("serving_model"), {}).get("test", {})
    return {"available": True, **r, "method": f"trained model: {md.get('serving_model')}", "model_version": md.get("version"),
            "model_test_macro_f1": mm.get("macro_f1"), "model_test_accuracy": mm.get("accuracy"),
            "warning": ("Low-confidence prediction (top probability below 50%)." if r["probabilities"][0]["probability"] < 0.5 else None),
            "limitations": "Predictions describe statistical patterns in a nutrient table; they are not a food-safety, allergen or health judgement."}


def sync_model_metadata():
    from ..database import SessionLocal
    with SessionLocal() as db:
        for task in TASKS:
            p = _dir(task) / "metadata.json"
            if not p.exists():
                continue
            md = json.loads(p.read_text())
            mp = _dir(task) / "metrics.json"
            mt = json.loads(mp.read_text()).get("models", {}).get(md.get("serving_model"), {}).get("test", {}) if mp.exists() else {}
            if not db.query(ModelMetadata).filter_by(name=task, version=md.get("version")).first():
                db.query(ModelMetadata).filter_by(name=task).update({"is_active": False})
                db.add(ModelMetadata(name=task, version=md.get("version", "?"), trained_at=dt.datetime.fromisoformat(md["trained_at"]) if md.get("trained_at") else None,
                                     metrics=mt, path=str(_dir(task)), is_active=True))
        db.commit()
