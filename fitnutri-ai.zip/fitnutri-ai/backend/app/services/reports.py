"""Weekly report built from REAL logged data. Missing logs are never treated as zero consumption."""
from __future__ import annotations

import datetime as dt
from collections import Counter, defaultdict

from sqlalchemy.orm import Session

from ..models import User, WaterLog, WeightLog
from ..services import diary as dsvc
from ..services import targets as tsvc
from ..utils.dates import daterange

KEYS = ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")


def weekly_report(db: Session, user: User, end: dt.date) -> dict:
    start = end - dt.timedelta(days=6)
    entries = dsvc.entries_between(db, user.id, start, end)
    per_day = dsvc.by_day(entries)
    t = tsvc.target_dict(tsvc.get_targets(db, user))
    days = []
    for d in daterange(start, end):
        es = per_day.get(d, [])
        tot = dsvc.totals(es) if es else None
        days.append({"date": d.isoformat(), "logged": bool(es), **({k: tot[k] for k in KEYS} if tot else {k: None for k in KEYS})})
    logged = [d for d in days if d["logged"]]
    n = len(logged)
    avg = {k: (round(sum(d[k] for d in logged) / n, 1) if n else None) for k in KEYS}
    adherence = None
    if t and n:
        adherence = {"days_within_10pct_calories": sum(1 for d in logged if 0.9 * t["calories"] <= d["calories"] <= 1.1 * t["calories"]),
                     "days_protein_at_least_90pct": sum(1 for d in logged if d["protein_g"] >= 0.9 * t["protein_g"]),
                     "days_fiber_at_least_80pct": sum(1 for d in logged if d["fiber_g"] >= 0.8 * t["fiber_g"]), "logged_days": n}
    foods = Counter(e.label for e in entries)
    meal_counts = Counter()
    for d, es in per_day.items():
        for m in {e.meal_type for e in es}:
            meal_counts[m] += 1
    expected = {3: ["breakfast", "lunch", "dinner"], 4: ["breakfast", "lunch", "evening_snack", "dinner"]}.get(user.profile.meals_per_day or 4,
                                                                                                               ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner"])
    skipped = [{"meal": m, "days_logged": meal_counts.get(m, 0), "of_logged_days": n} for m in expected if n and meal_counts.get(m, 0) < n * 0.5]
    helpers = []
    if t and n >= 3:
        hit_days = {d["date"] for d in logged if d["protein_g"] >= 0.9 * t["protein_g"]}
        by_food = defaultdict(lambda: [0, 0])
        for dd, es in per_day.items():
            for e in {x.label for x in es}:
                by_food[e][1] += 1
                if dd.isoformat() in hit_days:
                    by_food[e][0] += 1
        helpers = sorted([{"food": f, "days_eaten": b, "of_which_protein_target_met": a} for f, (a, b) in by_food.items() if b >= 2 and a / b >= 0.6],
                         key=lambda x: -x["days_eaten"])[:5]
    spend = [e.cost_inr for e in entries if e.cost_inr is not None]
    cost = {"estimated_spend_inr": round(sum(spend), 1) if spend else None, "entries_with_price": len(spend), "entries_total": len(entries),
            "note": "Prices are illustrative; entries without a price are excluded." if entries else None}
    suggestions = []
    if n == 0:
        suggestions.append("No food was logged this week, so nothing can be concluded. Log a few days to get meaningful averages.")
    else:
        if n < 5:
            suggestions.append(f"Only {n} of 7 days have food logged. Averages use logged days only; missing days are unknown, not zero.")
        if t:
            if avg["protein_g"] is not None and avg["protein_g"] < 0.85 * t["protein_g"]:
                suggestions.append(f"Average protein on logged days was {avg['protein_g']:.0f} g vs a {t['protein_g']:.0f} g target: add a protein source to your lowest-protein meal (see Recommendations).")
            if avg["fiber_g"] is not None and avg["fiber_g"] < 0.8 * t["fiber_g"]:
                suggestions.append(f"Average fibre was {avg['fiber_g']:.0f} g vs about {t['fiber_g']:.0f} g: add legumes, vegetables, fruit or whole grains. (Fibre totals can be underestimated if some foods lack fibre data.)")
            if avg["calories"] is not None and avg["calories"] < 0.85 * t["calories"]:
                suggestions.append("Average calories were well below target on logged days - check whether some meals were simply not logged.")
            if avg["calories"] is not None and avg["calories"] > 1.15 * t["calories"]:
                suggestions.append("Average calories were above target - review portion sizes of the most energy-dense foods.")
        if skipped:
            suggestions.append("Meals often missing from your log: " + ", ".join(s["meal"].replace("_", " ") for s in skipped) + ".")
        if not suggestions:
            suggestions.append("Your logged days look consistent with your targets. Keep tracking and review the trend over several weeks.")
    water = defaultdict(int)
    for w in db.query(WaterLog).filter(WaterLog.user_id == user.id, WaterLog.log_date >= start, WaterLog.log_date <= end):
        water[w.log_date] += w.amount_ml
    ws = db.query(WeightLog).filter(WeightLog.user_id == user.id, WeightLog.log_date >= start, WeightLog.log_date <= end).order_by(WeightLog.log_date).all()
    return {"start": start.isoformat(), "end": end.isoformat(), "targets": t, "days": days, "days_logged": n, "days_not_logged": 7 - n, "averages_logged_days": avg,
            "adherence": adherence, "top_foods": [{"food": f, "times_logged": c} for f, c in foods.most_common(5)], "meals_often_missing": skipped,
            "foods_on_days_protein_target_met": helpers, "cost": cost, "water_avg_ml_on_logged_days": round(sum(water.values()) / len(water)) if water else None,
            "weight": {"first_kg": ws[0].weight_kg, "last_kg": ws[-1].weight_kg, "change_kg": round(ws[-1].weight_kg - ws[0].weight_kg, 2)} if len(ws) >= 2 else None,
            "suggestions": suggestions,
            "disclaimer": "Based only on what you logged. No amount of muscle gain or fat loss is implied; scale weight cannot distinguish muscle from fat. Not medical advice."}
