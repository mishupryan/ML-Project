"""FitNutri AI backend."""
