import datetime as dt
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from ..utils.foodlogic import ALLERGENS, DIET_CHOICES

MealType = Literal["breakfast", "mid_morning_snack", "lunch", "evening_snack", "pre_workout", "post_workout", "dinner", "custom"]
MEAL_ORDER = ["breakfast", "mid_morning_snack", "pre_workout", "lunch", "evening_snack", "post_workout", "dinner", "custom"]


class FoodIn(BaseModel):
    """Custom food. All nutrient values are PER 100 g."""
    name: str = Field(min_length=1, max_length=255)
    brand: Optional[str] = Field(None, max_length=100)
    category: str = Field("Custom", min_length=1, max_length=60)
    serving_desc: str = Field("100 g", max_length=100)
    serving_g: float = Field(100, gt=0, le=5000)
    calories: float = Field(ge=0, le=900)
    protein_g: Optional[float] = Field(None, ge=0, le=100)
    carbs_g: Optional[float] = Field(None, ge=0, le=100)
    fat_g: Optional[float] = Field(None, ge=0, le=100)
    sat_fat_g: Optional[float] = Field(None, ge=0, le=100)
    fiber_g: Optional[float] = Field(None, ge=0, le=100)
    sugar_g: Optional[float] = Field(None, ge=0, le=100)
    sodium_mg: Optional[float] = Field(None, ge=0, le=40000)
    ingredients: Optional[str] = None
    allergens: list[str] = []
    allergen_verified: bool = False
    diet_class: Literal[tuple(DIET_CHOICES + ["unknown"])] = "unknown"  # type: ignore[valid-type]
    cuisine: Optional[str] = None
    prep_time_min: Optional[int] = Field(None, ge=0, le=600)
    price_per_100g: Optional[float] = Field(None, ge=0, le=100000)

    @field_validator("allergens")
    @classmethod
    def _al(cls, v):
        bad = [a for a in v if a not in ALLERGENS]
        if bad:
            raise ValueError(f"unknown allergens {bad}; allowed: {ALLERGENS}")
        return v

    @model_validator(mode="after")
    def _macros(self):
        p, c, f = (self.protein_g or 0), (self.carbs_g or 0), (self.fat_g or 0)
        if p + c + f > 110:
            raise ValueError("protein + carbs + fat cannot exceed ~100 g per 100 g of food")
        return self


class FoodUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    brand: Optional[str] = None
    category: Optional[str] = None
    serving_desc: Optional[str] = None
    serving_g: Optional[float] = Field(None, gt=0, le=5000)
    calories: Optional[float] = Field(None, ge=0, le=900)
    protein_g: Optional[float] = Field(None, ge=0, le=100)
    carbs_g: Optional[float] = Field(None, ge=0, le=100)
    fat_g: Optional[float] = Field(None, ge=0, le=100)
    fiber_g: Optional[float] = Field(None, ge=0, le=100)
    sugar_g: Optional[float] = Field(None, ge=0, le=100)
    sodium_mg: Optional[float] = Field(None, ge=0, le=40000)
    allergens: Optional[list[str]] = None
    allergen_verified: Optional[bool] = None
    diet_class: Optional[str] = None
    price_per_100g: Optional[float] = Field(None, ge=0, le=100000)


class DiaryIn(BaseModel):
    food_id: Optional[int] = None
    label: Optional[str] = Field(None, max_length=255)
    quantity_g: Optional[float] = Field(None, gt=0, le=10000)
    servings: Optional[float] = Field(None, gt=0, le=100)
    meal_type: MealType = "breakfast"
    log_date: Optional[dt.date] = None
    notes: Optional[str] = Field(None, max_length=255)

    @model_validator(mode="after")
    def _need(self):
        if self.food_id is None:
            raise ValueError("food_id is required (use /api/recipes/{id}/log to log a recipe)")
        if self.quantity_g is None and self.servings is None:
            raise ValueError("provide quantity_g (grams) or servings")
        return self


class DiaryUpdate(BaseModel):
    quantity_g: Optional[float] = Field(None, gt=0, le=10000)
    servings: Optional[float] = Field(None, gt=0, le=100)
    meal_type: Optional[MealType] = None
    log_date: Optional[dt.date] = None
    notes: Optional[str] = None


class CopyDiaryIn(BaseModel):
    from_date: dt.date
    to_date: dt.date
    meal_type: Optional[MealType] = None


class DuplicateMealIn(BaseModel):
    date: dt.date
    meal_type: MealType
    to_meal_type: Optional[MealType] = None
    to_date: Optional[dt.date] = None


class MealItemIn(BaseModel):
    food_id: int
    quantity_g: float = Field(gt=0, le=10000)


class MealIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    meal_type: Optional[MealType] = None
    items: list[MealItemIn] = Field(min_length=1, max_length=40)


class LogMealIn(BaseModel):
    log_date: Optional[dt.date] = None
    meal_type: MealType = "lunch"
