import datetime as dt
from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator

from .food import MealType


class PlanRequest(BaseModel):
    plan_type: str = "muscle_gain"
    days: int = Field(1, ge=1, le=7)
    name: Optional[str] = Field(None, max_length=160)
    meals_per_day: Optional[int] = Field(None, ge=3, le=6)
    calories: Optional[float] = Field(None, ge=1000, le=6000)
    protein_g: Optional[float] = Field(None, ge=20, le=400)
    carbs_g: Optional[float] = Field(None, ge=0, le=900)
    fat_g: Optional[float] = Field(None, ge=0, le=300)
    daily_budget_inr: Optional[float] = Field(None, ge=0, le=100000)
    diet: Optional[Literal["vegan", "vegetarian", "eggetarian", "pescatarian", "non_vegetarian"]] = None
    exclude_foods: list[str] = []
    include_only: list[str] = []
    seed: Optional[int] = None


class PlanUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=160)
    is_saved: Optional[bool] = None


class RegenMealIn(BaseModel):
    day_index: int = Field(ge=0, le=6)
    slot: str


class AlternativesIn(BaseModel):
    count: int = Field(3, ge=1, le=5)


class PlanItemIn(BaseModel):
    food_id: int
    quantity_g: float = Field(gt=0, le=2000)
    role: Optional[str] = None


class ApplyItemsIn(BaseModel):
    items: list[PlanItemIn] = Field(min_length=1, max_length=12)


class ReplaceIn(BaseModel):
    food_id: int
    quantity_g: Optional[float] = Field(None, gt=0, le=2000)


class SwapIn(BaseModel):
    meal_id_a: int
    meal_id_b: int


class LogPlanMealIn(BaseModel):
    log_date: Optional[dt.date] = None
    meal_type: Optional[MealType] = None


class SubstitutionIn(BaseModel):
    food_id: int
    quantity_g: float = Field(100, gt=0, le=2000)
    match: Literal["calories", "protein"] = "calories"
    limit: int = Field(4, ge=1, le=10)


class FeedbackIn(BaseModel):
    food_id: int
    rating: Literal[-1, 1]
    context: Optional[str] = Field(None, max_length=40)


class RecipeIngredientIn(BaseModel):
    food_id: int
    quantity_g: float = Field(gt=0, le=10000)


class RecipeIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    servings: float = Field(1, gt=0, le=100)
    instructions: Optional[str] = Field(None, max_length=5000)
    prep_time_min: Optional[int] = Field(None, ge=0, le=1000)
    ingredients: list[RecipeIngredientIn] = Field(min_length=1, max_length=60)


class RecipeLogIn(BaseModel):
    servings: float = Field(1, gt=0, le=20)
    meal_type: MealType = "lunch"
    log_date: Optional[dt.date] = None


class GroceryFromPlanIn(BaseModel):
    day_indexes: Optional[list[int]] = None
    name: Optional[str] = None


class GroceryItemIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    quantity_g: float = Field(gt=0, le=100000)
    food_id: Optional[int] = None


class GroceryItemPatch(BaseModel):
    purchased: Optional[bool] = None
    quantity_g: Optional[float] = Field(None, gt=0, le=100000)
    est_cost_inr: Optional[float] = Field(None, ge=0, le=1000000)


class WeightIn(BaseModel):
    weight_kg: float = Field(gt=25, lt=400)
    log_date: Optional[dt.date] = None
    note: Optional[str] = Field(None, max_length=255)


class MeasurementIn(BaseModel):
    log_date: Optional[dt.date] = None
    waist_cm: Optional[float] = Field(None, gt=20, lt=300)
    chest_cm: Optional[float] = Field(None, gt=20, lt=300)
    arm_cm: Optional[float] = Field(None, gt=10, lt=100)
    thigh_cm: Optional[float] = Field(None, gt=10, lt=200)
    hip_cm: Optional[float] = Field(None, gt=20, lt=300)
    body_fat_pct: Optional[float] = Field(None, ge=2, le=70)
    note: Optional[str] = Field(None, max_length=255)

    @model_validator(mode="after")
    def _any(self):
        if all(getattr(self, k) is None for k in ("waist_cm", "chest_cm", "arm_cm", "thigh_cm", "hip_cm", "body_fat_pct")):
            raise ValueError("provide at least one measurement")
        return self


class ExerciseIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    sets: Optional[int] = Field(None, ge=1, le=100)
    reps: Optional[int] = Field(None, ge=1, le=1000)
    weight_kg: Optional[float] = Field(None, ge=0, le=1000)


class WorkoutIn(BaseModel):
    workout_date: Optional[dt.date] = None
    workout_type: str = Field(min_length=1, max_length=40)
    duration_min: Optional[int] = Field(None, ge=1, le=600)
    perceived_exertion: Optional[int] = Field(None, ge=1, le=10)
    notes: Optional[str] = Field(None, max_length=2000)
    exercises: list[ExerciseIn] = Field(default_factory=list, max_length=50)


class WaterIn(BaseModel):
    amount_ml: int = Field(gt=0, le=3000)
    log_date: Optional[dt.date] = None


class NutrientsIn(BaseModel):
    """Nutrients PER 100 g."""
    calories: float = Field(ge=0, le=900)
    protein_g: Optional[float] = Field(None, ge=0, le=100)
    fat_g: Optional[float] = Field(None, ge=0, le=100)
    carbs_g: Optional[float] = Field(None, ge=0, le=100)
    fiber_g: Optional[float] = Field(None, ge=0, le=100)
    sugar_g: Optional[float] = Field(None, ge=0, le=100)
    sodium_mg: Optional[float] = Field(None, ge=0, le=40000)


class PredictIn(BaseModel):
    food_id: Optional[int] = None
    nutrients: Optional[NutrientsIn] = None

    @model_validator(mode="after")
    def _one(self):
        if self.food_id is None and self.nutrients is None:
            raise ValueError("provide food_id or nutrients (per 100 g)")
        return self


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
