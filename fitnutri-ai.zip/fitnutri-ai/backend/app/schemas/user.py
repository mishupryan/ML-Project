import re
from typing import Literal, Optional
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from ..utils.foodlogic import DIET_CHOICES, DIET_FLAGS

Sex = Literal["male", "female", "other"]
Activity = Literal["sedentary", "light", "moderate", "very_active", "extra_active"]
Goal = Literal["muscle_gain", "lean_bulk", "fat_loss", "recomposition", "maintenance", "general_fitness", "improve_protein", "healthy_habits"]
HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
WEEKDAYS = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"}


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    display_name: str = Field(min_length=1, max_length=100)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=72)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    display_name: str
    is_demo: bool = False


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_at: str
    user: UserOut


def _clean_list(v):
    return [str(x).strip() for x in (v or []) if str(x).strip()][:50]


class ProfileIn(BaseModel):
    age: Optional[int] = Field(None, ge=10, le=100)
    sex: Optional[Sex] = None
    height_cm: Optional[float] = Field(None, ge=100, le=250)
    weight_kg: Optional[float] = Field(None, ge=25, le=400)
    target_weight_kg: Optional[float] = Field(None, ge=25, le=400)
    activity_level: Optional[Activity] = None
    goal: Optional[Goal] = None
    diet_preference: Optional[Literal[tuple(DIET_CHOICES)]] = None  # type: ignore[valid-type]
    diet_flags: Optional[list[str]] = None
    allergies: Optional[list[str]] = None
    liked_foods: Optional[list[str]] = None
    disliked_foods: Optional[list[str]] = None
    preferred_cuisine: Optional[str] = Field(None, max_length=30)
    meals_per_day: Optional[int] = Field(None, ge=3, le=6)
    daily_budget: Optional[float] = Field(None, ge=0, le=100000)
    cooking_equipment: Optional[list[str]] = None
    cooking_time_pref_min: Optional[int] = Field(None, ge=0, le=240)
    workout_days: Optional[list[str]] = None
    workout_time: Optional[str] = None
    wake_time: Optional[str] = None
    sleep_time: Optional[str] = None
    medical_or_pregnancy_flag: Optional[bool] = None
    eating_disorder_concern: Optional[bool] = None
    water_enabled: Optional[bool] = None
    water_target_ml: Optional[int] = Field(None, ge=500, le=8000)
    timezone: Optional[str] = None

    @field_validator("diet_flags")
    @classmethod
    def _flags(cls, v):
        if v is None:
            return v
        bad = [x for x in v if x not in DIET_FLAGS]
        if bad:
            raise ValueError(f"unknown diet flags: {bad}. Allowed: {DIET_FLAGS}")
        return list(dict.fromkeys(v))

    @field_validator("allergies", "liked_foods", "disliked_foods", "cooking_equipment")
    @classmethod
    def _lists(cls, v):
        return None if v is None else _clean_list(v)

    @field_validator("workout_days")
    @classmethod
    def _days(cls, v):
        if v is None:
            return v
        v = [d.strip().lower()[:3] for d in v]
        if any(d not in WEEKDAYS for d in v):
            raise ValueError("workout_days must be weekday abbreviations (mon..sun)")
        return list(dict.fromkeys(v))

    @field_validator("workout_time", "wake_time", "sleep_time")
    @classmethod
    def _hhmm(cls, v):
        if v is not None and not HHMM.match(v):
            raise ValueError("time must be HH:MM (24h)")
        return v

    @field_validator("timezone")
    @classmethod
    def _tz(cls, v):
        if v is not None:
            try:
                ZoneInfo(v)
            except Exception:
                raise ValueError("unknown timezone")
        return v


class TargetsIn(BaseModel):
    calories: float = Field(ge=800, le=8000)
    protein_g: float = Field(ge=0, le=500)
    carbs_g: float = Field(ge=0, le=1500)
    fat_g: float = Field(ge=0, le=400)
    fiber_g: Optional[float] = Field(None, ge=0, le=150)
    water_ml: Optional[int] = Field(None, ge=0, le=10000)
