"""Relational schema for FitNutri AI (SQLAlchemy 2.0 declarative mapping)."""
from __future__ import annotations

import datetime as dt
from typing import Optional

from sqlalchemy import (JSON, Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    display_name: Mapped[str] = mapped_column(String(100))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    profile: Mapped[Optional["UserProfile"]] = relationship(back_populates="user", uselist=False, cascade="all, delete-orphan")
    targets: Mapped[Optional["NutritionTarget"]] = relationship(back_populates="user", uselist=False, cascade="all, delete-orphan")


class RevokedToken(Base):
    __tablename__ = "revoked_tokens"
    jti: Mapped[str] = mapped_column(String(64), primary_key=True)
    expires_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))


class UserProfile(Base):
    __tablename__ = "user_profiles"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    age: Mapped[Optional[int]] = mapped_column(Integer)
    sex: Mapped[Optional[str]] = mapped_column(String(10))  # male / female / other (used only for the BMR equation constant)
    height_cm: Mapped[Optional[float]] = mapped_column(Float)
    weight_kg: Mapped[Optional[float]] = mapped_column(Float)
    target_weight_kg: Mapped[Optional[float]] = mapped_column(Float)
    activity_level: Mapped[str] = mapped_column(String(20), default="moderate")
    goal: Mapped[str] = mapped_column(String(30), default="general_fitness")
    diet_preference: Mapped[str] = mapped_column(String(30), default="non_vegetarian")
    diet_flags: Mapped[list] = mapped_column(JSON, default=list)       # lactose_free, gluten_free, high_protein, budget_friendly ...
    allergies: Mapped[list] = mapped_column(JSON, default=list)
    liked_foods: Mapped[list] = mapped_column(JSON, default=list)
    disliked_foods: Mapped[list] = mapped_column(JSON, default=list)
    preferred_cuisine: Mapped[Optional[str]] = mapped_column(String(30))
    meals_per_day: Mapped[int] = mapped_column(Integer, default=4)
    daily_budget: Mapped[Optional[float]] = mapped_column(Float)
    cooking_equipment: Mapped[list] = mapped_column(JSON, default=list)
    cooking_time_pref_min: Mapped[Optional[int]] = mapped_column(Integer)
    workout_days: Mapped[list] = mapped_column(JSON, default=list)
    workout_time: Mapped[Optional[str]] = mapped_column(String(5))
    wake_time: Mapped[str] = mapped_column(String(5), default="07:00")
    sleep_time: Mapped[str] = mapped_column(String(5), default="23:00")
    medical_or_pregnancy_flag: Mapped[bool] = mapped_column(Boolean, default=False)
    eating_disorder_concern: Mapped[bool] = mapped_column(Boolean, default=False)
    water_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    water_target_ml: Mapped[Optional[int]] = mapped_column(Integer)
    timezone: Mapped[str] = mapped_column(String(50), default="Asia/Kolkata")
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    user: Mapped[User] = relationship(back_populates="profile")
    __table_args__ = (CheckConstraint("meals_per_day BETWEEN 3 AND 6", name="ck_profile_meals"),)


class NutritionTarget(Base):
    __tablename__ = "nutrition_targets"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    calories: Mapped[float] = mapped_column(Float)
    protein_g: Mapped[float] = mapped_column(Float)
    carbs_g: Mapped[float] = mapped_column(Float)
    fat_g: Mapped[float] = mapped_column(Float)
    fiber_g: Mapped[float] = mapped_column(Float, default=25)
    water_ml: Mapped[Optional[int]] = mapped_column(Integer)
    is_manual: Mapped[bool] = mapped_column(Boolean, default=False)
    bmr: Mapped[Optional[float]] = mapped_column(Float)
    tdee: Mapped[Optional[float]] = mapped_column(Float)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    user: Mapped[User] = relationship(back_populates="targets")


class Food(Base):
    """Nutrient values are stored PER 100 g."""
    __tablename__ = "foods"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    brand: Mapped[Optional[str]] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(String(60), index=True)
    serving_desc: Mapped[str] = mapped_column(String(100), default="100 g")
    serving_g: Mapped[float] = mapped_column(Float, default=100)
    unit_g: Mapped[Optional[float]] = mapped_column(Float)          # weight of one countable unit (egg, roti, banana ...)
    unit_name: Mapped[Optional[str]] = mapped_column(String(30))
    calories: Mapped[float] = mapped_column(Float)
    protein_g: Mapped[Optional[float]] = mapped_column(Float)
    carbs_g: Mapped[Optional[float]] = mapped_column(Float)
    fat_g: Mapped[Optional[float]] = mapped_column(Float)
    sat_fat_g: Mapped[Optional[float]] = mapped_column(Float)
    fiber_g: Mapped[Optional[float]] = mapped_column(Float)
    sugar_g: Mapped[Optional[float]] = mapped_column(Float)
    sodium_mg: Mapped[Optional[float]] = mapped_column(Float)
    micronutrients: Mapped[Optional[dict]] = mapped_column(JSON)
    ingredients: Mapped[Optional[str]] = mapped_column(Text)
    allergens: Mapped[list] = mapped_column(JSON, default=list)
    allergen_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    diet_class: Mapped[str] = mapped_column(String(20), default="unknown")   # vegan/vegetarian/eggetarian/pescatarian/non_vegetarian/unknown
    diet_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    cuisine: Mapped[Optional[str]] = mapped_column(String(30))
    meal_roles: Mapped[list] = mapped_column(JSON, default=list)
    tags: Mapped[list] = mapped_column(JSON, default=list)
    prep_time_min: Mapped[Optional[int]] = mapped_column(Integer)
    prep_note: Mapped[Optional[str]] = mapped_column(Text)
    price_per_100g: Mapped[Optional[float]] = mapped_column(Float)   # INR per 100 g AS PURCHASED
    purchase_factor: Mapped[float] = mapped_column(Float, default=1.0)  # grams purchased per 100 g eaten (e.g. dry rice -> cooked)
    price_source: Mapped[Optional[str]] = mapped_column(String(100))
    price_updated: Mapped[Optional[dt.date]] = mapped_column(Date)
    data_source: Mapped[str] = mapped_column(String(100), default="unknown")
    data_confidence: Mapped[str] = mapped_column(String(30), default="imported-unverified")  # curated-approximate / imported-unverified / user-custom
    is_custom: Mapped[bool] = mapped_column(Boolean, default=False)
    is_illustrative: Mapped[bool] = mapped_column(Boolean, default=False)
    owner_user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("calories >= 0", name="ck_food_cal"), CheckConstraint("serving_g > 0", name="ck_food_serving"),
                      Index("ix_foods_source_conf", "data_confidence"))


class FoodDiaryEntry(Base):
    __tablename__ = "food_diary_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[Optional[int]] = mapped_column(ForeignKey("foods.id", ondelete="SET NULL"))
    recipe_id: Mapped[Optional[int]] = mapped_column(ForeignKey("recipes.id", ondelete="SET NULL"))
    label: Mapped[str] = mapped_column(String(255))
    log_date: Mapped[dt.date] = mapped_column(Date, index=True)
    meal_type: Mapped[str] = mapped_column(String(30), default="breakfast")
    quantity_g: Mapped[float] = mapped_column(Float)
    servings: Mapped[Optional[float]] = mapped_column(Float)
    calories: Mapped[float] = mapped_column(Float, default=0)      # snapshot of the logged amount
    protein_g: Mapped[float] = mapped_column(Float, default=0)
    carbs_g: Mapped[float] = mapped_column(Float, default=0)
    fat_g: Mapped[float] = mapped_column(Float, default=0)
    fiber_g: Mapped[Optional[float]] = mapped_column(Float)
    sugar_g: Mapped[Optional[float]] = mapped_column(Float)
    sodium_mg: Mapped[Optional[float]] = mapped_column(Float)
    cost_inr: Mapped[Optional[float]] = mapped_column(Float)
    missing_nutrients: Mapped[list] = mapped_column(JSON, default=list)
    notes: Mapped[Optional[str]] = mapped_column(String(255))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    food: Mapped[Optional[Food]] = relationship()
    __table_args__ = (Index("ix_diary_user_date", "user_id", "log_date"), CheckConstraint("quantity_g > 0", name="ck_diary_qty"))


class SavedFood(Base):
    __tablename__ = "saved_foods"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[int] = mapped_column(ForeignKey("foods.id", ondelete="CASCADE"))
    food: Mapped[Food] = relationship()
    __table_args__ = (UniqueConstraint("user_id", "food_id", name="uq_saved_food"),)


class Meal(Base):
    """A reusable custom meal (collection of foods)."""
    __tablename__ = "meals"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    meal_type: Mapped[Optional[str]] = mapped_column(String(30))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    items: Mapped[list["MealItem"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class MealItem(Base):
    __tablename__ = "meal_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    meal_id: Mapped[int] = mapped_column(ForeignKey("meals.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[int] = mapped_column(ForeignKey("foods.id", ondelete="CASCADE"))
    quantity_g: Mapped[float] = mapped_column(Float)
    food: Mapped[Food] = relationship(lazy="selectin")


class Recipe(Base):
    __tablename__ = "recipes"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    servings: Mapped[float] = mapped_column(Float, default=1)
    instructions: Mapped[Optional[str]] = mapped_column(Text)
    prep_time_min: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ingredients: Mapped[list["RecipeIngredient"]] = relationship(cascade="all, delete-orphan", lazy="selectin")
    __table_args__ = (CheckConstraint("servings > 0", name="ck_recipe_servings"),)


class RecipeIngredient(Base):
    __tablename__ = "recipe_ingredients"
    id: Mapped[int] = mapped_column(primary_key=True)
    recipe_id: Mapped[int] = mapped_column(ForeignKey("recipes.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[int] = mapped_column(ForeignKey("foods.id", ondelete="CASCADE"))
    quantity_g: Mapped[float] = mapped_column(Float)
    food: Mapped[Food] = relationship(lazy="selectin")


class MealPlan(Base):
    __tablename__ = "meal_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    plan_type: Mapped[str] = mapped_column(String(40))
    num_days: Mapped[int] = mapped_column(Integer, default=1)
    meals_per_day: Mapped[int] = mapped_column(Integer, default=4)
    calories: Mapped[float] = mapped_column(Float)
    protein_g: Mapped[float] = mapped_column(Float)
    carbs_g: Mapped[float] = mapped_column(Float)
    fat_g: Mapped[float] = mapped_column(Float)
    fiber_g: Mapped[Optional[float]] = mapped_column(Float)
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    total_cost_inr: Mapped[Optional[float]] = mapped_column(Float)
    is_saved: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    days: Mapped[list["MealPlanDay"]] = relationship(cascade="all, delete-orphan", order_by="MealPlanDay.day_index", lazy="selectin")


class MealPlanDay(Base):
    __tablename__ = "meal_plan_days"
    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("meal_plans.id", ondelete="CASCADE"), index=True)
    day_index: Mapped[int] = mapped_column(Integer)
    meals: Mapped[list["MealPlanMeal"]] = relationship(cascade="all, delete-orphan", order_by="MealPlanMeal.sort_order", lazy="selectin")


class MealPlanMeal(Base):
    __tablename__ = "meal_plan_meals"
    id: Mapped[int] = mapped_column(primary_key=True)
    day_id: Mapped[int] = mapped_column(ForeignKey("meal_plan_days.id", ondelete="CASCADE"), index=True)
    slot: Mapped[str] = mapped_column(String(30))
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    name: Mapped[str] = mapped_column(String(255))
    instructions: Mapped[Optional[str]] = mapped_column(Text)
    prep_time_min: Mapped[Optional[int]] = mapped_column(Integer)
    rationale: Mapped[Optional[str]] = mapped_column(Text)
    substitutions: Mapped[list] = mapped_column(JSON, default=list)
    items: Mapped[list["MealPlanItem"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class MealPlanItem(Base):
    __tablename__ = "meal_plan_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    meal_id: Mapped[int] = mapped_column(ForeignKey("meal_plan_meals.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[int] = mapped_column(ForeignKey("foods.id", ondelete="CASCADE"))
    quantity_g: Mapped[float] = mapped_column(Float)
    role: Mapped[Optional[str]] = mapped_column(String(30))
    food: Mapped[Food] = relationship(lazy="selectin")


class ShoppingList(Base):
    __tablename__ = "shopping_lists"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[Optional[int]] = mapped_column(ForeignKey("meal_plans.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(160))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    items: Mapped[list["ShoppingListItem"]] = relationship(cascade="all, delete-orphan", lazy="selectin")


class ShoppingListItem(Base):
    __tablename__ = "shopping_list_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    list_id: Mapped[int] = mapped_column(ForeignKey("shopping_lists.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[Optional[int]] = mapped_column(ForeignKey("foods.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(255))
    quantity_g: Mapped[float] = mapped_column(Float)
    display_qty: Mapped[Optional[str]] = mapped_column(String(60))
    est_cost_inr: Mapped[Optional[float]] = mapped_column(Float)
    purchased: Mapped[bool] = mapped_column(Boolean, default=False)


class WeightLog(Base):
    __tablename__ = "weight_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    log_date: Mapped[dt.date] = mapped_column(Date)
    weight_kg: Mapped[float] = mapped_column(Float)
    note: Mapped[Optional[str]] = mapped_column(String(255))
    __table_args__ = (UniqueConstraint("user_id", "log_date", name="uq_weight_day"), CheckConstraint("weight_kg > 0", name="ck_weight_pos"))


class BodyMeasurement(Base):
    __tablename__ = "body_measurements"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    log_date: Mapped[dt.date] = mapped_column(Date)
    waist_cm: Mapped[Optional[float]] = mapped_column(Float)
    chest_cm: Mapped[Optional[float]] = mapped_column(Float)
    arm_cm: Mapped[Optional[float]] = mapped_column(Float)
    thigh_cm: Mapped[Optional[float]] = mapped_column(Float)
    hip_cm: Mapped[Optional[float]] = mapped_column(Float)
    body_fat_pct: Mapped[Optional[float]] = mapped_column(Float)
    note: Mapped[Optional[str]] = mapped_column(String(255))


class Workout(Base):
    __tablename__ = "workouts"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    workout_date: Mapped[dt.date] = mapped_column(Date)
    workout_type: Mapped[str] = mapped_column(String(40))
    duration_min: Mapped[Optional[int]] = mapped_column(Integer)
    perceived_exertion: Mapped[Optional[int]] = mapped_column(Integer)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    exercises: Mapped[list["WorkoutExercise"]] = relationship(cascade="all, delete-orphan", lazy="selectin")
    __table_args__ = (CheckConstraint("perceived_exertion IS NULL OR perceived_exertion BETWEEN 1 AND 10", name="ck_rpe"),)


class WorkoutExercise(Base):
    __tablename__ = "workout_exercises"
    id: Mapped[int] = mapped_column(primary_key=True)
    workout_id: Mapped[int] = mapped_column(ForeignKey("workouts.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(100))
    sets: Mapped[Optional[int]] = mapped_column(Integer)
    reps: Mapped[Optional[int]] = mapped_column(Integer)
    weight_kg: Mapped[Optional[float]] = mapped_column(Float)


class WaterLog(Base):
    __tablename__ = "water_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    log_date: Mapped[dt.date] = mapped_column(Date)
    amount_ml: Mapped[int] = mapped_column(Integer)
    logged_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("amount_ml > 0", name="ck_water_pos"),)


class RecommendationFeedback(Base):
    __tablename__ = "recommendation_feedback"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    food_id: Mapped[int] = mapped_column(ForeignKey("foods.id", ondelete="CASCADE"))
    rating: Mapped[int] = mapped_column(Integer)   # +1 helpful / -1 not helpful
    context: Mapped[Optional[str]] = mapped_column(String(40))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("rating IN (-1, 1)", name="ck_feedback_rating"),)


class ModelMetadata(Base):
    __tablename__ = "model_metadata"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60), index=True)
    version: Mapped[str] = mapped_column(String(40))
    trained_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime(timezone=True))
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    path: Mapped[Optional[str]] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
