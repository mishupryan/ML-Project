"""Application configuration. All values can be overridden with environment variables."""
import os
from dataclasses import dataclass, field
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
REPO_DIR = BACKEND_DIR.parent


DEV_SECRET = "dev-only-change-me-in-production-0123456789abcdef"


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


def _database_url() -> str:
    """DATABASE_URL, normalised for SQLAlchemy 2 + psycopg 3 (hosts such as Render/Heroku hand out postgres:// URLs)."""
    url = os.getenv("DATABASE_URL", f"sqlite:///{BACKEND_DIR / 'fitnutri.db'}").strip()
    if url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url[len("postgres://"):]
    elif url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]
    return url


@dataclass
class Settings:
    app_name: str = "FitNutri AI"
    environment: str = field(default_factory=lambda: os.getenv("APP_ENV", "development").strip().lower())
    database_url: str = field(default_factory=_database_url)
    secret_key: str = field(default_factory=lambda: os.getenv("SECRET_KEY", DEV_SECRET))
    access_token_expire_minutes: int = field(default_factory=lambda: int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "720")))
    cors_origins: list = field(default_factory=lambda: [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()])
    ml_model_dir: Path = field(default_factory=lambda: Path(os.getenv("ML_MODEL_DIR", str(REPO_DIR / "ml" / "models"))))
    ml_src_dir: Path = field(default_factory=lambda: Path(os.getenv("ML_SRC_DIR", str(REPO_DIR / "ml" / "src"))))
    frontend_dist: Path = field(default_factory=lambda: Path(os.getenv("FRONTEND_DIST", str(REPO_DIR / "frontend" / "dist"))))
    auto_create_tables: bool = field(default_factory=lambda: _bool("AUTO_CREATE_TABLES", False))
    default_timezone: str = field(default_factory=lambda: os.getenv("DEFAULT_TIMEZONE", "Asia/Kolkata"))
    currency: str = "INR"
    price_note: str = "Prices are illustrative estimates (India retail, per 100 g as purchased) and are user-editable; verify before budgeting."

    @property
    def is_production(self) -> bool:
        return self.environment in {"production", "prod"}

    def validate_for_production(self) -> None:
        """Refuse to boot a production instance with an insecure configuration."""
        if not self.is_production:
            return
        if self.secret_key == DEV_SECRET or len(self.secret_key) < 32:
            raise RuntimeError("APP_ENV=production requires SECRET_KEY to be set to a random value of at least 32 characters "
                               "(generate one with: python -c \"import secrets; print(secrets.token_urlsafe(48))\").")


settings = Settings()
