"""Password hashing, JWT handling and the current-user dependency."""
import datetime as dt
import uuid

import bcrypt
import jwt
from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from .errors import ApiError
from .models import RevokedToken, User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)
ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8")[:72], bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8")[:72], hashed.encode("utf-8"))
    except ValueError:
        return False


def create_access_token(user_id: int) -> tuple[str, dt.datetime]:
    exp = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=settings.access_token_expire_minutes)
    token = jwt.encode({"sub": str(user_id), "exp": exp, "jti": uuid.uuid4().hex}, settings.secret_key, algorithm=ALGORITHM)
    return token, exp


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise ApiError(401, "token_expired", "Your session has expired. Please log in again.")
    except jwt.PyJWTError:
        raise ApiError(401, "invalid_token", "Invalid authentication token.")


def get_current_user(token: str | None = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    if not token:
        raise ApiError(401, "not_authenticated", "Authentication required.")
    payload = decode_token(token)
    if db.get(RevokedToken, payload.get("jti")):
        raise ApiError(401, "token_revoked", "This session was logged out.")
    user = db.get(User, int(payload["sub"]))
    if not user or not user.is_active:
        raise ApiError(401, "invalid_token", "User not found or inactive.")
    return user
