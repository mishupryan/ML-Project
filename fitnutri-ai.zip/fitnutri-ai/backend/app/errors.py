"""Consistent error responses: {"error": {"code", "message", "details"}}."""
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str, details=None):
        self.status_code, self.code, self.message, self.details = status_code, code, message, details


def _resp(status: int, code: str, message: str, details=None):
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message, "details": details}})


def register_error_handlers(app: FastAPI):
    @app.exception_handler(ApiError)
    async def _api_error(_: Request, exc: ApiError):
        return _resp(exc.status_code, exc.code, exc.message, exc.details)

    @app.exception_handler(HTTPException)
    async def _http_error(_: Request, exc: HTTPException):
        return _resp(exc.status_code, "http_error", str(exc.detail))

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        details = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()]
        return _resp(422, "validation_error", "Some fields are invalid.", details)

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception):  # never leak internals
        return _resp(500, "internal_error", "Something went wrong on the server.")
