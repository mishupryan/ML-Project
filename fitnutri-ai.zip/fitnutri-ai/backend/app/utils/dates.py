import datetime as dt
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from ..config import settings


def tz_for(profile) -> ZoneInfo:
    name = (profile.timezone if profile and profile.timezone else settings.default_timezone)
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        return ZoneInfo("UTC")


def today_for(profile) -> dt.date:
    """'Today' in the user's own timezone (timezone-aware, not server-local)."""
    return dt.datetime.now(tz_for(profile)).date()


def daterange(start: dt.date, end: dt.date):
    d = start
    while d <= end:
        yield d
        d += dt.timedelta(days=1)
