"""Pure helpers: nutrient scaling, diet / allergen rules, serialisation of foods."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional

CORE_FIELDS = ["calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg"]
NUTRIENT_FIELDS = ["calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg", "sat_fat_g"]

DIET_ALLOWED = {
    "vegan": {"vegan"},
    "vegetarian": {"vegan", "vegetarian"},
    "eggetarian": {"vegan", "vegetarian", "eggetarian"},
    "pescatarian": {"vegan", "vegetarian", "eggetarian", "pescatarian"},
    "non_vegetarian": {"vegan", "vegetarian", "eggetarian", "pescatarian", "non_vegetarian"},
}
DIET_CHOICES = list(DIET_ALLOWED)
DIET_FLAGS = ["high_protein", "balanced", "indian_home_style", "mediterranean", "budget_friendly", "lactose_free", "gluten_free", "custom"]
ALLERGENS = ["milk", "egg", "fish", "shellfish", "peanut", "tree_nut", "soy", "gluten", "sesame", "mustard"]
_ALLERGY_SYNONYMS = {
    "dairy": {"milk"}, "lactose": {"milk"}, "milk": {"milk"}, "eggs": {"egg"}, "egg": {"egg"}, "fish": {"fish"},
    "seafood": {"fish", "shellfish"}, "shellfish": {"shellfish"}, "prawn": {"shellfish"}, "shrimp": {"shellfish"},
    "peanut": {"peanut"}, "peanuts": {"peanut"}, "nuts": {"peanut", "tree_nut"}, "nut": {"peanut", "tree_nut"},
    "tree nut": {"tree_nut"}, "tree_nut": {"tree_nut"}, "tree nuts": {"tree_nut"}, "almond": {"tree_nut"}, "soy": {"soy"}, "soya": {"soy"},
    "gluten": {"gluten"}, "wheat": {"gluten"}, "sesame": {"sesame"}, "mustard": {"mustard"},
}


def normalize_allergies(items: Iterable[str]) -> set[str]:
    out: set[str] = set()
    for a in items or []:
        key = str(a).strip().lower().replace("-", " ")
        out |= _ALLERGY_SYNONYMS.get(key, {key.replace(" ", "_")})
    return out


def scale_nutrients(food, quantity_g: float) -> dict:
    """Nutrition for `quantity_g` grams of `food` (values are stored per 100 g). Missing values stay None and are listed."""
    f = quantity_g / 100.0
    out, missing = {}, []
    for k in NUTRIENT_FIELDS:
        v = getattr(food, k, None)
        if v is None:
            out[k] = None
            if k != "sat_fat_g":
                missing.append(k)
        else:
            out[k] = round(v * f, 2)
    out["missing"] = missing
    return out


def completeness(food) -> float:
    return round(sum(getattr(food, k) is not None for k in CORE_FIELDS) / len(CORE_FIELDS), 2)


def cost_for(food, quantity_g: float) -> Optional[float]:
    if food.price_per_100g is None:
        return None
    return round(quantity_g / 100.0 * (food.purchase_factor or 1.0) * food.price_per_100g, 2)


def protein_per_100kcal(food) -> Optional[float]:
    if not food.calories or food.protein_g is None:
        return None
    return round(food.protein_g / food.calories * 100, 2)


def food_flags(food) -> dict:
    allergens = set(food.allergens or [])
    return {"gluten_free": bool(food.allergen_verified and "gluten" not in allergens),
            "lactose_free": bool(food.allergen_verified and "milk" not in allergens)}


def food_warnings(food) -> list[str]:
    w = []
    if not food.allergen_verified:
        w.append("Allergen information is not verified - do not rely on this food if you have allergies.")
    if food.diet_class == "unknown":
        w.append("Vegetarian/vegan classification is unknown.")
    if food.data_confidence == "imported-unverified":
        w.append("Imported record - values are unverified.")
    if food.is_illustrative:
        w.append("Illustrative approximate values - check your own product label.")
    miss = [k for k in CORE_FIELDS if getattr(food, k) is None]
    if miss:
        w.append("Missing nutrient data: " + ", ".join(miss))
    return w


def food_to_dict(food, quantity_g: Optional[float] = None) -> dict:
    d = {
        "id": food.id, "name": food.name, "brand": food.brand, "category": food.category,
        "serving_desc": food.serving_desc, "serving_g": food.serving_g, "unit_g": food.unit_g, "unit_name": food.unit_name,
        "per_100g": {k: getattr(food, k) for k in NUTRIENT_FIELDS},
        "micronutrients": food.micronutrients, "ingredients": food.ingredients,
        "allergens": food.allergens or [], "allergen_verified": food.allergen_verified,
        "diet_class": food.diet_class, "diet_verified": food.diet_verified, "cuisine": food.cuisine,
        "meal_roles": food.meal_roles or [], "tags": food.tags or [], "prep_time_min": food.prep_time_min, "prep_note": food.prep_note,
        "price_per_100g": food.price_per_100g, "purchase_factor": food.purchase_factor, "price_source": food.price_source,
        "price_updated": food.price_updated.isoformat() if food.price_updated else None,
        "price_per_serving": cost_for(food, food.serving_g),
        "data_source": food.data_source, "data_confidence": food.data_confidence, "is_custom": food.is_custom,
        "is_illustrative": food.is_illustrative, "completeness": completeness(food),
        "protein_per_100kcal": protein_per_100kcal(food), "flags": food_flags(food), "warnings": food_warnings(food),
    }
    if quantity_g is not None:
        d["quantity_g"] = quantity_g
        d["scaled"] = scale_nutrients(food, quantity_g)
        d["scaled_cost_inr"] = cost_for(food, quantity_g)
    return d


@dataclass
class Constraints:
    diet: str = "non_vegetarian"
    allergies: set = field(default_factory=set)
    disliked: list = field(default_factory=list)
    lactose_free: bool = False
    gluten_free: bool = False
    strict: bool = True           # planner / recommender: unverified info is rejected when it matters
    cuisine_only: Optional[str] = None
    max_prep_min: Optional[int] = None
    require_no_cook: bool = False
    exclude_ids: set = field(default_factory=set)
    only_ids: Optional[set] = None

    @classmethod
    def from_profile(cls, profile, **over) -> "Constraints":
        flags = set(profile.diet_flags or []) if profile else set()
        c = cls(
            diet=(profile.diet_preference if profile and profile.diet_preference in DIET_ALLOWED else "non_vegetarian"),
            allergies=normalize_allergies(profile.allergies if profile else []),
            disliked=[d.strip().lower() for d in (profile.disliked_foods if profile else []) if d and d.strip()],
            lactose_free="lactose_free" in flags, gluten_free="gluten_free" in flags,
        )
        for k, v in over.items():
            setattr(c, k, v)
        return c

    def check(self, food) -> tuple[bool, list[str]]:
        """Returns (allowed, reasons_for_rejection)."""
        why = []
        if self.only_ids is not None and food.id not in self.only_ids:
            why.append("not in the allowed list")
        if food.id in self.exclude_ids:
            why.append("excluded")
        allowed_classes = DIET_ALLOWED.get(self.diet, DIET_ALLOWED["non_vegetarian"])
        if food.diet_class not in allowed_classes:
            if food.diet_class == "unknown":
                if self.strict and self.diet != "non_vegetarian":
                    why.append("diet classification unknown")
            else:
                why.append(f"not {self.diet.replace('_', '-')}")
        fa = set(food.allergens or [])
        if self.allergies:
            hit = fa & self.allergies
            if hit:
                why.append("contains " + "/".join(sorted(hit)))
            elif self.strict and not food.allergen_verified:
                why.append("allergen info unverified")
        if self.lactose_free and ("milk" in fa or (self.strict and not food.allergen_verified)):
            why.append("not lactose-free")
        if self.gluten_free and ("gluten" in fa or (self.strict and not food.allergen_verified)):
            why.append("not gluten-free")
        nm = food.name.lower()
        if any(d in nm for d in self.disliked):
            why.append("disliked food")
        if self.cuisine_only and (food.cuisine or "").lower() not in (self.cuisine_only, "international"):
            why.append("cuisine filter")
        if self.max_prep_min is not None and (food.prep_time_min is None or food.prep_time_min > self.max_prep_min):
            why.append("preparation time too long")
        if self.require_no_cook and "no_cook" not in (food.tags or []):
            why.append("needs cooking")
        return (not why, why)
