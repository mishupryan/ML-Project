from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import Food, User
from ..schemas.food import FoodIn, FoodUpdate
from ..security import get_current_user
from ..utils.foodlogic import ALLERGENS, DIET_ALLOWED, cost_for, food_to_dict, normalize_allergies, protein_per_100kcal

router = APIRouter(prefix="/api/foods", tags=["foods"])


def visible(db: Session, user: User):
    return db.query(Food).filter(or_(Food.owner_user_id.is_(None), Food.owner_user_id == user.id))


@router.get("/categories")
def categories(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = visible(db, user).with_entities(Food.category).distinct().order_by(Food.category).all()
    return {"categories": [r[0] for r in rows], "allergens": ALLERGENS, "diets": list(DIET_ALLOWED)}


@router.get("")
def search_foods(q: Optional[str] = None, category: Optional[str] = None, min_protein: Optional[float] = None, max_calories: Optional[float] = None,
                 min_protein_per_100kcal: Optional[float] = None, max_carbs: Optional[float] = None, max_fat: Optional[float] = None,
                 min_fiber: Optional[float] = None, diet: Optional[str] = None, exclude_allergens: Optional[str] = None,
                 max_price_per_serving: Optional[float] = None, max_prep_min: Optional[int] = None,
                 source: str = Query("all", pattern="^(all|curated|imported|custom)$"), include_unverified: bool = False,
                 quantity_g: Optional[float] = Query(None, gt=0, le=10000),
                 sort: str = Query("relevance", pattern="^(relevance|name|protein|protein_density|calories|price)$"),
                 limit: int = Query(25, ge=1, le=100), offset: int = Query(0, ge=0),
                 user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    qry = visible(db, user)
    if q:
        for term in q.strip().split():
            qry = qry.filter(Food.name.ilike(f"%{term}%"))
    if category:
        qry = qry.filter(Food.category == category)
    if max_calories is not None:
        qry = qry.filter(Food.calories <= max_calories)
    if min_protein is not None:
        qry = qry.filter(Food.protein_g >= min_protein)
    if max_carbs is not None:
        qry = qry.filter(Food.carbs_g <= max_carbs)
    if max_fat is not None:
        qry = qry.filter(Food.fat_g <= max_fat)
    if min_fiber is not None:
        qry = qry.filter(Food.fiber_g >= min_fiber)
    if max_prep_min is not None:
        qry = qry.filter(Food.prep_time_min <= max_prep_min)
    if source == "curated":
        qry = qry.filter(Food.data_confidence == "curated-approximate")
    elif source == "imported":
        qry = qry.filter(Food.data_confidence == "imported-unverified")
    elif source == "custom":
        qry = qry.filter(Food.is_custom.is_(True))
    foods = qry.limit(5000).all()
    if diet:
        if diet not in DIET_ALLOWED:
            raise ApiError(422, "invalid_diet", f"diet must be one of {list(DIET_ALLOWED)}")
        ok = DIET_ALLOWED[diet]
        foods = [f for f in foods if f.diet_class in ok or (include_unverified and f.diet_class == "unknown")]
    if exclude_allergens:
        al = normalize_allergies(exclude_allergens.split(","))
        foods = [f for f in foods if not (set(f.allergens or []) & al) and (f.allergen_verified or include_unverified)]
    if min_protein_per_100kcal is not None:
        foods = [f for f in foods if (protein_per_100kcal(f) or 0) >= min_protein_per_100kcal]
    if max_price_per_serving is not None:
        foods = [f for f in foods if (c := cost_for(f, f.serving_g)) is not None and c <= max_price_per_serving]
    ql = (q or "").strip().lower()

    def rel(f):
        n = f.name.lower()
        return (0 if f.data_confidence == "curated-approximate" else 1 if f.is_custom else 2, 0 if n.startswith(ql) else 1, len(n), n)
    keyf = {"relevance": rel, "name": lambda f: f.name.lower(), "protein": lambda f: -(f.protein_g or 0),
            "protein_density": lambda f: -(protein_per_100kcal(f) or 0), "calories": lambda f: f.calories,
            "price": lambda f: cost_for(f, f.serving_g) if cost_for(f, f.serving_g) is not None else 1e9}[sort]
    foods.sort(key=keyf)
    total = len(foods)
    page = foods[offset: offset + limit]
    return {"total": total, "limit": limit, "offset": offset, "items": [food_to_dict(f, quantity_g) for f in page]}


@router.get("/{food_id}")
def get_food(food_id: int, quantity_g: Optional[float] = Query(None, gt=0, le=10000), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    f = visible(db, user).filter(Food.id == food_id).first()
    if not f:
        raise ApiError(404, "food_not_found", "Food not found.")
    return food_to_dict(f, quantity_g)


@router.post("", status_code=201)
def create_food(body: FoodIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = body.model_dump()
    f = Food(**data, is_custom=True, owner_user_id=user.id, data_source="user entered", data_confidence="user-custom",
             diet_verified=data["diet_class"] != "unknown", meal_roles=[], tags=[], purchase_factor=1.0,
             price_source="user entered" if data.get("price_per_100g") is not None else None)
    db.add(f); db.commit(); db.refresh(f)
    return food_to_dict(f)


def _own(db: Session, user: User, food_id: int) -> Food:
    f = db.get(Food, food_id)
    if not f or f.owner_user_id != user.id:
        raise ApiError(404, "food_not_found", "Custom food not found (built-in foods cannot be edited).")
    return f


@router.put("/{food_id}")
def update_food(food_id: int, body: FoodUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    f = _own(db, user, food_id)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(f, k, v)
    db.commit(); db.refresh(f)
    return food_to_dict(f)


@router.delete("/{food_id}", status_code=204)
def delete_food(food_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    f = _own(db, user, food_id)
    db.delete(f); db.commit()
