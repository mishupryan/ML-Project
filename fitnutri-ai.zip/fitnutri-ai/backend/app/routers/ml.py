from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import Food, User
from ..schemas.misc import PredictIn
from ..security import get_current_user
from ..services import ml_service
from ..services.diary import visible_food

router = APIRouter(prefix="/api/ml", tags=["ml"])


def _nutrients(body: PredictIn, db: Session, user: User) -> tuple[dict, str | None]:
    if body.nutrients:
        return body.nutrients.model_dump(), None
    f: Food = visible_food(db, user, body.food_id)
    return {"calories": f.calories, "protein_g": f.protein_g, "fat_g": f.fat_g, "carbs_g": f.carbs_g, "fiber_g": f.fiber_g, "sugar_g": f.sugar_g,
            "sodium_mg": f.sodium_mg}, f.name


@router.get("/status")
def status(user: User = Depends(get_current_user)):
    return {"models": ml_service.status(), "recommendation_ranking": {
        "method": "transparent rule-based scoring", "ml_ranking": "not trained",
        "reason": "A learned ranking needs real labelled user interactions; none exist yet. Thumbs up/down feedback is being collected."}}


@router.get("/metrics")
def metrics(task: str = Query("food_category", pattern="^(food_category|health_score)$"), user: User = Depends(get_current_user)):
    m = ml_service.metrics(task)
    if m is None:
        raise ApiError(404, "model_not_trained", "No trained model/metrics found. Run scripts/train_models.py or the Colab notebook.")
    return m


@router.post("/predict-food-category")
def predict_food_category(body: PredictIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    nut, name = _nutrients(body, db, user)
    r = ml_service.predict("food_category", nut, db)
    r["input_food"] = name
    return r


@router.post("/predict-health-score")
def predict_health_score(body: PredictIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    nut, name = _nutrients(body, db, user)
    r = ml_service.predict("health_score", nut, db)
    r["input_food"] = name
    r["note"] = "health_score appears to be rule-derived in the training data; treat as a research output."
    return r
