from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import Food, MealPlan, MealPlanMeal, User
from ..schemas.misc import (AlternativesIn, ApplyItemsIn, LogPlanMealIn, PlanRequest, PlanUpdate, RegenMealIn, ReplaceIn, SwapIn)
from ..security import get_current_user
from ..services import diary as dsvc
from ..services import planner
from ..utils.dates import today_for

router = APIRouter(prefix="/api/meal-plans", tags=["meal-plans"])


def _plan(db: Session, user: User, plan_id: int) -> MealPlan:
    p = db.get(MealPlan, plan_id)
    if not p or p.user_id != user.id:
        raise ApiError(404, "plan_not_found", "Meal plan not found.")
    return p


def _meal(plan: MealPlan, meal_id: int) -> MealPlanMeal:
    for d in plan.days:
        for m in d.meals:
            if m.id == meal_id:
                return m
    raise ApiError(404, "meal_not_found", "Meal not found in this plan.")


@router.get("/plan-types")
def plan_types():
    return {"items": [{"key": k, "label": v["label"], "description": v["desc"], "goal": v.get("goal"), "diet": v.get("diet")} for k, v in planner.PLAN_TYPES.items()]}


@router.post("/generate", status_code=201)
def generate(body: PlanRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = planner.generate_plan(db, user, body.model_dump())
    return planner.plan_dict(plan)


@router.get("")
def list_plans(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plans = db.query(MealPlan).filter_by(user_id=user.id).order_by(MealPlan.id.desc()).all()
    return {"items": [planner.plan_dict(p, detail=False) for p in plans]}


@router.get("/{plan_id}")
def get_plan(plan_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return planner.plan_dict(_plan(db, user, plan_id))


@router.put("/{plan_id}")
def update_plan(plan_id: int, body: PlanUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = _plan(db, user, plan_id)
    for k, v in body.model_dump(exclude_unset=True).items():
        if v is not None:
            setattr(p, k, v)
    db.commit(); db.refresh(p)
    return planner.plan_dict(p, detail=False)


@router.delete("/{plan_id}", status_code=204)
def delete_plan(plan_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(_plan(db, user, plan_id)); db.commit()


@router.post("/{plan_id}/meals/{meal_id}/alternatives")
def meal_alternatives(plan_id: int, meal_id: int, body: AlternativesIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    m = _meal(plan, meal_id)
    alts = planner.alternatives(db, user, plan, m, body.count)
    return {"meal_id": m.id, "slot": m.slot, "current": {"name": m.name}, "alternatives": alts,
            "note": "Compare totals, cost and prep time, then apply one with PUT /meals/{meal_id}/items."}


@router.put("/{plan_id}/meals/{meal_id}/items")
def apply_items(plan_id: int, meal_id: int, body: ApplyItemsIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    m = _meal(plan, meal_id)
    planner.apply_meal_items(db, user, plan, m, [i.model_dump() for i in body.items])
    db.commit(); db.refresh(plan)
    planner.recompute_cost(plan); db.commit()
    return planner.plan_dict(plan)


@router.post("/{plan_id}/regenerate-meal")
def regenerate_meal(plan_id: int, body: RegenMealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    day = next((d for d in plan.days if d.day_index == body.day_index), None)
    meal = next((m for m in (day.meals if day else []) if m.slot == body.slot), None)
    if not meal:
        raise ApiError(404, "meal_not_found", "No such meal in this plan.")
    alts = planner.alternatives(db, user, plan, meal, 1)
    if not alts:
        raise ApiError(422, "no_alternative", "No different meal could be built under your constraints.")
    planner.apply_meal_items(db, user, plan, meal, [{"food_id": i["food_id"], "quantity_g": i["quantity_g"], "role": i["role"]} for i in alts[0]["items"]])
    db.commit(); db.refresh(plan)
    planner.recompute_cost(plan); db.commit()
    return planner.plan_dict(plan)


@router.post("/{plan_id}/items/{item_id}/replace")
def replace_item(plan_id: int, item_id: int, body: ReplaceIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    item = next((i for d in plan.days for m in d.meals for i in m.items if i.id == item_id), None)
    if not item:
        raise ApiError(404, "item_not_found", "Item not found in this plan.")
    new_food = db.get(Food, body.food_id)
    if not new_food or (new_food.owner_user_id not in (None, user.id)):
        raise ApiError(404, "food_not_found", "Food not found.")
    info = planner.replace_ingredient(db, user, plan, item, new_food, body.quantity_g)
    db.commit(); db.refresh(plan)
    planner.recompute_cost(plan); db.commit()
    return {"result": info, "plan": planner.plan_dict(plan)}


@router.post("/{plan_id}/swap-meals")
def swap_meals(plan_id: int, body: SwapIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    a, b = _meal(plan, body.meal_id_a), _meal(plan, body.meal_id_b)
    if a.slot != b.slot:
        raise ApiError(422, "slot_mismatch", "Only meals in the same slot (e.g. dinner on two days) can be swapped, so calorie targets stay consistent.")
    a.day_id, b.day_id = b.day_id, a.day_id
    db.commit(); db.refresh(plan)
    return planner.plan_dict(plan)


@router.post("/{plan_id}/meals/{meal_id}/log", status_code=201)
def log_plan_meal(plan_id: int, meal_id: int, body: LogPlanMealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = _plan(db, user, plan_id)
    m = _meal(plan, meal_id)
    day = body.log_date or today_for(user.profile)
    mt = body.meal_type or (m.slot if m.slot in ("breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner", "custom") else "custom")
    for it in m.items:
        dsvc.create_entry(db, user, it.food, log_date=day, meal_type=mt, quantity_g=it.quantity_g)
    db.commit()
    return {"logged": len(m.items), "meal_type": mt, "date": day.isoformat()}
