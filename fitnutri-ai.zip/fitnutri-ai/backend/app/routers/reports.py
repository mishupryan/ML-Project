import csv
import datetime as dt
import io
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..security import get_current_user
from ..services.reports import weekly_report
from ..utils.dates import today_for

router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.get("/weekly")
def weekly(end_date: Optional[dt.date] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return weekly_report(db, user, end_date or today_for(user.profile))


@router.get("/weekly.csv")
def weekly_csv(end_date: Optional[dt.date] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = weekly_report(db, user, end_date or today_for(user.profile))
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["date", "logged", "calories", "protein_g", "carbs_g", "fat_g", "fiber_g"])
    for d in r["days"]:
        w.writerow([d["date"], "yes" if d["logged"] else "no", *["" if d[k] is None else d[k] for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")]])
    w.writerow([]); w.writerow(["average (logged days only)", "", *[r["averages_logged_days"][k] for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")]])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=weekly_report.csv"})
