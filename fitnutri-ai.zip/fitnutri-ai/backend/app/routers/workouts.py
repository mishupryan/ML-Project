import datetime as dt
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import User, Workout, WorkoutExercise
from ..schemas.misc import WorkoutIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..utils.dates import today_for

router = APIRouter(prefix="/api/workouts", tags=["workouts"])


def wdict(w: Workout) -> dict:
    vol = sum((e.sets or 0) * (e.reps or 0) * (e.weight_kg or 0) for e in w.exercises)
    return {"id": w.id, "workout_date": w.workout_date.isoformat(), "workout_type": w.workout_type, "duration_min": w.duration_min,
            "perceived_exertion": w.perceived_exertion, "notes": w.notes, "total_volume_kg": round(vol, 1),
            "exercises": [{"id": e.id, "name": e.name, "sets": e.sets, "reps": e.reps, "weight_kg": e.weight_kg} for e in w.exercises]}


@router.post("", status_code=201)
def add_workout(body: WorkoutIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    w = Workout(user_id=user.id, workout_date=body.workout_date or today_for(user.profile), workout_type=body.workout_type,
                duration_min=body.duration_min, perceived_exertion=body.perceived_exertion, notes=body.notes)
    for e in body.exercises:
        w.exercises.append(WorkoutExercise(**e.model_dump()))
    db.add(w); db.commit(); db.refresh(w)
    return wdict(w)


@router.get("/summary")
def summary(weeks: int = Query(8, ge=1, le=26), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Weekly workout volume next to average logged nutrition. Shown side by side only - no causal claims."""
    today = today_for(user.profile)
    start = today - dt.timedelta(days=weeks * 7 - 1)
    ws = db.query(Workout).filter(Workout.user_id == user.id, Workout.workout_date >= start).all()
    es = dsvc.entries_between(db, user.id, start, today)
    per_day = dsvc.by_day(es)
    out = []
    for i in range(weeks):
        a = start + dt.timedelta(days=7 * i)
        b = a + dt.timedelta(days=6)
        wk = [w for w in ws if a <= w.workout_date <= b]
        days = [dsvc.totals(v) for d, v in per_day.items() if a <= d <= b]
        rpe = [w.perceived_exertion for w in wk if w.perceived_exertion]
        out.append({"week_start": a.isoformat(), "sessions": len(wk), "total_minutes": sum(w.duration_min or 0 for w in wk),
                    "volume_kg": round(sum(sum((e.sets or 0) * (e.reps or 0) * (e.weight_kg or 0) for e in w.exercises) for w in wk), 0),
                    "avg_exertion": round(sum(rpe) / len(rpe), 1) if rpe else None,
                    "days_food_logged": len(days), "avg_calories_logged_days": round(sum(d["calories"] for d in days) / len(days)) if days else None,
                    "avg_protein_logged_days": round(sum(d["protein_g"] for d in days) / len(days), 1) if days else None})
    return {"weeks": out, "note": "Nutrition and training are shown side by side for your own review; this does not show that either caused the other."}


@router.get("")
def list_workouts(start: Optional[dt.date] = None, end: Optional[dt.date] = None, limit: int = Query(50, ge=1, le=500),
                  user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(Workout).filter_by(user_id=user.id)
    if start:
        q = q.filter(Workout.workout_date >= start)
    if end:
        q = q.filter(Workout.workout_date <= end)
    return {"items": [wdict(w) for w in q.order_by(Workout.workout_date.desc(), Workout.id.desc()).limit(limit).all()]}


@router.delete("/{wid}", status_code=204)
def delete_workout(wid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    w = db.get(Workout, wid)
    if not w or w.user_id != user.id:
        raise ApiError(404, "not_found", "Workout not found.")
    db.delete(w); db.commit()
