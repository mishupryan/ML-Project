from fastapi import APIRouter, Depends
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import FoodDiaryEntry, Recipe, RecipeIngredient, User
from ..schemas.misc import RecipeIn, RecipeLogIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..utils.dates import today_for
from ..utils.foodlogic import cost_for, scale_nutrients

router = APIRouter(prefix="/api/recipes", tags=["recipes"])
KEYS = ["calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg"]


def recipe_dict(r: Recipe) -> dict:
    tot = {k: 0.0 for k in KEYS}
    missing, ings, cost, cost_missing = set(), [], 0.0, False
    for i in r.ingredients:
        n = scale_nutrients(i.food, i.quantity_g)
        for k in KEYS:
            tot[k] += n[k] or 0
        for m in n["missing"]:
            missing.add(f"{i.food.name}: {m}")
        c = cost_for(i.food, i.quantity_g)
        if c is None:
            cost_missing = True
        cost += c or 0
        ings.append({"id": i.id, "food_id": i.food_id, "food_name": i.food.name, "quantity_g": i.quantity_g, "nutrients": n, "cost_inr": c})
    s = r.servings or 1
    return {"id": r.id, "name": r.name, "servings": r.servings, "instructions": r.instructions, "prep_time_min": r.prep_time_min, "ingredients": ings,
            "total": {k: round(v, 1) for k, v in tot.items()}, "per_serving": {k: round(v / s, 1) for k, v in tot.items()},
            "total_weight_g": round(sum(i.quantity_g for i in r.ingredients), 1), "cost_total_inr": round(cost, 1), "cost_per_serving_inr": round(cost / s, 1),
            "cost_incomplete": cost_missing, "missing_data": sorted(missing),
            "warnings": (["Some ingredients have missing nutrient values; totals may be underestimated."] if missing else [])}


def _recipe(db, user, rid) -> Recipe:
    r = db.get(Recipe, rid)
    if not r or r.user_id != user.id:
        raise ApiError(404, "recipe_not_found", "Recipe not found.")
    return r


def _fill(db, user, r: Recipe, body: RecipeIn):
    r.name, r.servings, r.instructions, r.prep_time_min = body.name, body.servings, body.instructions, body.prep_time_min
    r.ingredients.clear(); db.flush()
    for i in body.ingredients:
        dsvc.visible_food(db, user, i.food_id)
        r.ingredients.append(RecipeIngredient(food_id=i.food_id, quantity_g=i.quantity_g))


@router.get("")
def list_recipes(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {"items": [recipe_dict(r) for r in db.query(Recipe).filter_by(user_id=user.id).order_by(Recipe.id.desc()).all()]}


@router.post("", status_code=201)
def create_recipe(body: RecipeIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = Recipe(user_id=user.id, name=body.name)
    db.add(r); _fill(db, user, r, body); db.commit(); db.refresh(r)
    return recipe_dict(r)


@router.get("/{recipe_id}")
def get_recipe(recipe_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return recipe_dict(_recipe(db, user, recipe_id))


@router.put("/{recipe_id}")
def update_recipe(recipe_id: int, body: RecipeIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = _recipe(db, user, recipe_id)
    _fill(db, user, r, body); db.commit(); db.refresh(r)
    return recipe_dict(r)


@router.delete("/{recipe_id}", status_code=204)
def delete_recipe(recipe_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(_recipe(db, user, recipe_id)); db.commit()


@router.post("/{recipe_id}/log", status_code=201)
def log_recipe(recipe_id: int, body: RecipeLogIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = _recipe(db, user, recipe_id)
    d = recipe_dict(r)
    ps = d["per_serving"]
    f = body.servings
    e = FoodDiaryEntry(user_id=user.id, food_id=None, recipe_id=r.id, label=r.name, log_date=body.log_date or today_for(user.profile), meal_type=body.meal_type,
                       quantity_g=round(d["total_weight_g"] / (r.servings or 1) * f, 1), servings=f, calories=ps["calories"] * f, protein_g=ps["protein_g"] * f,
                       carbs_g=ps["carbs_g"] * f, fat_g=ps["fat_g"] * f, fiber_g=ps["fiber_g"] * f, sugar_g=ps["sugar_g"] * f, sodium_mg=ps["sodium_mg"] * f,
                       cost_inr=None if d["cost_incomplete"] else d["cost_per_serving_inr"] * f, missing_nutrients=sorted({m.split(": ")[1] for m in d["missing_data"]}))
    db.add(e); db.commit(); db.refresh(e)
    return dsvc.entry_dict(e)


@router.get("/{recipe_id}/export", response_class=PlainTextResponse)
def export_recipe(recipe_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    d = recipe_dict(_recipe(db, user, recipe_id))
    lines = [f"# {d['name']}", f"Servings: {d['servings']:g}   Prep time: {d['prep_time_min'] or '-'} min", "", "## Ingredients"]
    lines += [f"- {i['food_name']}: {i['quantity_g']:g} g" for i in d["ingredients"]]
    p = d["per_serving"]
    lines += ["", "## Nutrition per serving", f"{p['calories']:g} kcal | protein {p['protein_g']:g} g | carbs {p['carbs_g']:g} g | fat {p['fat_g']:g} g | fibre {p['fiber_g']:g} g",
              "", "## Instructions", d["instructions"] or "(none)"]
    if d["missing_data"]:
        lines += ["", "Note: missing nutrient data for: " + "; ".join(d["missing_data"])]
    return "\n".join(lines)
