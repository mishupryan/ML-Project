import datetime as dt
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import RecommendationFeedback, User
from ..schemas.misc import FeedbackIn, SubstitutionIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..services import recommender as rec
from ..services import substitutions as subs
from ..services import targets as tsvc
from ..services.context import nutrient_summary
from ..utils.dates import today_for

router = APIRouter(prefix="/api/recommendations", tags=["recommendations"])


@router.get("/foods")
def recommend_foods(context: str = Query("general", pattern="^(general|pre_workout|post_workout|budget|quick|high_fiber|high_protein)$"),
                    limit: int = Query(8, ge=1, le=30), date: Optional[dt.date] = None, max_prep_min: Optional[int] = Query(None, ge=0, le=240),
                    category: Optional[str] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    day = date or today_for(user.profile)
    td = dsvc.build_day(db, user, day)
    t = tsvc.target_dict(tsvc.get_targets(db, user))
    rem = rec.remaining_gap(t, td["totals"])
    res = rec.recommend(db, user, rem=rem, day=day, context=context, limit=limit, max_prep_min=max_prep_min, category=category)
    res["consumed_so_far"] = {k: v for k, v in td["totals"].items() if k != "incomplete_entries"}
    return res


@router.get("/top-foods")
def top_foods(goal: Optional[str] = None, limit: int = Query(15, ge=1, le=50), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return rec.top_foods_for_goal(db, user, goal or user.profile.goal or "general_fitness", limit)


@router.post("/substitutions")
def substitutions(body: SubstitutionIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    food = dsvc.visible_food(db, user, body.food_id)
    opts = subs.substitute(db, user, food, body.quantity_g, match=body.match, limit=body.limit)
    return {"original": {"food": food.name, "quantity_g": body.quantity_g, "nutrients": nutrient_summary(food, body.quantity_g)},
            "matched_on": body.match, "alternatives": opts,
            "note": "Alternatives respect your diet, allergies and dislikes. Quantities are matched on " + body.match + "; other nutrients will differ.",
            "empty_reason": None if opts else "No compatible alternative was found under your diet/allergy settings."}


@router.post("/feedback", status_code=201)
def feedback(body: FeedbackIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    dsvc.visible_food(db, user, body.food_id)
    db.add(RecommendationFeedback(user_id=user.id, food_id=body.food_id, rating=body.rating, context=body.context))
    db.commit()
    return {"ok": True, "message": "Thanks - your feedback adjusts the preference component of future rankings."}
