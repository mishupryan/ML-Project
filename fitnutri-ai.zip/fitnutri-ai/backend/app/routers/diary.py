import csv
import datetime as dt
import io
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import FoodDiaryEntry, User
from ..schemas.food import CopyDiaryIn, DiaryIn, DiaryUpdate, DuplicateMealIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..utils.dates import today_for

router = APIRouter(prefix="/api/diary", tags=["diary"])


def _entry(db: Session, user: User, entry_id: int) -> FoodDiaryEntry:
    e = db.get(FoodDiaryEntry, entry_id)
    if not e or e.user_id != user.id:                      # same response for "missing" and "not yours"
        raise ApiError(404, "entry_not_found", "Diary entry not found.")
    return e


@router.get("")
def list_diary(date: Optional[dt.date] = None, start: Optional[dt.date] = None, end: Optional[dt.date] = None,
               user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if start or end:
        s, e = start or end, end or start
        if (e - s).days > 366:
            raise ApiError(422, "range_too_large", "Date range cannot exceed one year.")
        days = dsvc.by_day(dsvc.entries_between(db, user.id, s, e))
        return {"days": [{"date": d.isoformat(), "totals": dsvc.totals(es), "entries": [dsvc.entry_dict(x) for x in es]} for d, es in sorted(days.items())]}
    return dsvc.build_day(db, user, date or today_for(user.profile))


@router.post("", status_code=201)
def add_entry(body: DiaryIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    food = dsvc.visible_food(db, user, body.food_id)
    e = dsvc.create_entry(db, user, food, log_date=body.log_date or today_for(user.profile), meal_type=body.meal_type,
                          quantity_g=body.quantity_g, servings=body.servings, notes=body.notes)
    db.commit(); db.refresh(e)
    return dsvc.entry_dict(e)


@router.put("/{entry_id}")
def update_entry(entry_id: int, body: DiaryUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    e = _entry(db, user, entry_id)
    data = body.model_dump(exclude_unset=True)
    if "servings" in data and "quantity_g" not in data and e.food:
        data["quantity_g"] = round(data["servings"] * e.food.serving_g, 2)
    old_q = e.quantity_g
    for k, v in data.items():
        if v is not None:
            setattr(e, k, v)
    if e.quantity_g != old_q:
        if e.food:
            dsvc.fill_entry_from_food(e, e.food)
        else:                                               # recipe / deleted food: scale the stored snapshot
            r = e.quantity_g / old_q
            for k in ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg", "cost_inr"):
                v = getattr(e, k)
                setattr(e, k, None if v is None else v * r)
    db.commit(); db.refresh(e)
    return dsvc.entry_dict(e)


@router.delete("/{entry_id}", status_code=204)
def delete_entry(entry_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    e = _entry(db, user, entry_id)
    db.delete(e); db.commit()


def _clone(db, user, src: FoodDiaryEntry, log_date, meal_type):
    n = FoodDiaryEntry(user_id=user.id, food_id=src.food_id, recipe_id=src.recipe_id, label=src.label, log_date=log_date, meal_type=meal_type,
                       quantity_g=src.quantity_g, servings=src.servings, calories=src.calories, protein_g=src.protein_g, carbs_g=src.carbs_g,
                       fat_g=src.fat_g, fiber_g=src.fiber_g, sugar_g=src.sugar_g, sodium_mg=src.sodium_mg, cost_inr=src.cost_inr,
                       missing_nutrients=src.missing_nutrients, notes=src.notes)
    db.add(n)
    return n


@router.post("/copy", status_code=201)
def copy_day(body: CopyDiaryIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Copy all (or one meal's) entries from another day."""
    q = db.query(FoodDiaryEntry).filter_by(user_id=user.id, log_date=body.from_date)
    if body.meal_type:
        q = q.filter_by(meal_type=body.meal_type)
    src = q.all()
    if not src:
        raise ApiError(404, "nothing_to_copy", "No entries found on the source day.")
    new = [_clone(db, user, s, body.to_date, s.meal_type) for s in src]
    db.commit()
    return {"copied": len(new)}


@router.post("/duplicate-meal", status_code=201)
def duplicate_meal(body: DuplicateMealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    src = db.query(FoodDiaryEntry).filter_by(user_id=user.id, log_date=body.date, meal_type=body.meal_type).all()
    if not src:
        raise ApiError(404, "nothing_to_copy", "That meal has no entries.")
    for s in src:
        _clone(db, user, s, body.to_date or body.date, body.to_meal_type or body.meal_type)
    db.commit()
    return {"copied": len(src)}


@router.get("/export.csv")
def export_csv(start: Optional[dt.date] = None, end: Optional[dt.date] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = start or dt.date(2000, 1, 1)
    e = end or dt.date(2100, 1, 1)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["date", "meal_type", "food", "quantity_g", "calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "sugar_g", "sodium_mg", "cost_inr"])
    for x in dsvc.entries_between(db, user.id, s, e):
        w.writerow([x.log_date, x.meal_type, x.label, x.quantity_g, x.calories, x.protein_g, x.carbs_g, x.fat_g, x.fiber_g, x.sugar_g, x.sodium_mg, x.cost_inr])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=food_diary.csv"})
