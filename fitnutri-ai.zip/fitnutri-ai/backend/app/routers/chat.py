from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..schemas.misc import ChatIn
from ..security import get_current_user
from ..services import chat

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("")
def send(body: ChatIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return chat.respond(db, user, body.message)


@router.get("/examples")
def examples(user: User = Depends(get_current_user)):
    return {"examples": ["What can I eat to reach my protein target today?", "Suggest a vegetarian muscle-gain meal", "Give me three inexpensive high-protein dinner options",
                         "Replace eggs in my breakfast", "Create a meal plan using rice, dal, paneer and vegetables", "Compare paneer and tofu", "Why am I missing my fiber target?",
                         "What should I eat after a workout?"]}
