from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, WeightLog
from ..schemas.user import ProfileIn
from ..security import get_current_user
from ..services import nutrition_calc as nc
from ..services import targets as tsvc
from ..utils.dates import today_for

router = APIRouter(prefix="/api/profile", tags=["profile"])

FIELDS = ["age", "sex", "height_cm", "weight_kg", "target_weight_kg", "activity_level", "goal", "diet_preference", "diet_flags", "allergies",
          "liked_foods", "disliked_foods", "preferred_cuisine", "meals_per_day", "daily_budget", "cooking_equipment", "cooking_time_pref_min",
          "workout_days", "workout_time", "wake_time", "sleep_time", "medical_or_pregnancy_flag", "eating_disorder_concern", "water_enabled",
          "water_target_ml", "timezone"]
LIST_FIELDS = ("diet_flags", "allergies", "liked_foods", "disliked_foods", "cooking_equipment", "workout_days")


def profile_dict(user: User) -> dict:
    p = user.profile
    d = {k: getattr(p, k) for k in FIELDS}
    d.update({"display_name": user.display_name, "email": user.email, "restrictions": nc.is_restricted(p), "complete_for_targets": tsvc.profile_ready(p)})
    return d


@router.get("")
def get_profile(user: User = Depends(get_current_user)):
    return profile_dict(user)


@router.put("")
def update_profile(body: ProfileIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = body.model_dump(exclude_unset=True)
    p = user.profile
    old_weight = p.weight_kg
    for k, v in data.items():
        if v is None and k in LIST_FIELDS:
            v = []
        setattr(p, k, v)
    db.commit()
    if data.get("weight_kg") and data["weight_kg"] != old_weight:   # keep the progress tracker in sync
        day = today_for(p)
        wl = db.query(WeightLog).filter_by(user_id=user.id, log_date=day).first()
        if wl:
            wl.weight_kg = data["weight_kg"]
        else:
            db.add(WeightLog(user_id=user.id, log_date=day, weight_kg=data["weight_kg"], note="from profile"))
        db.commit()
    t = tsvc.recompute_targets(db, user)
    db.refresh(user)
    return {"profile": profile_dict(user), "targets": tsvc.target_dict(t)}
