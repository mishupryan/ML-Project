from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import RevokedToken, User, UserProfile
from ..schemas.user import LoginIn, RegisterIn, TokenOut, UserOut
from ..security import (create_access_token, decode_token, get_current_user, hash_password, oauth2_scheme, verify_password)

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _token_response(user: User) -> dict:
    token, exp = create_access_token(user.id)
    return {"access_token": token, "token_type": "bearer", "expires_at": exp.isoformat(), "user": UserOut.model_validate(user).model_dump()}


@router.post("/register", response_model=TokenOut, status_code=201)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.query(User).filter(User.email == email).first():
        raise ApiError(409, "email_taken", "An account with this email already exists.")
    user = User(email=email, password_hash=hash_password(body.password), display_name=body.display_name.strip())
    user.profile = UserProfile()
    db.add(user)
    db.commit()
    db.refresh(user)
    return _token_response(user)


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email.lower()).first()
    if not user or not verify_password(body.password, user.password_hash):
        raise ApiError(401, "invalid_credentials", "Incorrect email or password.")
    return _token_response(user)


@router.post("/token", summary="OAuth2 form login (used by the Swagger 'Authorize' button)")
def token_form(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form.username.lower()).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise ApiError(401, "invalid_credentials", "Incorrect email or password.")
    return {"access_token": _token_response(user)["access_token"], "token_type": "bearer"}


@router.post("/logout")
def logout(token: str = Depends(oauth2_scheme), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    import datetime as dt
    p = decode_token(token)
    db.merge(RevokedToken(jti=p["jti"], expires_at=dt.datetime.fromtimestamp(p["exp"], dt.timezone.utc)))
    db.commit()
    return {"ok": True, "message": "Logged out. Discard the token on the client."}


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user
