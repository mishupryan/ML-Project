import csv
import io
import math
from collections import defaultdict

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import Food, MealPlan, ShoppingList, ShoppingListItem, User
from ..schemas.misc import GroceryFromPlanIn, GroceryItemIn, GroceryItemPatch
from ..security import get_current_user
from ..utils.foodlogic import cost_for

router = APIRouter(prefix="/api/grocery", tags=["grocery"])


def _purchase_display(food: Food, eaten_g: float, purchase_g: float) -> str:
    if food.unit_g and food.unit_name and (food.purchase_factor or 1) == 1:
        n = math.ceil(eaten_g / food.unit_g - 1e-9)
        name = food.unit_name
        return f"{n} {name if (n == 1 or name.endswith('s')) else name + 's'}"
    return f"{purchase_g / 1000:.2f} kg" if purchase_g >= 1000 else f"{round(purchase_g / 5) * 5:g} g"


def _list_dict(sl: ShoppingList) -> dict:
    items = [{"id": i.id, "food_id": i.food_id, "name": i.name, "quantity_g": i.quantity_g, "display_qty": i.display_qty, "est_cost_inr": i.est_cost_inr,
              "purchased": i.purchased} for i in sorted(sl.items, key=lambda x: x.name.lower())]
    known = [i["est_cost_inr"] for i in items if i["est_cost_inr"] is not None]
    return {"id": sl.id, "name": sl.name, "plan_id": sl.plan_id, "created_at": sl.created_at.isoformat(), "items": items,
            "est_total_cost_inr": round(sum(known), 1) if known else None,
            "cost_incomplete": len(known) < len(items), "purchased_count": sum(i["purchased"] for i in items), "item_count": len(items),
            "note": "Quantities are as PURCHASED (e.g. dry rice/dal, raw chicken), converted from as-eaten weights; prices are illustrative estimates."}


def _own(db, user, list_id) -> ShoppingList:
    sl = db.get(ShoppingList, list_id)
    if not sl or sl.user_id != user.id:
        raise ApiError(404, "list_not_found", "Shopping list not found.")
    return sl


@router.get("/meal-prep/{plan_id}", tags=["meal-prep"])
def meal_prep(plan_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Batch-cooking suggestions and a weekly prep schedule derived from a plan."""
    plan = db.get(MealPlan, plan_id)
    if not plan or plan.user_id != user.id:
        raise ApiError(404, "plan_not_found", "Meal plan not found.")
    uses: dict[int, list] = defaultdict(list)
    for d in plan.days:
        for m in d.meals:
            for it in m.items:
                uses[it.food_id].append((d.day_index, m.slot, it.quantity_g, it.food))
    batches, total_min = [], 0
    for fid, lst in uses.items():
        f = lst[0][3]
        if (f.prep_time_min or 0) < 10 or "no_cook" in (f.tags or []) or len(lst) < 2:
            continue
        days = sorted({d for d, *_ in lst})
        chunks, cur = [], [days[0]]
        for d in days[1:]:
            if d - cur[0] < 3:
                cur.append(d)
            else:
                chunks.append(cur)
                cur = [d]
        chunks.append(cur)
        for ch in chunks:
            qty = sum(q for d, _, q, _ in lst if d in ch)
            batches.append({"food": f.name, "cook_on_day": ch[0] + 1, "covers_days": [d + 1 for d in ch], "total_cooked_g": round(qty, 0),
                            "portions": sum(1 for d, *_ in lst if d in ch), "prep_time_min": f.prep_time_min, "how": f.prep_note})
            total_min += f.prep_time_min or 0
    batches.sort(key=lambda b: (b["cook_on_day"], b["food"]))
    sched = defaultdict(list)
    for b in batches:
        sched[b["cook_on_day"]].append(f"Cook {b['food']} ({b['total_cooked_g']:g} g for days {', '.join(map(str, b['covers_days']))})")
    reuse = [f"{lst[0][3].name} appears in {len(lst)} meals - buy once and portion it out." for lst in uses.values() if len(lst) >= 4]
    return {"plan_id": plan.id, "batches": batches, "weekly_schedule": [{"day": d, "tasks": t} for d, t in sorted(sched.items())],
            "estimated_total_cooking_minutes": total_min, "ingredient_reuse": reuse[:8],
            "storage_guidance": ["Cool cooked food and refrigerate within 2 hours; keep the fridge at 4 C (40 F) or below.",
                                 "Eat refrigerated leftovers within about 3-4 days, or freeze portions for longer storage.",
                                 "Reheat leftovers until steaming hot (74 C / 165 F) and reheat only once."],
            "source_note": "General guidance in line with USDA FSIS leftovers advice - confirm with current official food-safety guidance for your country."}


@router.post("/from-plan/{plan_id}", status_code=201)
def from_plan(plan_id: int, body: GroceryFromPlanIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = db.get(MealPlan, plan_id)
    if not plan or plan.user_id != user.id:
        raise ApiError(404, "plan_not_found", "Meal plan not found.")
    agg: dict[int, float] = defaultdict(float)
    foods: dict[int, Food] = {}
    for d in plan.days:
        if body.day_indexes is not None and d.day_index not in body.day_indexes:
            continue
        for m in d.meals:
            for it in m.items:
                agg[it.food_id] += it.quantity_g
                foods[it.food_id] = it.food
    if not agg:
        raise ApiError(422, "empty_selection", "The selected days contain no foods.")
    sl = ShoppingList(user_id=user.id, plan_id=plan.id, name=body.name or f"Groceries - {plan.name}")
    for fid, eaten in agg.items():                   # duplicate ingredients across meals/days are combined here
        f = foods[fid]
        purchase = eaten * (f.purchase_factor or 1.0)
        sl.items.append(ShoppingListItem(food_id=fid, name=f.name, quantity_g=round(purchase, 1), display_qty=_purchase_display(f, eaten, purchase),
                                         est_cost_inr=cost_for(f, eaten)))
    db.add(sl); db.commit(); db.refresh(sl)
    return _list_dict(sl)


@router.get("")
def lists(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {"items": [_list_dict(s) | {"items": []} for s in db.query(ShoppingList).filter_by(user_id=user.id).order_by(ShoppingList.id.desc()).all()]}


@router.get("/{list_id}")
def get_list(list_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return _list_dict(_own(db, user, list_id))


@router.delete("/{list_id}", status_code=204)
def delete_list(list_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(_own(db, user, list_id)); db.commit()


@router.post("/{list_id}/items", status_code=201)
def add_item(list_id: int, body: GroceryItemIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sl = _own(db, user, list_id)
    cost = None
    if body.food_id:
        f = db.get(Food, body.food_id)
        if f and f.owner_user_id in (None, user.id) and f.price_per_100g is not None:
            cost = round(body.quantity_g / 100 * f.price_per_100g, 2)
    sl.items.append(ShoppingListItem(food_id=body.food_id, name=body.name, quantity_g=body.quantity_g, display_qty=f"{body.quantity_g:g} g", est_cost_inr=cost))
    db.commit(); db.refresh(sl)
    return _list_dict(sl)


@router.patch("/{list_id}/items/{item_id}")
def patch_item(list_id: int, item_id: int, body: GroceryItemPatch, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sl = _own(db, user, list_id)
    it = next((i for i in sl.items if i.id == item_id), None)
    if not it:
        raise ApiError(404, "item_not_found", "Item not found.")
    data = body.model_dump(exclude_unset=True)
    if data.get("quantity_g") and it.quantity_g:
        ratio = data["quantity_g"] / it.quantity_g
        if it.est_cost_inr is not None and "est_cost_inr" not in data:
            it.est_cost_inr = round(it.est_cost_inr * ratio, 2)
        it.display_qty = f"{data['quantity_g'] / 1000:.2f} kg" if data["quantity_g"] >= 1000 else f"{data['quantity_g']:g} g"
    for k, v in data.items():
        if v is not None:
            setattr(it, k, v)
    db.commit(); db.refresh(sl)
    return _list_dict(sl)


@router.delete("/{list_id}/items/{item_id}")
def delete_item(list_id: int, item_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sl = _own(db, user, list_id)
    it = next((i for i in sl.items if i.id == item_id), None)
    if not it:
        raise ApiError(404, "item_not_found", "Item not found.")
    sl.items.remove(it); db.commit(); db.refresh(sl)
    return _list_dict(sl)


@router.get("/{list_id}/export.csv")
def export(list_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    d = _list_dict(_own(db, user, list_id))
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["item", "quantity_to_buy", "quantity_g", "est_cost_inr", "purchased"])
    for i in d["items"]:
        w.writerow([i["name"], i["display_qty"], i["quantity_g"], i["est_cost_inr"], "yes" if i["purchased"] else "no"])
    w.writerow(["TOTAL (estimated)", "", "", d["est_total_cost_inr"], ""])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=grocery_list.csv"})
