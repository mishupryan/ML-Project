import datetime as dt
from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import NutritionTarget, User, WaterLog, WeightLog
from ..schemas.user import TargetsIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..services import nutrition_calc as nc
from ..services import targets as tsvc
from ..utils.dates import today_for

router = APIRouter(prefix="/api/nutrition", tags=["nutrition"])


@router.get("/targets")
def get_targets(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = user.profile
    t = tsvc.get_targets(db, user) or tsvc.recompute_targets(db, user)
    estimate = None
    if tsvc.profile_ready(p):
        try:
            estimate = tsvc.estimate_for_profile(p).to_dict()
        except ValueError as e:
            raise ApiError(422, "invalid_profile", str(e))
    return {"targets": tsvc.target_dict(t), "estimate": estimate, "restrictions": nc.is_restricted(p), "limitations": nc.LIMITATIONS,
            "message": None if t else "Complete your profile (age, height, weight) to calculate targets, or set them manually."}


@router.put("/targets")
def set_targets(body: TargetsIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    t = tsvc.get_targets(db, user) or NutritionTarget(user_id=user.id, calories=0, protein_g=0, carbs_g=0, fat_g=0)
    kcal_from_macros = body.protein_g * 4 + body.carbs_g * 4 + body.fat_g * 9
    warnings = []
    if abs(kcal_from_macros - body.calories) > 0.15 * body.calories:
        warnings.append(f"Your macros add up to about {round(kcal_from_macros)} kcal, which differs from the calorie target by more than 15%.")
    t.calories, t.protein_g, t.carbs_g, t.fat_g = body.calories, body.protein_g, body.carbs_g, body.fat_g
    t.fiber_g = body.fiber_g if body.fiber_g is not None else (t.fiber_g or 25)
    t.water_ml = body.water_ml if body.water_ml is not None else t.water_ml
    t.is_manual = True
    db.add(t); db.commit(); db.refresh(t)
    return {"targets": tsvc.target_dict(t), "warnings": warnings}


@router.post("/targets/reset")
def reset_targets(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not tsvc.profile_ready(user.profile):
        raise ApiError(422, "profile_incomplete", "Add age, height and weight to your profile first.")
    return {"targets": tsvc.target_dict(tsvc.recompute_targets(db, user, force=True))}


@router.get("/daily-summary")
def daily_summary(date: Optional[dt.date] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = user.profile
    day = date or today_for(p)
    t = tsvc.get_targets(db, user)
    td = dsvc.build_day(db, user, day)
    cons = td["totals"]
    tgt = tsvc.target_dict(t)
    remaining = percent = None
    if tgt:
        keys = ("calories", "protein_g", "carbs_g", "fat_g", "fiber_g")
        remaining = {k: round(tgt[k] - cons[k], 1) for k in keys}
        percent = {k: round(100 * cons[k] / tgt[k], 1) if tgt[k] else None for k in keys}
    water = sum(w.amount_ml for w in db.query(WaterLog).filter_by(user_id=user.id, log_date=day).all())
    warnings = []
    for k, n in cons["incomplete_entries"].items():
        warnings.append(f"{n} logged item(s) have no {k.replace('_', ' ')} data, so that total may be underestimated.")
    if td["entries_count"] == 0:
        warnings.append("Nothing logged for this day yet - totals show 0 because no food was recorded, not because nothing was eaten.")
    wk_entries = dsvc.entries_between(db, user.id, day - dt.timedelta(days=6), day)
    per_day = dsvc.by_day(wk_entries)
    on_target = 0
    if tgt:
        on_target = sum(1 for es in per_day.values() if 0.9 * tgt["calories"] <= dsvc.totals(es)["calories"] <= 1.1 * tgt["calories"])
    weights = db.query(WeightLog).filter(WeightLog.user_id == user.id).order_by(WeightLog.log_date.desc()).limit(30).all()
    wt = None
    if weights:
        latest = weights[0]
        ref = next((w for w in weights if (latest.log_date - w.log_date).days >= 7), None)
        wt = {"latest_kg": latest.weight_kg, "latest_date": latest.log_date.isoformat(),
              "change_kg_over_7d_or_more": None if not ref else round(latest.weight_kg - ref.weight_kg, 2),
              "note": "Scale weight alone cannot tell muscle from fat."}
    next_meal = None
    try:
        from ..services import recommender
        next_meal = recommender.next_meal_suggestion(db, user, day, td, tgt)
    except Exception:                                   # recommendations must never break the dashboard
        next_meal = None
    return {"date": day.isoformat(), "targets": tgt, "consumed": {k: v for k, v in cons.items() if k != "incomplete_entries"},
            "remaining": remaining, "percent": percent, "meals": td["meals"], "entries_count": td["entries_count"],
            "meals_logged": [m["meal_type"] for m in td["meals"]], "water_ml": water,
            "water_target_ml": (t.water_ml if t else None) if p.water_enabled else None,
            "weekly_consistency": {"days_logged_last_7": len(per_day), "days_within_10pct_of_calorie_target": on_target},
            "weight_trend": wt, "next_meal": next_meal, "warnings": warnings}


def _hm(s: str) -> int:
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def _fmt(mins: int) -> str:
    mins %= 1440
    return f"{mins // 60:02d}:{mins % 60:02d}"


@router.get("/meal-timing")
def meal_timing(user: User = Depends(get_current_user)):
    """Flexible meal schedule around wake/sleep and (optional) workout time. Timing is a guide, not a rule."""
    p = user.profile
    wake, sleep = _hm(p.wake_time or "07:00"), _hm(p.sleep_time or "23:00")
    if sleep <= wake:
        sleep += 1440
    n = p.meals_per_day or 4
    first, last = wake + 60, sleep - 150
    slots = [first + round(i * (last - first) / (n - 1)) for i in range(n)]
    names = {3: ["breakfast", "lunch", "dinner"], 4: ["breakfast", "lunch", "evening_snack", "dinner"],
             5: ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner"], 6: ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "dinner", "custom"]}[n]
    sched = [{"meal": nm, "suggested_time": _fmt(t)} for nm, t in zip(names, slots)]
    notes = ["Times are flexible suggestions spread across your waking hours; there is no single 'anabolic window' that everyone must hit.",
             "Total daily protein and calories matter more than exact meal timing."]
    workout = None
    if p.workout_time:
        w = _hm(p.workout_time)
        workout = {"workout_time": p.workout_time, "pre_workout_suggestion": f"A light carbohydrate-based snack roughly 60-120 minutes before ({_fmt(w - 90)}), adjusted to what you tolerate.",
                   "post_workout_suggestion": f"A meal or snack with protein and carbohydrate within a few hours after ({_fmt(w + 90)})."}
    return {"schedule": sched, "workout": workout, "workout_days": p.workout_days, "notes": notes}
