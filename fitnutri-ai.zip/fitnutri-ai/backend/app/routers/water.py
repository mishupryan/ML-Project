import datetime as dt
from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import User, WaterLog
from ..schemas.misc import WaterIn
from ..security import get_current_user
from ..services import targets as tsvc
from ..utils.dates import today_for

router = APIRouter(prefix="/api/water-logs", tags=["water"])


@router.post("", status_code=201)
def add(body: WaterIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    w = WaterLog(user_id=user.id, log_date=body.log_date or today_for(user.profile), amount_ml=body.amount_ml)
    db.add(w); db.commit(); db.refresh(w)
    return {"id": w.id, "log_date": w.log_date.isoformat(), "amount_ml": w.amount_ml}


@router.get("")
def list_logs(date: Optional[dt.date] = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    day = date or today_for(user.profile)
    rows = db.query(WaterLog).filter_by(user_id=user.id, log_date=day).order_by(WaterLog.id).all()
    t = tsvc.get_targets(db, user)
    p = user.profile
    target = (p.water_target_ml or (t.water_ml if t else None)) if p.water_enabled else None
    total = sum(r.amount_ml for r in rows)
    return {"date": day.isoformat(), "total_ml": total, "target_ml": target, "percent": round(100 * total / target) if target else None,
            "enabled": p.water_enabled, "entries": [{"id": r.id, "amount_ml": r.amount_ml} for r in rows],
            "note": "Water needs vary with climate, body size, activity and health; the target is a general, editable guide (Profile > water target).",
            "reminder_interval_min": 120}


@router.delete("/{wid}", status_code=204)
def delete(wid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    w = db.get(WaterLog, wid)
    if not w or w.user_id != user.id:
        raise ApiError(404, "not_found", "Water entry not found.")
    db.delete(w); db.commit()
