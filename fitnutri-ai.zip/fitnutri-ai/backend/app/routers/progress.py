import csv
import datetime as dt
import io

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import BodyMeasurement, FoodDiaryEntry, User, WeightLog
from ..schemas.misc import MeasurementIn, WeightIn
from ..security import get_current_user
from ..utils.dates import today_for

router = APIRouter(prefix="/api/progress", tags=["progress"])


def _wd(w: WeightLog):
    return {"id": w.id, "log_date": w.log_date.isoformat(), "weight_kg": w.weight_kg, "note": w.note}


def _md(m: BodyMeasurement):
    return {"id": m.id, "log_date": m.log_date.isoformat(), "waist_cm": m.waist_cm, "chest_cm": m.chest_cm, "arm_cm": m.arm_cm, "thigh_cm": m.thigh_cm,
            "hip_cm": m.hip_cm, "body_fat_pct": m.body_fat_pct, "note": m.note}


@router.post("/weight", status_code=201)
def log_weight(body: WeightIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    day = body.log_date or today_for(user.profile)
    w = db.query(WeightLog).filter_by(user_id=user.id, log_date=day).first()
    if w:
        w.weight_kg, w.note = body.weight_kg, body.note
    else:
        w = WeightLog(user_id=user.id, log_date=day, weight_kg=body.weight_kg, note=body.note)
        db.add(w)
    if day == today_for(user.profile):
        user.profile.weight_kg = body.weight_kg
    db.commit(); db.refresh(w)
    return _wd(w)


@router.delete("/weight/{wid}", status_code=204)
def delete_weight(wid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    w = db.get(WeightLog, wid)
    if not w or w.user_id != user.id:
        raise ApiError(404, "not_found", "Weight entry not found.")
    db.delete(w); db.commit()


@router.post("/measurements", status_code=201)
def log_measurement(body: MeasurementIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = body.model_dump()
    data["log_date"] = data["log_date"] or today_for(user.profile)
    m = BodyMeasurement(user_id=user.id, **data)
    db.add(m); db.commit(); db.refresh(m)
    return _md(m)


@router.delete("/measurements/{mid}", status_code=204)
def delete_measurement(mid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = db.get(BodyMeasurement, mid)
    if not m or m.user_id != user.id:
        raise ApiError(404, "not_found", "Measurement not found.")
    db.delete(m); db.commit()


def _trend(weights: list[WeightLog]) -> dict:
    if len(weights) < 2:
        return {"weekly_change_kg": None, "note": "Log your weight at least twice (ideally a week or more apart) to see a trend."}
    first, last = weights[0], weights[-1]
    days = max((last.log_date - first.log_date).days, 1)
    return {"weekly_change_kg": round((last.weight_kg - first.weight_kg) / days * 7, 2), "total_change_kg": round(last.weight_kg - first.weight_kg, 2), "days": days,
            "note": "Scale weight includes water, food in the gut, muscle and fat - it cannot show which one changed."}


@router.get("")
def progress(days: int = Query(90, ge=7, le=730), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = user.profile
    today = today_for(p)
    start = today - dt.timedelta(days=days)
    weights = db.query(WeightLog).filter(WeightLog.user_id == user.id, WeightLog.log_date >= start).order_by(WeightLog.log_date).all()
    meas = db.query(BodyMeasurement).filter(BodyMeasurement.user_id == user.id, BodyMeasurement.log_date >= start).order_by(BodyMeasurement.log_date).all()
    logged_days = {r[0] for r in db.query(FoodDiaryEntry.log_date).filter(FoodDiaryEntry.user_id == user.id, FoodDiaryEntry.log_date >= start).distinct().all()}
    span = min(days, 30)
    last30 = sum(1 for d in logged_days if d >= today - dt.timedelta(days=span - 1))
    milestones = None
    all_w = db.query(WeightLog).filter_by(user_id=user.id).order_by(WeightLog.log_date).all()
    if p.target_weight_kg and all_w:
        s, c, t = all_w[0].weight_kg, all_w[-1].weight_kg, p.target_weight_kg
        total = t - s
        prog = 0 if total == 0 else max(0.0, min(1.0, (c - s) / total))
        milestones = {"start_kg": s, "current_kg": c, "target_kg": t, "percent_complete": round(100 * prog),
                      "milestones": [{"label": f"{int(x * 100)}% of the way", "weight_kg": round(s + total * x, 1), "reached": prog >= x} for x in (0.25, 0.5, 0.75, 1.0)]}
    return {"weights": [_wd(w) for w in weights], "measurements": [_md(m) for m in meas], "trend": _trend(weights), "milestones": milestones,
            "logging_consistency": {"window_days": span, "days_with_food_logged": last30, "percent": round(100 * last30 / span)},
            "weight_logged_days": len(weights)}


@router.get("/export.csv")
def export(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["type", "date", "value", "details"])
    for x in db.query(WeightLog).filter_by(user_id=user.id).order_by(WeightLog.log_date):
        w.writerow(["weight_kg", x.log_date, x.weight_kg, x.note or ""])
    for m in db.query(BodyMeasurement).filter_by(user_id=user.id).order_by(BodyMeasurement.log_date):
        w.writerow(["measurements", m.log_date, "", f"waist={m.waist_cm} chest={m.chest_cm} arm={m.arm_cm} thigh={m.thigh_cm} hip={m.hip_cm} bf%={m.body_fat_pct}"])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=progress.csv"})
