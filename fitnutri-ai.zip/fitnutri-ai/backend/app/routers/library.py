"""Saved (favourite) foods and reusable custom meals."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import Meal, MealItem, SavedFood, User
from ..schemas.food import LogMealIn, MealIn
from ..security import get_current_user
from ..services import diary as dsvc
from ..utils.dates import today_for
from ..utils.foodlogic import food_to_dict, scale_nutrients

router = APIRouter(prefix="/api", tags=["library"])


@router.get("/saved-foods")
def list_saved(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {"items": [food_to_dict(s.food) for s in db.query(SavedFood).filter_by(user_id=user.id).all()]}


@router.post("/saved-foods/{food_id}", status_code=201)
def save_food(food_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    dsvc.visible_food(db, user, food_id)
    if not db.query(SavedFood).filter_by(user_id=user.id, food_id=food_id).first():
        db.add(SavedFood(user_id=user.id, food_id=food_id)); db.commit()
    return {"ok": True}


@router.delete("/saved-foods/{food_id}", status_code=204)
def unsave_food(food_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = db.query(SavedFood).filter_by(user_id=user.id, food_id=food_id).first()
    if s:
        db.delete(s); db.commit()


def meal_dict(m: Meal) -> dict:
    tot = {"calories": 0.0, "protein_g": 0.0, "carbs_g": 0.0, "fat_g": 0.0, "fiber_g": 0.0}
    items = []
    for it in m.items:
        n = scale_nutrients(it.food, it.quantity_g)
        for k in tot:
            tot[k] += n[k] or 0
        items.append({"id": it.id, "food_id": it.food_id, "food_name": it.food.name, "quantity_g": it.quantity_g, "nutrients": n})
    return {"id": m.id, "name": m.name, "meal_type": m.meal_type, "items": items, "totals": {k: round(v, 1) for k, v in tot.items()}}


def _meal(db, user, meal_id) -> Meal:
    m = db.get(Meal, meal_id)
    if not m or m.user_id != user.id:
        raise ApiError(404, "meal_not_found", "Meal not found.")
    return m


@router.get("/meals")
def list_meals(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {"items": [meal_dict(m) for m in db.query(Meal).filter_by(user_id=user.id).order_by(Meal.id.desc()).all()]}


@router.post("/meals", status_code=201)
def create_meal(body: MealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = Meal(user_id=user.id, name=body.name, meal_type=body.meal_type)
    for it in body.items:
        dsvc.visible_food(db, user, it.food_id)
        m.items.append(MealItem(food_id=it.food_id, quantity_g=it.quantity_g))
    db.add(m); db.commit(); db.refresh(m)
    return meal_dict(m)


@router.delete("/meals/{meal_id}", status_code=204)
def delete_meal(meal_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(_meal(db, user, meal_id)); db.commit()


@router.post("/meals/{meal_id}/log", status_code=201)
def log_meal(meal_id: int, body: LogMealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = _meal(db, user, meal_id)
    day = body.log_date or today_for(user.profile)
    for it in m.items:
        dsvc.create_entry(db, user, it.food, log_date=day, meal_type=body.meal_type, quantity_g=it.quantity_g)
    db.commit()
    return {"logged": len(m.items)}
