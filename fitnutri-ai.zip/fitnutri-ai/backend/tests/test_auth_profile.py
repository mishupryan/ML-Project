from conftest import PROFILE, register


def test_register_login_me_logout(client):
    h = register(client)
    assert client.get("/api/auth/me", headers=h).json()["email"] == "a@example.com"
    r = client.post("/api/auth/login", json={"email": "A@example.com", "password": "Passw0rd!x"})
    assert r.status_code == 200 and r.json()["access_token"]
    assert client.post("/api/auth/logout", headers=h).status_code == 200
    assert client.get("/api/auth/me", headers=h).status_code == 401      # token revoked


def test_password_is_hashed_and_duplicates_rejected(client):
    register(client)
    from app.models import User
    with client.session_factory() as db:
        u = db.query(User).first()
        assert u.password_hash != "Passw0rd!x" and u.password_hash.startswith("$2")
    r = client.post("/api/auth/register", json={"email": "a@example.com", "password": "Passw0rd!x", "display_name": "x"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "email_taken"


def test_bad_credentials_and_validation_errors(client):
    register(client)
    r = client.post("/api/auth/login", json={"email": "a@example.com", "password": "wrong-password"})
    assert r.status_code == 401 and r.json()["error"]["code"] == "invalid_credentials"
    r = client.post("/api/auth/register", json={"email": "not-an-email", "password": "short", "display_name": ""})
    assert r.status_code == 422 and r.json()["error"]["code"] == "validation_error" and r.json()["error"]["details"]


def test_protected_routes_need_token(client):
    for path in ["/api/profile", "/api/diary", "/api/foods", "/api/nutrition/targets", "/api/progress", "/api/meal-plans", "/api/recipes", "/api/ml/status"]:
        assert client.get(path).status_code == 401, path
    assert client.get("/api/profile", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_profile_update_calculates_targets_and_validates(client, auth):
    t = client.get("/api/nutrition/targets", headers=auth).json()
    assert t["targets"]["calories"] > 2500 and t["targets"]["protein_g"] > 100 and t["estimate"]["bmr"] > 1500
    assert client.put("/api/profile", json={"age": 5}, headers=auth).status_code == 422
    assert client.put("/api/profile", json={"diet_flags": ["nonsense"]}, headers=auth).status_code == 422
    assert client.put("/api/profile", json={"weight_kg": -3}, headers=auth).status_code == 422
    assert client.put("/api/profile", json={"timezone": "Mars/Base"}, headers=auth).status_code == 422


def test_manual_targets_persist_and_reset(client, auth):
    r = client.put("/api/nutrition/targets", json={"calories": 2400, "protein_g": 150, "carbs_g": 280, "fat_g": 75}, headers=auth)
    assert r.status_code == 200 and r.json()["targets"]["is_manual"]
    client.put("/api/profile", json={"weight_kg": 72}, headers=auth)           # manual targets kept
    assert client.get("/api/nutrition/targets", headers=auth).json()["targets"]["calories"] == 2400
    r = client.post("/api/nutrition/targets/reset", headers=auth)
    assert not r.json()["targets"]["is_manual"] and r.json()["targets"]["calories"] != 2400


def test_minor_and_flagged_users_are_restricted(client):
    h = register(client, email="kid@example.com", profile={**PROFILE, "age": 16, "goal": "muscle_gain"})
    t = client.get("/api/nutrition/targets", headers=h).json()
    assert t["restrictions"] and t["estimate"]["restricted"] and t["estimate"]["goal"] == "maintenance"
    h2 = register(client, email="ed@example.com", profile={**PROFILE, "goal": "fat_loss", "eating_disorder_concern": True})
    assert client.get("/api/nutrition/targets", headers=h2).json()["estimate"]["goal"] == "maintenance"


def test_profile_weight_syncs_progress(client, auth):
    prog = client.get("/api/progress", headers=auth).json()
    assert any(w["weight_kg"] == 70 for w in prog["weights"])
