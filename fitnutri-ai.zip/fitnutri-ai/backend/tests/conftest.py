import os
import sys
from pathlib import Path

os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "ml" / "src"))

from app.database import Base, get_db, make_engine  # noqa: E402
from app.main import create_app  # noqa: E402
from app.services.seed import load_sample_foods  # noqa: E402

PROFILE = {"age": 25, "sex": "male", "height_cm": 175, "weight_kg": 70, "activity_level": "moderate", "goal": "muscle_gain",
           "diet_preference": "non_vegetarian", "meals_per_day": 4}


@pytest.fixture()
def session_factory():
    eng = make_engine("sqlite:///:memory:")
    Base.metadata.create_all(eng)
    SL = sessionmaker(bind=eng, autoflush=False, autocommit=False, future=True)
    with SL() as s:
        load_sample_foods(s)
    yield SL
    eng.dispose()


@pytest.fixture()
def client(session_factory):
    app = create_app()

    def _db():
        db = session_factory()
        try:
            yield db
        finally:
            db.close()
    app.dependency_overrides[get_db] = _db
    with TestClient(app, raise_server_exceptions=False) as c:
        c.session_factory = session_factory
        yield c


def register(client, email="a@example.com", password="Passw0rd!x", name="Alice", profile=None):
    r = client.post("/api/auth/register", json={"email": email, "password": password, "display_name": name})
    assert r.status_code == 201, r.text
    h = {"Authorization": "Bearer " + r.json()["access_token"]}
    if profile is not None:
        pr = client.put("/api/profile", json=profile, headers=h)
        assert pr.status_code == 200, pr.text
    return h


@pytest.fixture()
def auth(client):
    return register(client, profile=PROFILE)


@pytest.fixture()
def auth2(client):
    return register(client, email="b@example.com", name="Bob", profile=PROFILE)


def food_id(client, auth, name):
    r = client.get("/api/foods", params={"q": name, "source": "curated"}, headers=auth)
    assert r.json()["items"], f"food {name} not found"
    return r.json()["items"][0]["id"]
