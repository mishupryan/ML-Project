import datetime as dt

from conftest import PROFILE, food_id, register

TODAY = dt.date.today().isoformat()


def test_food_search_filters_and_scaling(client, auth):
    r = client.get("/api/foods", params={"q": "paneer", "quantity_g": 150}, headers=auth).json()
    item = r["items"][0]
    assert item["name"] == "Paneer"
    assert item["scaled"]["protein_g"] == round(18.3 * 1.5, 2)                      # 150 g serving scales per-100 g values
    hi = client.get("/api/foods", params={"min_protein_per_100kcal": 10, "source": "curated"}, headers=auth).json()["items"]
    assert hi and all(i["protein_per_100kcal"] >= 10 for i in hi)
    cheap = client.get("/api/foods", params={"max_price_per_serving": 10, "source": "curated"}, headers=auth).json()["items"]
    assert cheap and all(i["price_per_serving"] <= 10 for i in cheap)
    vegan = client.get("/api/foods", params={"diet": "vegan", "source": "curated"}, headers=auth).json()["items"]
    assert vegan and all(i["diet_class"] == "vegan" for i in vegan)
    nopeanut = client.get("/api/foods", params={"exclude_allergens": "peanuts", "source": "curated"}, headers=auth).json()["items"]
    assert all("peanut" not in i["allergens"] for i in nopeanut)


def test_custom_food_crud_validation_and_privacy(client, auth, auth2):
    body = {"name": "My protein shake", "calories": 120, "protein_g": 24, "carbs_g": 3, "fat_g": 1.5, "serving_g": 250}
    r = client.post("/api/foods", json=body, headers=auth)
    assert r.status_code == 201 and r.json()["data_confidence"] == "user-custom" and r.json()["is_custom"]
    fid = r.json()["id"]
    assert any(i["id"] == fid for i in client.get("/api/foods", params={"q": "protein shake"}, headers=auth).json()["items"])
    assert not client.get("/api/foods", params={"q": "protein shake"}, headers=auth2).json()["items"]      # other users never see it
    assert client.get(f"/api/foods/{fid}", headers=auth2).status_code == 404
    assert client.put(f"/api/foods/{fid}", json={"calories": 130}, headers=auth2).status_code == 404
    assert client.put(f"/api/foods/{fid}", json={"calories": 130}, headers=auth).json()["per_100g"]["calories"] == 130
    bad = client.post("/api/foods", json={**body, "protein_g": 80, "carbs_g": 60}, headers=auth)
    assert bad.status_code == 422
    assert client.post("/api/foods", json={**body, "calories": -5}, headers=auth).status_code == 422
    assert client.delete(f"/api/foods/{fid}", headers=auth).status_code == 204


def test_builtin_foods_cannot_be_edited(client, auth):
    fid = food_id(client, auth, "Paneer")
    assert client.put(f"/api/foods/{fid}", json={"calories": 1}, headers=auth).status_code == 404
    assert client.delete(f"/api/foods/{fid}", headers=auth).status_code == 404


def test_diary_crud_and_totals(client, auth):
    egg, rice = food_id(client, auth, "Egg, whole"), food_id(client, auth, "Rice, white")
    r = client.post("/api/diary", json={"food_id": egg, "quantity_g": 100, "meal_type": "breakfast", "log_date": TODAY}, headers=auth)
    assert r.status_code == 201 and r.json()["protein_g"] == 12.6 and r.json()["calories"] == 155
    e2 = client.post("/api/diary", json={"food_id": rice, "servings": 2, "meal_type": "lunch", "log_date": TODAY}, headers=auth).json()
    assert e2["quantity_g"] == 300                                              # 2 x 150 g serving
    s = client.get("/api/nutrition/daily-summary", params={"date": TODAY}, headers=auth).json()
    assert s["consumed"]["calories"] == round(155 + 390, 1) and s["entries_count"] == 2
    assert s["remaining"]["calories"] == round(s["targets"]["calories"] - 545, 1)
    up = client.put(f"/api/diary/{e2['id']}", json={"quantity_g": 150}, headers=auth).json()
    assert up["calories"] == 195
    assert client.get("/api/nutrition/daily-summary", params={"date": TODAY}, headers=auth).json()["consumed"]["calories"] == 350
    assert client.delete(f"/api/diary/{e2['id']}", headers=auth).status_code == 204
    assert client.get("/api/nutrition/daily-summary", params={"date": TODAY}, headers=auth).json()["consumed"]["calories"] == 155


def test_diary_validation_and_empty_day(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    assert client.post("/api/diary", json={"food_id": egg, "quantity_g": 0, "meal_type": "lunch"}, headers=auth).status_code == 422
    assert client.post("/api/diary", json={"food_id": egg, "quantity_g": -5, "meal_type": "lunch"}, headers=auth).status_code == 422
    assert client.post("/api/diary", json={"food_id": egg, "meal_type": "lunch"}, headers=auth).status_code == 422
    assert client.post("/api/diary", json={"food_id": egg, "quantity_g": 50, "meal_type": "brunch"}, headers=auth).status_code == 422
    assert client.post("/api/diary", json={"food_id": 99999, "quantity_g": 50, "meal_type": "lunch"}, headers=auth).status_code == 404
    s = client.get("/api/nutrition/daily-summary", params={"date": "2020-01-01"}, headers=auth).json()
    assert s["consumed"]["calories"] == 0 and s["entries_count"] == 0
    assert any("nothing logged" in w.lower() for w in s["warnings"])            # missing log is explained, not treated as 'ate nothing'


def test_duplicate_entries_are_allowed_and_summed(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    for _ in range(2):
        client.post("/api/diary", json={"food_id": egg, "quantity_g": 50, "meal_type": "breakfast", "log_date": TODAY}, headers=auth)
    assert client.get("/api/diary", params={"date": TODAY}, headers=auth).json()["totals"]["calories"] == 155


def test_missing_nutrient_data_is_flagged(client, auth):
    r = client.post("/api/foods", json={"name": "Mystery bar", "calories": 400, "protein_g": 10, "carbs_g": 50, "fat_g": 15}, headers=auth).json()
    client.post("/api/diary", json={"food_id": r["id"], "quantity_g": 50, "meal_type": "evening_snack", "log_date": TODAY}, headers=auth)
    s = client.get("/api/nutrition/daily-summary", params={"date": TODAY}, headers=auth).json()
    assert any("fiber" in w for w in s["warnings"])
    assert "fiber_g" in client.get("/api/diary", params={"date": TODAY}, headers=auth).json()["meals"][0]["entries"][0]["missing_nutrients"]


def test_copy_and_duplicate_meal(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    client.post("/api/diary", json={"food_id": egg, "quantity_g": 100, "meal_type": "breakfast", "log_date": "2025-01-01"}, headers=auth)
    assert client.post("/api/diary/copy", json={"from_date": "2025-01-01", "to_date": "2025-01-02"}, headers=auth).json()["copied"] == 1
    assert client.get("/api/diary", params={"date": "2025-01-02"}, headers=auth).json()["totals"]["calories"] == 155
    assert client.post("/api/diary/duplicate-meal", json={"date": "2025-01-01", "meal_type": "breakfast", "to_meal_type": "lunch"}, headers=auth).status_code == 201
    assert client.post("/api/diary/copy", json={"from_date": "1999-01-01", "to_date": "2025-01-02"}, headers=auth).status_code == 404
    csv = client.get("/api/diary/export.csv", headers=auth)
    assert csv.status_code == 200 and "Egg, whole" in csv.text


def test_saved_foods_and_custom_meals(client, auth):
    egg, rice = food_id(client, auth, "Egg, whole"), food_id(client, auth, "Rice, white")
    assert client.post(f"/api/saved-foods/{egg}", headers=auth).status_code == 201
    assert len(client.get("/api/saved-foods", headers=auth).json()["items"]) == 1
    m = client.post("/api/meals", json={"name": "Egg rice", "items": [{"food_id": egg, "quantity_g": 100}, {"food_id": rice, "quantity_g": 150}]}, headers=auth)
    assert m.status_code == 201 and m.json()["totals"]["calories"] == 155 + 195
    assert client.post(f"/api/meals/{m.json()['id']}/log", json={"log_date": TODAY, "meal_type": "lunch"}, headers=auth).json()["logged"] == 2


def test_user_data_isolation(client, auth, auth2):
    egg = food_id(client, auth, "Egg, whole")
    e = client.post("/api/diary", json={"food_id": egg, "quantity_g": 50, "meal_type": "lunch", "log_date": TODAY}, headers=auth).json()
    assert client.put(f"/api/diary/{e['id']}", json={"quantity_g": 10}, headers=auth2).status_code == 404       # changing the ID in the URL gives nothing
    assert client.delete(f"/api/diary/{e['id']}", headers=auth2).status_code == 404
    assert client.get("/api/diary", params={"date": TODAY}, headers=auth2).json()["entries_count"] == 0
    r = client.post("/api/recipes", json={"name": "R", "ingredients": [{"food_id": egg, "quantity_g": 100}]}, headers=auth).json()
    assert client.get(f"/api/recipes/{r['id']}", headers=auth2).status_code == 404
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain"}, headers=auth).json()
    assert client.get(f"/api/meal-plans/{p['id']}", headers=auth2).status_code == 404
    assert client.get("/api/meal-plans", headers=auth2).json()["items"] == []
    g = client.post(f"/api/grocery/from-plan/{p['id']}", json={}, headers=auth).json()
    assert client.get(f"/api/grocery/{g['id']}", headers=auth2).status_code == 404
    assert client.post(f"/api/grocery/from-plan/{p['id']}", json={}, headers=auth2).status_code == 404


def test_timezone_aware_today(client):
    h = register(client, profile={**PROFILE, "timezone": "Pacific/Kiritimati"})            # UTC+14: date can differ from UTC date
    from app.utils.dates import today_for
    from app.models import User
    with client.session_factory() as db:
        u = db.query(User).first()
        d = today_for(u.profile)
    s = client.get("/api/nutrition/daily-summary", headers=h).json()
    assert s["date"] == d.isoformat()
