import datetime as dt

from conftest import PROFILE, food_id, register

TODAY = dt.date.today().isoformat()


def test_recommendations_explained_and_respect_constraints(client):
    h = register(client, profile={**PROFILE, "diet_preference": "vegan", "allergies": ["peanut"]})
    r = client.get("/api/recommendations/foods", params={"context": "general", "limit": 6}, headers=h).json()
    assert r["items"] and r["method"].startswith("rule-based") and r["weights"]
    for i in r["items"]:
        assert i["explanation"] and i["breakdown"] and 0 <= i["score"] <= 100
        assert i["food"]["diet_class"] == "vegan" and "peanut" not in i["food"]["name"].lower()
    scores = [i["score"] for i in r["items"]]
    assert scores == sorted(scores, reverse=True)
    assert client.get("/api/recommendations/foods", params={"context": "nonsense"}, headers=h).status_code == 422


def test_recommendations_close_remaining_protein_gap(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    client.post("/api/diary", json={"food_id": egg, "quantity_g": 100, "meal_type": "breakfast", "log_date": TODAY}, headers=auth)
    r = client.get("/api/recommendations/foods", params={"date": TODAY, "context": "high_protein"}, headers=auth).json()
    t = client.get("/api/nutrition/targets", headers=auth).json()["targets"]
    assert abs(r["remaining"]["protein_g"] - (t["protein_g"] - 12.6)) < 0.2
    assert max(i["nutrients"]["protein_g"] for i in r["items"]) >= 15


def test_feedback_changes_ranking_transparently(client, auth):
    base = client.get("/api/recommendations/foods", params={"limit": 30}, headers=auth).json()["items"]
    top = base[0]["food"]["id"]
    for _ in range(3):
        assert client.post("/api/recommendations/feedback", json={"food_id": top, "rating": -1}, headers=auth).status_code == 201
    after = client.get("/api/recommendations/foods", params={"limit": 30}, headers=auth).json()["items"]
    s0 = next(i for i in base if i["food"]["id"] == top)["score"]
    s1 = next(i for i in after if i["food"]["id"] == top)["score"]
    assert s1 < s0
    assert client.post("/api/recommendations/feedback", json={"food_id": top, "rating": 5}, headers=auth).status_code == 422


def test_top_foods_for_goal(client, auth):
    r = client.get("/api/recommendations/top-foods", params={"goal": "muscle_gain", "limit": 5}, headers=auth).json()
    assert len(r["items"]) == 5 and r["method"]
    assert r["items"][0]["score"] >= r["items"][-1]["score"]


def test_substitutions_respect_diet_and_allergy_and_are_honest(client):
    h = register(client, profile={**PROFILE, "diet_preference": "vegan"})
    paneer = client.get("/api/foods", params={"q": "Paneer", "source": "curated"}, headers=h).json()["items"][0]["id"]
    r = client.post("/api/recommendations/substitutions", json={"food_id": paneer, "quantity_g": 100, "match": "protein"}, headers=h).json()
    assert r["alternatives"], r
    names = [a["food"]["name"] for a in r["alternatives"]]
    assert any("Tofu" in n or "Soya" in n for n in names)
    assert all(a["food"]["diet_class"] == "vegan" for a in r["alternatives"])
    assert all(a["caveat"] for a in r["alternatives"])
    assert all(a["delta_vs_original"] for a in r["alternatives"])


def test_substitution_none_available(client):
    h = register(client, profile={**PROFILE, "diet_preference": "vegan", "allergies": ["soy", "peanut", "tree nuts", "gluten"],
                                  "disliked_foods": ["dal", "chana", "rajma", "quinoa", "sprouts", "peas"]})
    paneer = client.get("/api/foods", params={"q": "Paneer", "source": "curated"}, headers=h).json()["items"][0]["id"]
    r = client.post("/api/recommendations/substitutions", json={"food_id": paneer, "quantity_g": 100}, headers=h).json()
    assert r["alternatives"] == [] and r["empty_reason"]


def test_recipe_calculations_and_logging(client, auth):
    rice, dal = food_id(client, auth, "Rice, white"), food_id(client, auth, "Dal, cooked")
    body = {"name": "Dal rice", "servings": 2, "instructions": "Cook.", "prep_time_min": 30, "ingredients": [{"food_id": rice, "quantity_g": 300}, {"food_id": dal, "quantity_g": 200}]}
    r = client.post("/api/recipes", json=body, headers=auth)
    assert r.status_code == 201
    d = r.json()
    assert d["total"]["calories"] == round(390 + 232, 1) and d["per_serving"]["calories"] == round((390 + 232) / 2, 1)
    assert d["per_serving"]["protein_g"] == round((8.1 + 18.0) / 2, 1)
    assert d["cost_total_inr"] > 0 and d["missing_data"] == []
    log = client.post(f"/api/recipes/{d['id']}/log", json={"servings": 1.5, "meal_type": "dinner", "log_date": TODAY}, headers=auth)
    assert log.status_code == 201 and log.json()["calories"] == round(d["per_serving"]["calories"] * 1.5, 1)
    assert "Dal rice" in client.get(f"/api/recipes/{d['id']}/export", headers=auth).text
    assert client.post("/api/recipes", json={**body, "servings": 0}, headers=auth).status_code == 422
    assert client.post("/api/recipes", json={**body, "ingredients": []}, headers=auth).status_code == 422
    assert client.post("/api/recipes", json={**body, "ingredients": [{"food_id": 99999, "quantity_g": 5}]}, headers=auth).status_code == 404


def test_recipe_reports_missing_data(client, auth):
    c = client.post("/api/foods", json={"name": "Unlabelled mix", "calories": 300, "protein_g": 10, "carbs_g": 40, "fat_g": 10}, headers=auth).json()
    r = client.post("/api/recipes", json={"name": "X", "servings": 1, "ingredients": [{"food_id": c["id"], "quantity_g": 100}]}, headers=auth).json()
    assert r["missing_data"] and r["warnings"]


def test_progress_workouts_water(client, auth):
    assert client.post("/api/progress/weight", json={"weight_kg": 70.5, "log_date": "2025-01-01"}, headers=auth).status_code == 201
    client.post("/api/progress/weight", json={"weight_kg": 71.5, "log_date": "2025-01-15"}, headers=auth)
    client.post("/api/progress/weight", json={"weight_kg": 71.0, "log_date": "2025-01-15"}, headers=auth)        # same day updates, not duplicates
    assert client.post("/api/progress/measurements", json={"waist_cm": 80, "arm_cm": 35}, headers=auth).status_code == 201
    assert client.post("/api/progress/measurements", json={}, headers=auth).status_code == 422
    assert client.post("/api/progress/weight", json={"weight_kg": -1}, headers=auth).status_code == 422
    p = client.get("/api/progress", params={"days": 730}, headers=auth).json()
    assert [w["weight_kg"] for w in p["weights"] if w["log_date"].startswith("2025")] == [70.5, 71.0]
    assert p["trend"]["weekly_change_kg"] is not None and "cannot show" in p["trend"]["note"]
    client.put("/api/profile", json={"target_weight_kg": 80}, headers=auth)
    assert client.get("/api/progress", params={"days": 730}, headers=auth).json()["milestones"]["milestones"]
    assert "weight_kg" in client.get("/api/progress/export.csv", headers=auth).text
    w = client.post("/api/workouts", json={"workout_type": "strength", "duration_min": 60, "perceived_exertion": 8, "workout_date": TODAY,
                                           "exercises": [{"name": "Squat", "sets": 5, "reps": 5, "weight_kg": 100}]}, headers=auth)
    assert w.status_code == 201 and w.json()["total_volume_kg"] == 2500
    assert client.post("/api/workouts", json={"workout_type": "x", "perceived_exertion": 11}, headers=auth).status_code == 422
    assert client.get("/api/workouts/summary", headers=auth).json()["weeks"][-1]["sessions"] == 1
    assert client.post("/api/water-logs", json={"amount_ml": 500, "log_date": TODAY}, headers=auth).status_code == 201
    wl = client.get("/api/water-logs", params={"date": TODAY}, headers=auth).json()
    assert wl["total_ml"] == 500 and wl["target_ml"]
    assert client.post("/api/water-logs", json={"amount_ml": 0}, headers=auth).status_code == 422
    assert client.delete(f"/api/workouts/{w.json()['id']}", headers=auth).status_code == 204


def test_weekly_report_distinguishes_missing_from_zero(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    end = dt.date(2025, 2, 7)
    for d in (end, end - dt.timedelta(days=1)):
        client.post("/api/diary", json={"food_id": egg, "quantity_g": 200, "meal_type": "breakfast", "log_date": d.isoformat()}, headers=auth)
    r = client.get("/api/reports/weekly", params={"end_date": end.isoformat()}, headers=auth).json()
    assert r["days_logged"] == 2 and r["days_not_logged"] == 5
    assert r["averages_logged_days"]["calories"] == 310                          # averaged over LOGGED days only
    assert [d["calories"] for d in r["days"]].count(None) == 5                   # unlogged days are null, not 0
    assert any("Only 2" in s for s in r["suggestions"])
    csv = client.get("/api/reports/weekly.csv", params={"end_date": end.isoformat()}, headers=auth)
    assert csv.status_code == 200 and "no" in csv.text


def test_weekly_report_with_no_data(client, auth):
    r = client.get("/api/reports/weekly", headers=auth).json()
    assert r["days_logged"] == 0 and r["averages_logged_days"]["calories"] is None and "nothing can be concluded" in r["suggestions"][0]


def test_meal_timing(client, auth):
    client.put("/api/profile", json={"workout_time": "18:00", "workout_days": ["mon", "wed"]}, headers=auth)
    t = client.get("/api/nutrition/meal-timing", headers=auth).json()
    assert len(t["schedule"]) == 4 and t["workout"]["pre_workout_suggestion"] and any("anabolic" in n for n in t["notes"])


def test_chat_assistant_intents(client, auth):
    egg = food_id(client, auth, "Egg, whole")
    client.post("/api/diary", json={"food_id": egg, "quantity_g": 100, "meal_type": "breakfast", "log_date": dt.date.today().isoformat()}, headers=auth)
    ask = lambda m: client.post("/api/chat", json={"message": m}, headers=auth).json()
    r = ask("What can I eat to reach my protein target today?")
    assert r["intent"] == "protein" and "g protein" in r["reply"]
    assert ask("Compare paneer and tofu")["intent"] == "compare" and "Tofu" in ask("compare paneer and tofu")["reply"]
    assert ask("Replace eggs in my breakfast")["intent"] == "substitute"
    c = ask("Give me three inexpensive high-protein dinner options")
    assert c["intent"] == "budget" and "INR" in c["reply"]
    p = ask("Create a meal plan using rice, dal, paneer and vegetables")
    assert p["intent"] == "ingredient_plan" and p["data"]["plan_id"]
    plan = client.get(f"/api/meal-plans/{p['data']['plan_id']}", headers=auth).json()
    allowed = ("rice", "dal", "paneer", "vegetable")
    assert all(any(a in i["food_name"].lower() for a in allowed) for d in plan["days"] for m in d["meals"] for i in m["items"])
    assert ask("Why am I missing my fiber target?")["intent"] == "fiber"
    assert ask("what should I eat before a workout")["intent"] == "pre_workout"
    assert ask("blah blah")["intent"] == "help"
    assert ask("how do I starve myself to lose weight fast")["intent"] == "safety"
    assert client.post("/api/chat", json={"message": ""}, headers=auth).status_code == 422


def test_chat_respects_allergies(client):
    h = register(client, profile={**PROFILE, "allergies": ["soy"], "diet_preference": "vegetarian"})
    r = client.post("/api/chat", json={"message": "Create a meal plan using tofu, rice and dal"}, headers=h).json()
    assert "Tofu" not in r["reply"]
