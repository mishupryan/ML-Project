import numpy as np
import pandas as pd
import pytest

from conftest import PROFILE, register


def synthetic(n=240, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    prof = {"Meat": (150, 25, 0, 5), "Grain": (350, 8, 70, 2), "Fruit": (60, 1, 14, 0.3)}
    for i in range(n):
        c = list(prof)[i % 3]
        k, p, cb, f = prof[c]
        rows.append({"food_name": f"{c} item {i}", "food_type": c, "calories": max(k + rng.normal(0, 8), 1), "protein_g": max(p + rng.normal(0, 1), 0),
                     "carbs_g": max(cb + rng.normal(0, 2), 0), "fat_g": max(f + rng.normal(0, 0.5), 0), "fiber_g": rng.uniform(0, 1) * max(cb, 0) * 0.3, "sugar_g": rng.uniform(0, 1) * max(cb, 0) * 0.5, "sodium_mg": rng.uniform(0, 300)})
    rows += [{"food_name": "Rare A", "food_type": "Rare", "calories": 100, "protein_g": 5, "carbs_g": 10, "fat_g": 2, "fiber_g": 1, "sugar_g": 1, "sodium_mg": 10},
             {"food_name": "Rare B", "food_type": "Rare", "calories": 110, "protein_g": 5, "carbs_g": 12, "fat_g": 2, "fiber_g": 1, "sugar_g": 1, "sodium_mg": 10}]
    return pd.DataFrame(rows)


@pytest.fixture(scope="module")
def trained(tmp_path_factory):
    from fitnutri_ml.train import train_task
    out = tmp_path_factory.mktemp("models")
    res = train_task(synthetic(), "food_type", "food_category", out, fast=True, log=lambda *a: None)
    return out, res


def test_training_pipeline_outputs_and_rules(trained):
    out, res = trained
    for f in ("model.joblib", "preprocessor.joblib", "label_encoder.json", "features.json", "metrics.json", "metadata.json"):
        assert (out / "food_category" / f).exists()
    md, mt = res["metadata"], res["metrics"]
    assert md["serving_model"] in mt["models"] and set(md["classes"]) == {"Meat", "Grain", "Fruit"}
    assert any("fewer than" in w for w in mt["data_quality"]["warnings"])                 # rare class excluded AND reported
    best = mt["models"][md["best_model_by_validation_macro_f1"]]
    assert best["validation"]["macro_f1"] >= max(m["validation"]["macro_f1"] for m in mt["models"].values()) - 1e-9   # chosen on validation, not test
    assert mt["models"]["Random Forest"]["test"]["accuracy"] > 0.9
    assert md["n_train"] + md["n_validation"] + md["n_test"] <= md["n_rows_after_cleaning"]


def test_preprocessing_fit_on_train_only(trained):
    import joblib
    out, res = trained
    pre = joblib.load(out / "food_category" / "preprocessor.joblib")
    assert pre.named_steps["scale"].n_samples_seen_ == res["metadata"]["n_train"]          # scaler saw exactly the training rows


def test_cleaning_reports_removals():
    from fitnutri_ml.data import detect_columns, validate_and_clean
    df = synthetic(30)
    df.loc[0, "sodium_mg"] = 1_000_000
    df.loc[1, "calories"] = 5000
    df = pd.concat([df, df.iloc[[5]]])
    d, rep = validate_and_clean(df, detect_columns(df)["nutrients"])
    assert rep["exact_duplicates_removed"] == 1 and rep["impossible_rows_removed"] == 2 and len(d) == len(df) - 3
    assert rep["warnings"]                                                                   # >5% removed -> loud warning, never silent


def test_invalid_columns_raise_clear_errors():
    from fitnutri_ml.train import train_task
    df = synthetic(30)
    with pytest.raises(ValueError, match="not found"):
        train_task(df, "nope", "t", "/tmp/x", log=lambda *a: None)
    with pytest.raises(ValueError, match="nutrient"):
        train_task(df, "calories", "t", "/tmp/x", log=lambda *a: None)
    with pytest.raises(ValueError, match="no nutrient"):
        train_task(pd.DataFrame({"a": [1, 2, 3], "food_type": ["x", "y", "x"]}), "food_type", "t", "/tmp/x", log=lambda *a: None)


def test_column_detection_adapts_to_names():
    from fitnutri_ml.data import detect_columns, normalize_columns
    df = normalize_columns(pd.DataFrame({"Food Name": ["a", "b"], "Energy (kcal)": [1, 2], "Protein (g)": [1, 2], "Total Fat": [1, 2], "Carbohydrate": [1, 2], "Category": ["x", "y"]}))
    det = detect_columns(df)
    assert det["nutrients"]["calories"] == "energy_kcal" and det["nutrients"]["fat_g"] == "total_fat" and "category" in det["candidate_targets"]
    assert "fiber_g" not in det["nutrients"]                                                  # optional columns simply absent


def test_api_prediction_with_trained_model(client, auth, trained, monkeypatch):
    from app.config import settings
    from app.services import ml_service
    out, _ = trained
    monkeypatch.setattr(settings, "ml_model_dir", out)
    ml_service.reset_cache()
    st = client.get("/api/ml/status", headers=auth).json()["models"]["food_category"]
    assert st["available"] and st["serving_model"]
    r = client.post("/api/ml/predict-food-category", json={"nutrients": {"calories": 150, "protein_g": 25, "carbs_g": 0, "fat_g": 5}}, headers=auth).json()
    assert r["prediction"] == "Meat" and r["probabilities"][0]["probability"] > 0.5 and r["method"].startswith("trained model")
    r2 = client.post("/api/ml/predict-food-category", json={"nutrients": {"calories": 60, "protein_g": 1, "carbs_g": 14, "fat_g": 0.3, "fiber_g": 2}}, headers=auth).json()
    assert r2["prediction"] == "Fruit"
    assert client.get("/api/ml/metrics", params={"task": "food_category"}, headers=auth).json()["metrics"]["models"]
    assert client.post("/api/ml/predict-food-category", json={}, headers=auth).status_code == 422
    assert client.post("/api/ml/predict-food-category", json={"nutrients": {"calories": -4}}, headers=auth).status_code == 422
    ml_service.reset_cache()


def test_api_when_model_artifact_is_missing(client, auth, tmp_path, monkeypatch):
    from app.config import settings
    from app.services import ml_service
    monkeypatch.setattr(settings, "ml_model_dir", tmp_path)
    ml_service.reset_cache()
    st = client.get("/api/ml/status", headers=auth).json()["models"]
    assert st["food_category"]["available"] is False and "train" in st["food_category"]["message"].lower()
    r = client.post("/api/ml/predict-food-category", json={"nutrients": {"calories": 165, "protein_g": 31, "carbs_g": 0, "fat_g": 3.6}}, headers=auth)
    assert r.status_code == 200 and r.json()["available"] and "fallback" in r.json()["method"]       # graceful fallback, clearly labelled
    assert client.post("/api/ml/predict-health-score", json={"nutrients": {"calories": 100}}, headers=auth).json()["available"] is False
    assert client.get("/api/ml/metrics", headers=auth).status_code == 404
    ml_service.reset_cache()


def test_predict_by_food_id(client, auth, trained, monkeypatch):
    from app.config import settings
    from app.services import ml_service
    monkeypatch.setattr(settings, "ml_model_dir", trained[0]); ml_service.reset_cache()
    fid = client.get("/api/foods", params={"q": "Chicken breast", "source": "curated"}, headers=auth).json()["items"][0]["id"]
    r = client.post("/api/ml/predict-food-category", json={"food_id": fid}, headers=auth).json()
    assert r["input_food"] == "Chicken breast, cooked" and r["prediction"] in {"Meat", "Grain", "Fruit"}
    ml_service.reset_cache()
