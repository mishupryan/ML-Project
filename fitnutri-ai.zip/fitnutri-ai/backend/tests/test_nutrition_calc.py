import pytest

from app.services import nutrition_calc as nc
from app.utils.foodlogic import Constraints, scale_nutrients


def test_mifflin_known_values():
    assert nc.mifflin_st_jeor("male", 70, 175, 25) == pytest.approx(1673.75)
    assert nc.mifflin_st_jeor("female", 60, 160, 25) == pytest.approx(1314.0)
    assert nc.mifflin_st_jeor("other", 70, 175, 25) == pytest.approx(1673.75 - 83)


def test_goal_adjustments_are_capped_and_floored():
    gain = nc.calculate_targets(age=25, sex="male", height_cm=175, weight_kg=70, activity_level="moderate", goal="muscle_gain")
    assert 1.0 < gain.calories / gain.tdee <= 1.15
    loss = nc.calculate_targets(age=40, sex="female", height_cm=155, weight_kg=60, activity_level="sedentary", goal="fat_loss")
    assert loss.calories >= loss.bmr and loss.calories >= 1200
    assert loss.protein_g / 60 <= 2.2 + 1e-6


def test_macros_add_up_to_calories():
    r = nc.calculate_targets(age=30, sex="male", height_cm=180, weight_kg=80, goal="lean_bulk")
    assert abs(r.protein_g * 4 + r.carbs_g * 4 + r.fat_g * 9 - r.calories) < 0.06 * r.calories


def test_invalid_inputs():
    with pytest.raises(ValueError):
        nc.calculate_targets(age=None, sex="male", height_cm=175, weight_kg=70)
    with pytest.raises(ValueError):
        nc.calculate_targets(age=25, sex="male", height_cm=20, weight_kg=70)


def test_restricted_reasons_force_maintenance():
    r = nc.calculate_targets(age=25, sex="male", height_cm=175, weight_kg=70, goal="fat_loss", restricted_reasons=["x"])
    assert r.restricted and r.goal == "maintenance" and r.calories == r.tdee


class F:  # tiny stand-in for the Food ORM object
    def __init__(self, **kw):
        base = dict(id=1, name="x", calories=200, protein_g=20, carbs_g=10, fat_g=5, fiber_g=None, sugar_g=2, sodium_mg=50, sat_fat_g=None,
                    allergens=[], allergen_verified=True, diet_class="vegan", cuisine="indian", prep_time_min=5, tags=[])
        base.update(kw)
        self.__dict__.update(base)


def test_serving_scaling_150g_gives_30g_protein():
    n = scale_nutrients(F(protein_g=20), 150)
    assert n["protein_g"] == 30 and n["calories"] == 300
    assert n["fiber_g"] is None and "fiber_g" in n["missing"]          # missing stays missing, never silently 0


def test_constraints_allergy_diet_unknown():
    c = Constraints(diet="vegan", allergies={"peanut"})
    assert c.check(F())[0]
    assert not c.check(F(allergens=["peanut"]))[0]
    assert not c.check(F(allergen_verified=False))[0]                      # unknown allergen info is not "safe"
    assert not c.check(F(diet_class="vegetarian"))[0]
    assert not Constraints(diet="vegan").check(F(diet_class="unknown"))[0]
    assert Constraints(diet="non_vegetarian", strict=True).check(F(diet_class="unknown"))[0]
    assert not Constraints(lactose_free=True).check(F(allergens=["milk"]))[0]
    assert not Constraints(disliked=["tofu"]).check(F(name="Tofu, firm"))[0]
