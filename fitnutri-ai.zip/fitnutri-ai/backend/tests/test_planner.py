import pytest

from conftest import PROFILE, register


def foods_in(plan):
    return [(i["food_id"], i["food_name"]) for d in plan["days"] for m in d["meals"] for i in m["items"]]


def food_rows(client, ids):
    from app.models import Food
    with client.session_factory() as db:
        return {f.id: f for f in db.query(Food).filter(Food.id.in_(ids)).all()}


def test_plan_types_listed(client, auth):
    assert len(client.get("/api/meal-plans/plan-types", headers=auth).json()["items"]) == 17


def test_one_day_plan_is_complete_and_close_to_targets(client, auth):
    r = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 1}, headers=auth)
    assert r.status_code == 201, r.text
    p = r.json()
    day = p["days"][0]
    assert [m["slot"] for m in day["meals"]] == ["breakfast", "lunch", "evening_snack", "dinner"]
    for m in day["meals"]:
        assert m["items"] and m["instructions"] and m["rationale"] and m["totals"]["calories"] > 0 and "substitutions" in m
    assert abs(day["totals"]["calories"] - p["targets"]["calories"]) / p["targets"]["calories"] < 0.12
    assert abs(day["totals"]["protein_g"] - p["targets"]["protein_g"]) / p["targets"]["protein_g"] < 0.15
    assert p["total_cost_inr"] > 0 and "constraints_applied" in p and p["disclaimer"]


def test_weekly_plan_has_variety(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 7}, headers=auth).json()
    assert len(p["days"]) == 7
    dinners = [tuple(sorted(i["food_id"] for i in d["meals"][-1]["items"])) for d in p["days"]]
    assert len(set(dinners)) == 7                                             # no identical dinner twice
    lunches = [tuple(sorted(i["food_id"] for i in d["meals"][1]["items"])) for d in p["days"]]
    assert len(set(lunches)) == 7


@pytest.mark.parametrize("ptype,allowed", [("vegan_high_protein", {"vegan"}), ("vegetarian_muscle_gain", {"vegan", "vegetarian"}),
                                           ("eggetarian_bodybuilding", {"vegan", "vegetarian", "eggetarian"})])
def test_diet_restrictions_respected(client, auth, ptype, allowed):
    r = client.post("/api/meal-plans/generate", json={"plan_type": ptype, "days": 7}, headers=auth)
    assert r.status_code == 201, r.text
    p = r.json()
    rows = food_rows(client, {fid for fid, _ in foods_in(p)})
    assert all(rows[fid].diet_class in allowed for fid, _ in foods_in(p)), [n for fid, n in foods_in(p) if rows[fid].diet_class not in allowed]


def test_allergy_filtering_in_planner(client):
    prof = {**PROFILE, "allergies": ["peanuts", "dairy", "egg"], "diet_preference": "non_vegetarian"}
    h = register(client, profile=prof)
    r = client.post("/api/meal-plans/generate", json={"plan_type": "nonveg_bodybuilding", "days": 7}, headers=h)
    assert r.status_code == 201, r.text
    p = r.json()
    rows = food_rows(client, {fid for fid, _ in foods_in(p)})
    for fid, name in foods_in(p):
        assert not (set(rows[fid].allergens) & {"peanut", "milk", "egg"}), name
        assert rows[fid].allergen_verified


def test_unknown_allergen_foods_are_never_used_when_user_has_allergies(client):
    from app.models import Food
    with client.session_factory() as db:                     # a curated-looking food with UNKNOWN allergen info
        db.add(Food(name="Mystery protein", category="Meat & Poultry", calories=150, protein_g=30, carbs_g=0, fat_g=3, allergens=[], allergen_verified=False,
                    diet_class="non_vegetarian", meal_roles=["main_protein"], data_confidence="curated-approximate", price_per_100g=10))
        db.commit()
    h = register(client, profile={**PROFILE, "allergies": ["fish"]})
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 3}, headers=h).json()
    assert all(n != "Mystery protein" for _, n in foods_in(p))
    rec = client.get("/api/recommendations/foods", headers=h).json()
    assert all(i["food"]["name"] != "Mystery protein" for i in rec["items"])
    search = client.get("/api/foods", params={"q": "Mystery"}, headers=h).json()["items"][0]
    assert any("not verified" in w for w in search["warnings"])               # search shows an uncertainty warning rather than claiming safety


def test_lactose_gluten_and_dislikes(client):
    h = register(client, profile={**PROFILE, "disliked_foods": ["tofu", "chicken"]})
    for ptype, bad in (("lactose_free", {"milk"}), ("gluten_free", {"gluten"})):
        r = client.post("/api/meal-plans/generate", json={"plan_type": ptype, "days": 3}, headers=h)
        assert r.status_code == 201, r.text
        p = r.json()
        rows = food_rows(client, {fid for fid, _ in foods_in(p)})
        assert not any(set(rows[fid].allergens) & bad for fid, _ in foods_in(p))
        assert not any("tofu" in n.lower() or "chicken" in n.lower() for _, n in foods_in(p))


def test_no_cook_and_quick_plans(client, auth):
    r = client.post("/api/meal-plans/generate", json={"plan_type": "no_cook", "days": 3}, headers=auth)
    assert r.status_code == 201, r.text
    p = r.json()
    rows = food_rows(client, {fid for fid, _ in foods_in(p)})
    assert all("no_cook" in rows[fid].tags for fid, _ in foods_in(p))
    q = client.post("/api/meal-plans/generate", json={"plan_type": "student_quick", "days": 3}, headers=auth).json()
    rows = food_rows(client, {fid for fid, _ in foods_in(q)})
    assert all(rows[fid].prep_time_min <= 15 for fid, _ in foods_in(q))


def test_budget_plan_reports_cost_and_budget_warning(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "budget_bodybuilding", "days": 1, "daily_budget_inr": 60}, headers=auth).json()
    assert p["days"][0]["cost_inr"] > 0
    assert any("budget" in w.lower() for w in p["warnings"])                  # impossible budget is reported, not hidden


def test_impossible_constraints_return_closest_plan_with_explanation(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "vegan_high_protein", "days": 1, "calories": 4500, "protein_g": 330,
                                                      "exclude_foods": ["tofu", "soya", "dal", "chana", "rajma"]}, headers=auth)
    assert p.status_code == 201, p.text
    body = p.json()
    assert body["warnings"] and any("protein" in w.lower() or "calories" in w.lower() for w in body["warnings"])
    assert any("diet:" in c for c in body["constraints_applied"])


def test_no_foods_available_gives_clear_error(client, auth):
    r = client.post("/api/meal-plans/generate", json={"plan_type": "vegan_high_protein", "days": 1, "include_only": ["zzzz-nothing"]}, headers=auth)
    assert r.status_code == 422 and r.json()["error"]["code"] == "no_foods_available"


def test_regenerate_swap_replace_and_alternatives(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 2}, headers=auth).json()
    pid = p["id"]
    before = [i["food_id"] for i in p["days"][0]["meals"][1]["items"]]
    p2 = client.post(f"/api/meal-plans/{pid}/regenerate-meal", json={"day_index": 0, "slot": "lunch"}, headers=auth).json()
    after = [i["food_id"] for i in p2["days"][0]["meals"][1]["items"]]
    assert set(before) != set(after)
    meal_id = p2["days"][0]["meals"][1]["id"]
    alts = client.post(f"/api/meal-plans/{pid}/meals/{meal_id}/alternatives", json={"count": 3}, headers=auth).json()["alternatives"]
    assert len(alts) >= 2 and all(a["totals"]["calories"] > 0 for a in alts)
    applied = client.put(f"/api/meal-plans/{pid}/meals/{meal_id}/items", json={"items": [{"food_id": i["food_id"], "quantity_g": i["quantity_g"], "role": i["role"]} for i in alts[0]["items"]]}, headers=auth)
    assert applied.status_code == 200
    a, b = p2["days"][0]["meals"][3]["id"], p2["days"][1]["meals"][3]["id"]
    assert client.post(f"/api/meal-plans/{pid}/swap-meals", json={"meal_id_a": a, "meal_id_b": b}, headers=auth).status_code == 200
    assert client.post(f"/api/meal-plans/{pid}/swap-meals", json={"meal_id_a": p2["days"][0]["meals"][0]["id"], "meal_id_b": b}, headers=auth).status_code == 422
    item = p2["days"][0]["meals"][0]["items"][0]
    sub = client.get("/api/foods", params={"q": "Tofu", "source": "curated"}, headers=auth).json()["items"][0]["id"]
    rep = client.post(f"/api/meal-plans/{pid}/items/{item['id']}/replace", json={"food_id": sub}, headers=auth)
    assert rep.status_code == 200 and rep.json()["result"]["with"] == "Tofu, firm"
    assert client.put(f"/api/meal-plans/{pid}", json={"name": "Mine", "is_saved": True}, headers=auth).json()["is_saved"]


def test_replace_ingredient_respects_allergies(client):
    h = register(client, profile={**PROFILE, "allergies": ["soy"]})
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 1}, headers=h).json()
    tofu = client.get("/api/foods", params={"q": "Tofu", "source": "curated"}, headers=h).json()["items"][0]["id"]
    r = client.post(f"/api/meal-plans/{p['id']}/items/{p['days'][0]['meals'][0]['items'][0]['id']}/replace", json={"food_id": tofu}, headers=h)
    assert r.status_code == 422 and r.json()["error"]["code"] == "constraint_violation"


def test_restricted_users_cannot_generate_plans(client):
    h = register(client, profile={**PROFILE, "age": 15})
    r = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain"}, headers=h)
    assert r.status_code == 409 and r.json()["error"]["code"] == "plan_not_available"
    h2 = register(client, email="x@example.com", profile={**PROFILE, "eating_disorder_concern": True})
    assert client.post("/api/meal-plans/generate", json={"plan_type": "fat_loss"}, headers=h2).status_code == 409


def test_incomplete_profile_needs_targets(client):
    h = register(client, email="new@example.com")
    r = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain"}, headers=h)
    assert r.status_code == 422 and r.json()["error"]["code"] == "profile_incomplete"
    assert client.post("/api/meal-plans/generate", json={"plan_type": "custom", "calories": 2200, "protein_g": 140}, headers=h).status_code == 201


def test_plan_logging_to_diary(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain"}, headers=auth).json()
    m = p["days"][0]["meals"][0]
    assert client.post(f"/api/meal-plans/{p['id']}/meals/{m['id']}/log", json={"log_date": "2025-03-03"}, headers=auth).status_code == 201
    assert abs(client.get("/api/diary", params={"date": "2025-03-03"}, headers=auth).json()["totals"]["calories"] - m["totals"]["calories"]) < 1


def test_grocery_from_plan_combines_duplicates_and_exports(client, auth):
    p = client.post("/api/meal-plans/generate", json={"plan_type": "muscle_gain", "days": 7}, headers=auth).json()
    g = client.post(f"/api/grocery/from-plan/{p['id']}", json={}, headers=auth).json()
    names = [i["name"] for i in g["items"]]
    assert len(names) == len(set(names))                                     # duplicates combined
    eaten = {}
    for d in p["days"]:
        for m in d["meals"]:
            for i in m["items"]:
                eaten[i["food_name"]] = eaten.get(i["food_name"], 0) + i["quantity_g"]
    rice = next((i for i in g["items"] if i["name"].startswith("Rice, white")), None)
    if rice:                                                                  # cooked grams are converted to dry purchase grams
        assert rice["quantity_g"] == pytest.approx(eaten["Rice, white, cooked"] * 0.35, abs=1)
    assert g["est_total_cost_inr"] > 0
    iid = g["items"][0]["id"]
    assert client.patch(f"/api/grocery/{g['id']}/items/{iid}", json={"purchased": True}, headers=auth).json()["purchased_count"] == 1
    assert client.patch(f"/api/grocery/{g['id']}/items/{iid}", json={"quantity_g": 777}, headers=auth).status_code == 200
    csv = client.get(f"/api/grocery/{g['id']}/export.csv", headers=auth)
    assert csv.status_code == 200 and "TOTAL" in csv.text
    n = len(g["items"])
    assert len(client.delete(f"/api/grocery/{g['id']}/items/{iid}", headers=auth).json()["items"]) == n - 1
    assert client.post(f"/api/grocery/{g['id']}/items", json={"name": "Salt", "quantity_g": 500}, headers=auth).status_code == 201
    prep = client.get(f"/api/grocery/meal-prep/{p['id']}", headers=auth).json()
    assert "batches" in prep and prep["storage_guidance"] and prep["source_note"]
