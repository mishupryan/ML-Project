import pytest

from app import config


def _settings(monkeypatch, **env):
    for k in ("APP_ENV", "SECRET_KEY", "DATABASE_URL"):
        monkeypatch.delenv(k, raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, v)
    return config.Settings()


def test_dev_defaults_boot(monkeypatch):
    s = _settings(monkeypatch)
    assert not s.is_production
    s.validate_for_production()  # no error in development


def test_production_rejects_default_or_short_secret(monkeypatch):
    with pytest.raises(RuntimeError):
        _settings(monkeypatch, APP_ENV="production").validate_for_production()
    with pytest.raises(RuntimeError):
        _settings(monkeypatch, APP_ENV="production", SECRET_KEY="short").validate_for_production()


def test_production_accepts_strong_secret(monkeypatch):
    _settings(monkeypatch, APP_ENV="production", SECRET_KEY="x" * 48).validate_for_production()


@pytest.mark.parametrize("given,expected", [
    ("postgres://u:p@h:5432/db", "postgresql+psycopg://u:p@h:5432/db"),
    ("postgresql://u:p@h/db", "postgresql+psycopg://u:p@h/db"),
    ("postgresql+psycopg://u:p@h/db", "postgresql+psycopg://u:p@h/db"),
    ("sqlite:///x.db", "sqlite:///x.db"),
])
def test_database_url_normalised(monkeypatch, given, expected):
    assert _settings(monkeypatch, DATABASE_URL=given).database_url == expected
