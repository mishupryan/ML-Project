#!/bin/sh
# Container start-up: migrate the database, load foods (idempotent), then serve the API + frontend.
set -eu
cd /app

if [ "${RUN_MIGRATIONS:-true}" = "true" ]; then
  ARGS=""
  [ "${SEED_DEMO:-false}" = "true" ] || ARGS="$ARGS --no-demo"
  [ "${IMPORT_DATASET:-true}" = "true" ] || ARGS="$ARGS --no-import"
  echo "[entrypoint] migrating + seeding database (args:${ARGS:- none})"
  python scripts/seed_database.py $ARGS
fi

echo "[entrypoint] starting server on port ${PORT:-8000} with ${WEB_CONCURRENCY:-2} worker(s)"
cd backend
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" --workers "${WEB_CONCURRENCY:-2}" \
  --proxy-headers --forwarded-allow-ips "*"
