const KEY = "fitnutri_token";
export const token = {
  get: () => localStorage.getItem(KEY),
  set: (t) => localStorage.setItem(KEY, t),
  clear: () => localStorage.removeItem(KEY),
};

export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status; this.code = code; this.details = details;
  }
}

function qs(params) {
  const p = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") p.append(k, v);
  });
  const s = p.toString();
  return s ? "?" + s : "";
}

async function raw(path, { method = "GET", body, params } = {}) {
  const headers = {};
  const t = token.get();
  if (t) headers.Authorization = "Bearer " + t;
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const res = await fetch("/api" + path + qs(params), { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  if (res.status === 401 && t && !path.startsWith("/auth/")) {
    token.clear();
    window.dispatchEvent(new Event("fn:logout"));
  }
  return res;
}

export async function api(path, opts) {
  const res = await raw(path, opts);
  if (res.status === 204) return null;
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON body */ }
  if (!res.ok) {
    const e = data?.error || {};
    const detail = Array.isArray(e.details) && e.details.length ? " " + e.details.map((d) => `${d.field}: ${d.message}`).join("; ") : "";
    throw new ApiError(res.status, e.code || "error", (e.message || `Request failed (${res.status})`) + detail, e.details);
  }
  return data;
}

export async function download(path, filename, params) {
  const res = await raw(path, { params });
  if (!res.ok) throw new ApiError(res.status, "download_failed", "Could not download the file.");
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export const todayISO = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
export const shiftDate = (iso, days) => {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + days);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
export const num = (v, d = 0) => (v === null || v === undefined || Number.isNaN(+v) ? "–" : (+v).toFixed(d));
export const label = (s) => String(s || "").replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
