import { useCallback, useEffect, useState } from "react";

export function useAsync(fn, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const run = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try { setState({ data: await fn(), error: null, loading: false }); }
    catch (e) { setState({ data: null, error: e, loading: false }); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...state, reload: run };
}

export const Card = ({ title, actions, children, className = "" }) => (
  <section className={"card " + className}>
    {(title || actions) && <header className="card-h"><h3>{title}</h3><div className="row">{actions}</div></header>}
    {children}
  </section>
);

export const Spinner = () => <div className="spinner" role="status" aria-label="Loading" />;
export const ErrorMsg = ({ error }) => error ? <div className="alert err" role="alert">{error.message || String(error)}</div> : null;
export const Notice = ({ children, kind = "info" }) => children ? <div className={"alert " + kind}>{children}</div> : null;

export function Async({ state, children }) {
  if (state.loading && !state.data) return <Spinner />;
  if (state.error) return <ErrorMsg error={state.error} />;
  return state.data ? children(state.data) : null;
}

export const Field = ({ label, children, hint }) => (
  <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>
);

export function Bar({ value = 0, max = 1, label, unit = "", warn }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const over = max > 0 && value > max * 1.1;
  return (
    <div className="bar-row">
      <div className="bar-top"><span>{label}</span><span>{Math.round(value)} / {Math.round(max)}{unit}</span></div>
      <div className="bar"><div className={"bar-fill" + (over || warn ? " over" : "")} style={{ width: pct + "%" }} /></div>
    </div>
  );
}

export function Modal({ title, onClose, children }) {
  useEffect(() => {
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="modal-bg" onMouseDown={onClose}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.stopPropagation()}>
        <header className="card-h"><h3>{title}</h3><button className="btn ghost" onClick={onClose} aria-label="Close">✕</button></header>
        {children}
      </div>
    </div>
  );
}

export function LineChart({ points, height = 140, unit = "" }) {
  if (!points || points.length < 2) return <p className="muted">Log at least two entries to see a trend.</p>;
  const w = 600, pad = 28;
  const ys = points.map((p) => p.y);
  const min = Math.min(...ys), max = Math.max(...ys), span = max - min || 1;
  const x = (i) => pad + (i * (w - pad * 2)) / (points.length - 1);
  const y = (v) => height - pad - ((v - min) / span) * (height - pad * 2);
  const d = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.y).toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="chart" role="img" aria-label="Trend chart">
      <path d={d} fill="none" stroke="var(--accent)" strokeWidth="2.5" strokeLinejoin="round" />
      {points.map((p, i) => <circle key={i} cx={x(i)} cy={y(p.y)} r="3.5" fill="var(--accent)"><title>{p.x}: {p.y}{unit}</title></circle>)}
      <text x={pad} y={height - 6} className="axis">{points[0].x}</text>
      <text x={w - pad} y={height - 6} className="axis" textAnchor="end">{points[points.length - 1].x}</text>
      <text x={pad} y={14} className="axis">{max}{unit}</text>
      <text x={pad} y={height - pad + 14} className="axis">{min}{unit}</text>
    </svg>
  );
}

export function BarChart({ items, height = 130 }) {
  const max = Math.max(1, ...items.map((i) => i.value || 0));
  return (
    <div className="bars" style={{ height }}>
      {items.map((i, k) => (
        <div key={k} className="bars-col" title={`${i.label}: ${i.value ?? "no data"}`}>
          <div className={"bars-bar" + (i.value == null ? " empty" : "")} style={{ height: i.value == null ? "4px" : Math.max(4, (i.value / max) * (height - 28)) + "px" }} />
          <span>{i.label}</span>
        </div>
      ))}
    </div>
  );
}

export const csvList = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean);
