import { useEffect, useState } from "react";
import { api, label } from "../api.js";
import { useAuth } from "../App.jsx";
import { Async, Card, ErrorMsg, Field, Notice, csvList, useAsync } from "../ui.jsx";

const GOALS = ["muscle_gain", "lean_bulk", "fat_loss", "recomposition", "maintenance", "general_fitness", "improve_protein", "healthy_habits"];
const ACT = ["sedentary", "light", "moderate", "very_active", "extra_active"];
const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const FLAGS = ["high_protein", "balanced", "indian_home_style", "mediterranean", "budget_friendly", "lactose_free", "gluten_free"];
const ALLERGENS = ["milk", "egg", "fish", "shellfish", "peanut", "tree_nut", "soy", "gluten", "sesame", "mustard"];
const NUMS = ["age", "height_cm", "weight_kg", "target_weight_kg", "daily_budget", "water_target_ml", "meals_per_day", "cooking_time_pref_min"];
const LISTS = ["liked_foods", "disliked_foods", "cooking_equipment"];
const KEYS = ["age", "sex", "height_cm", "weight_kg", "target_weight_kg", "activity_level", "goal", "diet_preference", "diet_flags", "allergies", "liked_foods", "disliked_foods",
  "preferred_cuisine", "meals_per_day", "daily_budget", "cooking_equipment", "cooking_time_pref_min", "workout_days", "workout_time", "wake_time", "sleep_time",
  "medical_or_pregnancy_flag", "eating_disorder_concern", "water_enabled", "water_target_ml", "timezone"];

export default function Profile() {
  const { user } = useAuth();
  const prof = useAsync(() => api("/profile"));
  const targets = useAsync(() => api("/nutrition/targets"));
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);
  const [t, setT] = useState(null);

  useEffect(() => {
    if (!prof.data) return;
    const x = {}; KEYS.forEach((k) => { const v = prof.data[k]; x[k] = LISTS.includes(k) ? (v || []).join(", ") : v ?? (NUMS.includes(k) ? "" : v); });
    setF(x);
  }, [prof.data]);
  useEffect(() => { if (targets.data) setT(Object.fromEntries(["calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "water_ml"].map((k) => [k, targets.data.targets?.[k] ?? ""]))); }, [targets.data]);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const toggle = (k, v) => setF({ ...f, [k]: f[k]?.includes(v) ? f[k].filter((x) => x !== v) : [...(f[k] || []), v] });

  async function save(e) {
    e.preventDefault(); setErr(null); setMsg(null);
    const body = {};
    KEYS.forEach((k) => {
      let v = f[k];
      if (NUMS.includes(k)) v = v === "" || v === null ? null : +v;
      else if (LISTS.includes(k)) v = csvList(v);
      else if (v === "") v = null;
      body[k] = v;
    });
    try { await api("/profile", { method: "PUT", body }); setMsg("Profile saved. Targets recalculated."); prof.reload(); targets.reload(); }
    catch (x) { setErr(x); }
  }
  async function saveTargets(e) {
    e.preventDefault(); setErr(null); setMsg(null);
    try { const body = {}; Object.entries(t).forEach(([k, v]) => { if (v !== "" && v !== null) body[k] = +v; }); await api("/nutrition/targets", { method: "PUT", body }); setMsg("Custom targets saved."); targets.reload(); }
    catch (x) { setErr(x); }
  }

  return (
    <>
      <h1>Profile & targets</h1>
      <p className="muted">{user.email}</p>
      {msg && <Notice>{msg}</Notice>}<ErrorMsg error={err} />
      <Async state={targets}>{(d) => (
        <Card title="Daily targets" actions={<>{d.targets?.is_manual && <span className="pill warn">custom</span>}
          <button className="btn ghost sm" onClick={async () => { await api("/nutrition/targets/reset", { method: "POST" }); targets.reload(); setMsg("Targets reset to the estimate."); }}>Reset to estimate</button></>}>
          {d.estimate?.warnings?.map((w, i) => <Notice key={i} kind="warn">{w}</Notice>)}
          {t && <form className="form" onSubmit={saveTargets}>
            {[["calories", "Calories"], ["protein_g", "Protein (g)"], ["carbs_g", "Carbs (g)"], ["fat_g", "Fat (g)"], ["fiber_g", "Fibre (g)"], ["water_ml", "Water (ml)"]].map(([k, l]) => (
              <Field key={k} label={l}><input type="number" value={t[k]} onChange={(e) => setT({ ...t, [k]: e.target.value })} /></Field>))}
            <button className="btn">Save custom targets</button></form>}
          <small>{d.estimate?.method}. {(d.estimate?.limitations || [])[0]}</small>
        </Card>)}</Async>
      <Async state={prof}>{() => f && (
        <form className="grid" onSubmit={save}>
          <Card title="About you"><div className="form">
            <Field label="Age"><input type="number" min="10" max="100" value={f.age} onChange={set("age")} /></Field>
            <Field label="Sex"><select value={f.sex || ""} onChange={set("sex")}><option value="">–</option>{["male", "female", "other"].map((s) => <option key={s}>{s}</option>)}</select></Field>
            <Field label="Height (cm)"><input type="number" step="0.1" value={f.height_cm} onChange={set("height_cm")} /></Field>
            <Field label="Weight (kg)"><input type="number" step="0.1" value={f.weight_kg} onChange={set("weight_kg")} /></Field>
            <Field label="Target weight (kg)"><input type="number" step="0.1" value={f.target_weight_kg} onChange={set("target_weight_kg")} /></Field>
            <Field label="Activity"><select value={f.activity_level || ""} onChange={set("activity_level")}><option value="">–</option>{ACT.map((s) => <option key={s} value={s}>{label(s)}</option>)}</select></Field>
            <Field label="Goal"><select value={f.goal || ""} onChange={set("goal")}><option value="">–</option>{GOALS.map((s) => <option key={s} value={s}>{label(s)}</option>)}</select></Field>
          </div></Card>
          <Card title="Food preferences"><div className="form">
            <Field label="Diet"><select value={f.diet_preference || ""} onChange={set("diet_preference")}><option value="">–</option>{["vegan", "vegetarian", "eggetarian", "pescatarian", "non_vegetarian"].map((s) => <option key={s} value={s}>{label(s)}</option>)}</select></Field>
            <Field label="Meals per day"><select value={f.meals_per_day || ""} onChange={set("meals_per_day")}><option value="">–</option>{[3, 4, 5, 6].map((n) => <option key={n}>{n}</option>)}</select></Field>
            <Field label="Daily budget (₹)"><input type="number" min="0" value={f.daily_budget} onChange={set("daily_budget")} /></Field>
            <Field label="Cuisine"><input value={f.preferred_cuisine || ""} onChange={set("preferred_cuisine")} /></Field>
            <Field label="Liked foods"><input value={f.liked_foods} onChange={set("liked_foods")} placeholder="paneer, dal" /></Field>
            <Field label="Disliked foods"><input value={f.disliked_foods} onChange={set("disliked_foods")} /></Field>
            <div className="wide"><strong>Allergies</strong><div className="row">{ALLERGENS.map((a) => <label key={a} className="row"><input type="checkbox" checked={f.allergies?.includes(a)} onChange={() => toggle("allergies", a)} />{label(a)}</label>)}</div></div>
            <div className="wide"><strong>Style</strong><div className="row">{FLAGS.map((a) => <label key={a} className="row"><input type="checkbox" checked={f.diet_flags?.includes(a)} onChange={() => toggle("diet_flags", a)} />{label(a)}</label>)}</div></div>
          </div></Card>
          <Card title="Training & routine"><div className="form">
            <div className="wide"><strong>Workout days</strong><div className="row">{DAYS.map((a) => <label key={a} className="row"><input type="checkbox" checked={f.workout_days?.includes(a)} onChange={() => toggle("workout_days", a)} />{a}</label>)}</div></div>
            <Field label="Workout time"><input type="time" value={f.workout_time || ""} onChange={set("workout_time")} /></Field>
            <Field label="Wake time"><input type="time" value={f.wake_time || ""} onChange={set("wake_time")} /></Field>
            <Field label="Sleep time"><input type="time" value={f.sleep_time || ""} onChange={set("sleep_time")} /></Field>
            <Field label="Timezone"><input value={f.timezone || ""} onChange={set("timezone")} placeholder="Asia/Kolkata" /></Field>
            <label className="row"><input type="checkbox" checked={!!f.water_enabled} onChange={set("water_enabled")} /> Track water</label>
            <Field label="Water target (ml)"><input type="number" value={f.water_target_ml} onChange={set("water_target_ml")} /></Field>
          </div></Card>
          <Card title="Health safeguards">
            <label className="row"><input type="checkbox" checked={!!f.medical_or_pregnancy_flag} onChange={set("medical_or_pregnancy_flag")} /> I am pregnant or have a medical condition affecting diet</label>
            <label className="row"><input type="checkbox" checked={!!f.eating_disorder_concern} onChange={set("eating_disorder_concern")} /> I have, or have had, an eating-disorder concern</label>
            <small>If either is ticked, FitNutri limits aggressive targets and recommends speaking to a qualified professional.</small>
          </Card>
          <div><button className="btn">Save profile</button></div>
        </form>)}</Async>
    </>
  );
}
