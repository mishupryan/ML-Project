import { useEffect, useState } from "react";
import { api, label, num, todayISO } from "../api.js";
import FoodPicker from "../FoodPicker.jsx";
import { Card, ErrorMsg, Field, Notice } from "../ui.jsx";

const EMPTY = { name: "", calories: "", protein_g: "", carbs_g: "", fat_g: "", fiber_g: "" };

export default function Foods() {
  const [f, setF] = useState({ q: "", category: "", diet: "", sort: "relevance", min_protein: "", max_calories: "", source: "all" });
  const [cats, setCats] = useState({ categories: [], diets: [] });
  const [res, setRes] = useState({ items: [], total: 0 });
  const [pick, setPick] = useState(null);
  const [err, setErr] = useState(null);
  const [custom, setCustom] = useState(null);
  const [saved, setSaved] = useState("");

  useEffect(() => { api("/foods/categories").then(setCats).catch(setErr); }, []);
  useEffect(() => {
    const t = setTimeout(() => api("/foods", { params: { ...f, limit: 40 } }).then((r) => { setRes(r); setErr(null); }).catch(setErr), 300);
    return () => clearTimeout(t);
  }, [f]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function saveCustom(e) {
    e.preventDefault(); setErr(null);
    try {
      const body = { name: custom.name, calories: +custom.calories };
      ["protein_g", "carbs_g", "fat_g", "fiber_g"].forEach((k) => { if (custom[k] !== "") body[k] = +custom[k]; });
      await api("/foods", { method: "POST", body });
      setSaved(`Added “${custom.name}”.`); setCustom(null); setF({ ...f });
    } catch (x) { setErr(x); }
  }

  return (
    <>
      <div className="page-h"><h1>Food database</h1><button className="btn ghost" onClick={() => setCustom(custom ? null : { ...EMPTY })}>+ Custom food</button></div>
      <Notice kind="warn">Values are approximate generic references, not lab-verified or brand data. Check your own labels.</Notice>
      {saved && <Notice>{saved}</Notice>}
      {custom && (
        <Card title="New custom food (values per 100 g)">
          <form className="form" onSubmit={saveCustom}>
            <Field label="Name"><input required value={custom.name} onChange={(e) => setCustom({ ...custom, name: e.target.value })} /></Field>
            {[["calories", "Calories (kcal)"], ["protein_g", "Protein (g)"], ["carbs_g", "Carbs (g)"], ["fat_g", "Fat (g)"], ["fiber_g", "Fibre (g)"]].map(([k, l]) => (
              <Field key={k} label={l}><input type="number" step="0.1" min="0" required={k === "calories"} value={custom[k]} onChange={(e) => setCustom({ ...custom, [k]: e.target.value })} /></Field>))}
            <button className="btn">Save food</button>
          </form>
        </Card>
      )}
      <Card>
        <div className="form">
          <Field label="Search"><input value={f.q} onChange={set("q")} placeholder="paneer, oats…" /></Field>
          <Field label="Category"><select value={f.category} onChange={set("category")}><option value="">All</option>{cats.categories.map((c) => <option key={c}>{c}</option>)}</select></Field>
          <Field label="Diet"><select value={f.diet} onChange={set("diet")}><option value="">Any</option>{cats.diets.map((c) => <option key={c} value={c}>{label(c)}</option>)}</select></Field>
          <Field label="Source"><select value={f.source} onChange={set("source")}><option value="all">All</option><option value="curated">Curated</option><option value="imported">Imported</option><option value="custom">My foods</option></select></Field>
          <Field label="Min protein /100 g"><input type="number" value={f.min_protein} onChange={set("min_protein")} /></Field>
          <Field label="Max kcal /100 g"><input type="number" value={f.max_calories} onChange={set("max_calories")} /></Field>
          <Field label="Sort"><select value={f.sort} onChange={set("sort")}>{["relevance", "name", "protein", "protein_density", "calories", "price"].map((s) => <option key={s} value={s}>{label(s)}</option>)}</select></Field>
        </div>
      </Card>
      <ErrorMsg error={err} />
      <Card title={`${res.total} foods`}>
        <div className="list">{res.items.map((x) => (
          <div key={x.id} className="item">
            <div><strong>{x.name}</strong> <span className="pill">{x.category}</span> {x.data_confidence === "imported-unverified" && <span className="pill warn">unverified</span>}<br />
              <small>Per 100 g: {num(x.per_100g.calories)} kcal · P {num(x.per_100g.protein_g, 1)} · C {num(x.per_100g.carbs_g, 1)} · F {num(x.per_100g.fat_g, 1)} {x.price_per_serving != null && `· ≈ ₹${num(x.price_per_serving)}/serving`}</small></div>
            <button className="btn sm" onClick={() => setPick(x)}>Log</button>
          </div>))}</div>
      </Card>
      {pick && <FoodPicker preselected={pick} date={todayISO()} onClose={() => setPick(null)} defaultMeal="lunch" />}
    </>
  );
}
