import { useEffect, useRef, useState } from "react";
import { api, download, label, num } from "../api.js";
import { Async, Bar, BarChart, Card, ErrorMsg, Field, Notice, useAsync } from "../ui.jsx";

const TABS = [["recs", "Recommendations"], ["report", "Weekly report"], ["chat", "Assistant"], ["ml", "ML models"]];

export default function Insights() {
  const [tab, setTab] = useState("recs");
  return (
    <>
      <h1>Insights</h1>
      <div className="tabs">{TABS.map(([k, t]) => <button key={k} className={"tab" + (tab === k ? " on" : "")} onClick={() => setTab(k)}>{t}</button>)}</div>
      {tab === "recs" && <Recs />}{tab === "report" && <Report />}{tab === "chat" && <Chat />}{tab === "ml" && <ML />}
    </>
  );
}

function Recs() {
  const [ctx, setCtx] = useState("general");
  const r = useAsync(() => api("/recommendations/foods", { params: { context: ctx, limit: 6 } }), [ctx]);
  const [msg, setMsg] = useState(null);
  const fb = async (id, rating) => { try { await api("/recommendations/feedback", { method: "POST", body: { food_id: id, rating, context: ctx } }); setMsg("Thanks, feedback saved."); } catch (e) { setMsg(e.message); } };
  return (
    <Card title="What to eat next" actions={<select value={ctx} onChange={(e) => setCtx(e.target.value)} style={{ width: "auto" }}>
      {["general", "pre_workout", "post_workout", "budget", "quick", "high_fiber", "high_protein"].map((c) => <option key={c} value={c}>{label(c)}</option>)}</select>}>
      <Async state={r}>{(d) => (<>
        <p className="muted">Remaining today: {num(d.remaining.calories)} kcal, {num(d.remaining.protein_g)} g protein. Method: {d.method}.</p>
        {msg && <Notice>{msg}</Notice>}
        <div className="list">{d.items.map((x) => (
          <div key={x.food.id} className="item"><div><strong>{x.food.name}</strong> <span className="pill">{x.display_qty}</span> <span className="pill">score {Math.round(x.score)}</span><br /><small>{x.explanation}</small></div>
            <div className="row"><button className="btn ghost sm" aria-label="Good suggestion" onClick={() => fb(x.food.id, 1)}>👍</button><button className="btn ghost sm" aria-label="Bad suggestion" onClick={() => fb(x.food.id, -1)}>👎</button></div></div>))}</div>
      </>)}</Async>
    </Card>
  );
}

function Report() {
  const r = useAsync(() => api("/reports/weekly"));
  const [err, setErr] = useState(null);
  return (
    <Async state={r}>{(d) => (
      <>
        <Card title={`${d.start} → ${d.end}`} actions={<button className="btn ghost sm" onClick={() => download("/reports/weekly.csv", "weekly-report.csv").catch(setErr)}>Export CSV</button>}>
          <BarChart items={d.days.map((x) => ({ label: x.date.slice(8), value: x.calories != null ? Math.round(x.calories) : null }))} />
          <small>Calories per day. Grey bars are days with nothing logged (not zero).</small>
          <ErrorMsg error={err} />
          <p>Logged <strong>{d.days_logged}</strong> day(s), <strong>{d.days_not_logged}</strong> not logged. Averages on logged days: {num(d.averages_logged_days.calories)} kcal, {num(d.averages_logged_days.protein_g)} g protein.</p>
          {d.adherence && <><Bar label="Days within 10% of calorie target" value={d.adherence.days_within_10pct_calories} max={d.adherence.logged_days || 1} />
            <Bar label="Days protein ≥ 90% of target" value={d.adherence.days_protein_at_least_90pct} max={d.adherence.logged_days || 1} /></>}
          {d.cost && <p className="muted">Estimated spend ≈ ₹{num(d.cost.estimated_spend_inr)} (illustrative prices).</p>}
        </Card>
        <Card title="Top foods"><div className="list">{d.top_foods.map((f) => <div key={f.food} className="item"><span>{f.food}</span><span className="pill">{f.times_logged}×</span></div>)}</div></Card>
        {d.suggestions?.map((s, i) => <Notice key={i}>{s}</Notice>)}
        <small>{d.disclaimer}</small>
      </>)}</Async>
  );
}

function Chat() {
  const ex = useAsync(() => api("/chat/examples"));
  const [log, setLog] = useState([]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [log]);
  async function send(text) {
    if (!text.trim() || busy) return;
    setLog((l) => [...l, { me: true, text }]); setMsg(""); setBusy(true);
    try { const r = await api("/chat", { method: "POST", body: { message: text } }); setLog((l) => [...l, { text: r.reply, note: r.disclaimer }]); }
    catch (e) { setLog((l) => [...l, { text: "Sorry: " + e.message }]); } finally { setBusy(false); }
  }
  return (
    <Card title="Nutrition assistant">
      <Notice>This is a rule-based assistant using your profile, diary and the food database. It is not an AI language model and not medical advice.</Notice>
      <div className="chat">{log.map((m, i) => <div key={i} className={"bubble" + (m.me ? " me" : "")}>{m.text}</div>)}<div ref={end} /></div>
      {!log.length && <div className="row">{(ex.data?.examples || []).slice(0, 5).map((e) => <button key={e} className="btn ghost sm" onClick={() => send(e)}>{e}</button>)}</div>}
      <form className="row" onSubmit={(e) => { e.preventDefault(); send(msg); }}>
        <input value={msg} maxLength={1000} onChange={(e) => setMsg(e.target.value)} placeholder="Ask about foods, protein, meals…" style={{ flex: 1 }} />
        <button className="btn" disabled={busy}>Send</button></form>
    </Card>
  );
}

function ML() {
  const st = useAsync(() => api("/ml/status"));
  const [n, setN] = useState({ calories: 120, protein_g: 20, carbs_g: 2, fat_g: 4, fiber_g: "", sugar_g: "", sodium_mg: "" });
  const [res, setRes] = useState(null);
  const [err, setErr] = useState(null);
  async function predict(e) {
    e.preventDefault(); setErr(null);
    try {
      const nutrients = {}; Object.entries(n).forEach(([k, v]) => { if (v !== "") nutrients[k] = +v; });
      setRes(await api("/ml/predict-food-category", { method: "POST", body: { nutrients } }));
    } catch (x) { setErr(x); }
  }
  return (
    <>
      <Async state={st}>{(d) => (
        <Card title="Model status"><div className="list">{Object.entries(d.models).map(([k, m]) => (
          <div key={k}><strong>{m.label}</strong> {m.available ? <span className="pill">v{m.version}</span> : <span className="pill warn">not trained</span>}<br />
            {m.available ? <small>Serving model: {m.serving_model} · test accuracy {num((m.test_metrics_serving_model?.accuracy || 0) * 100, 1)}% · macro-F1 {num(m.test_metrics_serving_model?.macro_f1, 3)} · majority baseline {num((m.majority_baseline_test_accuracy || 0) * 100, 1)}%</small> : <small>{m.message}</small>}</div>))}</div></Card>)}</Async>
      <Card title="Predict a food's category from nutrients (per 100 g)">
        <form className="form" onSubmit={predict}>
          {Object.keys(n).map((k) => <Field key={k} label={label(k)}><input type="number" step="0.1" min="0" required={k === "calories"} value={n[k]} onChange={(e) => setN({ ...n, [k]: e.target.value })} /></Field>)}
          <button className="btn">Predict</button></form>
        <ErrorMsg error={err} />
        {res && (res.available ? (<>
          <p>Prediction: <strong>{res.prediction}</strong> <small>({res.method})</small></p>
          {res.probabilities.map((p) => <Bar key={p.label} label={p.label} value={p.probability * 100} max={100} unit="%" />)}
          {res.warning && <Notice kind="warn">{res.warning}</Notice>}<small>{res.limitations}</small></>) : <Notice kind="warn">{res.message}</Notice>)}
      </Card>
    </>
  );
}
