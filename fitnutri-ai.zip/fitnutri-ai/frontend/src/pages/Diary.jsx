import { useState } from "react";
import { api, download, label, num, shiftDate, todayISO } from "../api.js";
import FoodPicker from "../FoodPicker.jsx";
import { Async, Card, ErrorMsg, useAsync } from "../ui.jsx";

export default function Diary() {
  const [date, setDate] = useState(todayISO());
  const [adding, setAdding] = useState(false);
  const [err, setErr] = useState(null);
  const d = useAsync(() => api("/diary", { params: { date } }), [date]);
  const run = async (fn) => { setErr(null); try { await fn(); d.reload(); } catch (e) { setErr(e); } };
  const edit = (e) => { const v = window.prompt(`New quantity in grams for ${e.label}`, e.quantity_g); if (v && +v > 0) run(() => api(`/diary/${e.id}`, { method: "PUT", body: { quantity_g: +v } })); };

  return (
    <>
      <div className="page-h"><h1>Food diary</h1>
        <div className="row">
          <button className="btn ghost sm" onClick={() => setDate(shiftDate(date, -1))} aria-label="Previous day">‹</button>
          <input type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} style={{ width: "auto" }} />
          <button className="btn ghost sm" onClick={() => setDate(shiftDate(date, 1))} aria-label="Next day">›</button>
          <button className="btn" onClick={() => setAdding(true)}>+ Add food</button>
        </div>
      </div>
      <ErrorMsg error={err} />
      <Async state={d}>{(data) => (
        <>
          <Card title="Totals" actions={<>
            <button className="btn ghost sm" onClick={() => run(() => api("/diary/copy", { method: "POST", body: { from_date: shiftDate(date, -1), to_date: date } }))}>Copy from yesterday</button>
            <button className="btn ghost sm" onClick={() => download("/diary/export.csv", `diary-${date}.csv`, { start: date, end: date }).catch(setErr)}>Export CSV</button></>}>
            <p><strong>{num(data.totals.calories)}</strong> kcal · <strong>{num(data.totals.protein_g, 1)}</strong> g protein · {num(data.totals.carbs_g, 1)} g carbs · {num(data.totals.fat_g, 1)} g fat · {num(data.totals.fiber_g, 1)} g fibre</p>
            {!data.entries_count && <p className="muted">No entries for this day.</p>}
          </Card>
          {data.meals.map((m) => (
            <Card key={m.meal_type} title={label(m.meal_type)} actions={<span className="muted">{num(m.totals.calories)} kcal</span>}>
              <table><thead><tr><th>Food</th><th className="num">g</th><th className="num">kcal</th><th className="num">Protein</th><th /></tr></thead>
                <tbody>{m.entries.map((e) => (
                  <tr key={e.id}><td>{e.label}</td><td className="num">{num(e.quantity_g)}</td><td className="num">{num(e.calories)}</td><td className="num">{num(e.protein_g, 1)}</td>
                    <td className="num"><button className="btn ghost sm" onClick={() => edit(e)}>Edit</button> <button className="btn danger sm" onClick={() => run(() => api(`/diary/${e.id}`, { method: "DELETE" }))} aria-label={`Delete ${e.label}`}>✕</button></td></tr>
                ))}</tbody></table>
            </Card>
          ))}
        </>
      )}</Async>
      {adding && <FoodPicker date={date} onClose={() => setAdding(false)} onLogged={d.reload} />}
    </>
  );
}
