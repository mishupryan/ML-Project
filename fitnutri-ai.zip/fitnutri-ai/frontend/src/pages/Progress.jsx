import { useState } from "react";
import { api, download, num, todayISO } from "../api.js";
import { Async, Bar, Card, ErrorMsg, Field, LineChart, Notice, useAsync } from "../ui.jsx";

export default function Progress() {
  const p = useAsync(() => api("/progress", { params: { days: 120 } }));
  const [w, setW] = useState("");
  const [m, setM] = useState({ waist_cm: "", chest_cm: "", arm_cm: "", thigh_cm: "", body_fat_pct: "" });
  const [err, setErr] = useState(null);
  const run = async (fn) => { setErr(null); try { await fn(); p.reload(); } catch (e) { setErr(e); } };

  return (
    <>
      <div className="page-h"><h1>Progress</h1><button className="btn ghost" onClick={() => download("/progress/export.csv", "progress.csv").catch(setErr)}>Export CSV</button></div>
      <ErrorMsg error={err} />
      <Async state={p}>{(d) => (
        <>
          <div className="grid g2">
            <Card title="Weight">
              <LineChart points={d.weights.map((x) => ({ x: x.log_date, y: x.weight_kg }))} unit=" kg" />
              {d.trend && <p className="muted">{d.trend.weekly_change_kg >= 0 ? "+" : ""}{num(d.trend.weekly_change_kg, 2)} kg/week over {d.trend.days} days. {d.trend.note}</p>}
              <form className="row" onSubmit={(e) => { e.preventDefault(); run(async () => { await api("/progress/weight", { method: "POST", body: { weight_kg: +w, log_date: todayISO() } }); setW(""); }); }}>
                <input type="number" step="0.1" min="26" max="399" required placeholder="Today's weight (kg)" value={w} onChange={(e) => setW(e.target.value)} style={{ maxWidth: 190 }} />
                <button className="btn">Log weight</button></form>
            </Card>
            {d.milestones && (
              <Card title="Goal milestones">
                <Bar label={`${num(d.milestones.current_kg, 1)} kg → ${num(d.milestones.target_kg, 1)} kg`} value={d.milestones.percent_complete} max={100} unit="%" />
                <div className="list">{d.milestones.milestones.map((x) => <div key={x.label} className="item"><span>{x.label} ({x.weight_kg} kg)</span><span className={"pill" + (x.reached ? "" : " warn")}>{x.reached ? "reached" : "ahead"}</span></div>)}</div>
              </Card>)}
          </div>
          <Card title="Body measurements">
            <form className="form" onSubmit={(e) => { e.preventDefault(); run(async () => {
              const body = { log_date: todayISO() }; Object.entries(m).forEach(([k, v]) => { if (v !== "") body[k] = +v; });
              await api("/progress/measurements", { method: "POST", body }); setM({ waist_cm: "", chest_cm: "", arm_cm: "", thigh_cm: "", body_fat_pct: "" }); }); }}>
              {Object.keys(m).map((k) => <Field key={k} label={k.replace("_cm", " (cm)").replace("_pct", " (%)").replace(/^\w/, (c) => c.toUpperCase())}><input type="number" step="0.1" value={m[k]} onChange={(e) => setM({ ...m, [k]: e.target.value })} /></Field>)}
              <button className="btn">Save</button>
            </form>
            {d.measurements.length > 0 && <table><thead><tr><th>Date</th><th className="num">Waist</th><th className="num">Chest</th><th className="num">Arm</th><th className="num">Thigh</th><th className="num">BF %</th></tr></thead>
              <tbody>{d.measurements.slice(-8).map((x) => <tr key={x.id}><td>{x.log_date}</td><td className="num">{num(x.waist_cm, 1)}</td><td className="num">{num(x.chest_cm, 1)}</td><td className="num">{num(x.arm_cm, 1)}</td><td className="num">{num(x.thigh_cm, 1)}</td><td className="num">{num(x.body_fat_pct, 1)}</td></tr>)}</tbody></table>}
          </Card>
          <Notice>Scale weight cannot tell muscle from fat. Look at trends over several weeks.</Notice>
        </>)}</Async>
    </>
  );
}
