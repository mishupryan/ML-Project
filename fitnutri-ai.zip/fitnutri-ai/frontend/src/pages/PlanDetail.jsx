import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, label, num, todayISO } from "../api.js";
import { Async, Card, ErrorMsg, Notice, useAsync } from "../ui.jsx";

export default function PlanDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const p = useAsync(() => api(`/meal-plans/${id}`), [id]);
  const [day, setDay] = useState(0);
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);
  const run = async (fn, ok) => { setErr(null); setMsg(null); try { await fn(); if (ok) setMsg(ok); p.reload(); } catch (e) { setErr(e); } };

  return (
    <Async state={p}>{(plan) => {
      const d = plan.days[Math.min(day, plan.days.length - 1)];
      return (
        <>
          <div className="page-h"><div><h1>{plan.name}</h1><p className="muted">{plan.plan_label} · target {num(plan.targets.calories)} kcal, {num(plan.targets.protein_g)} g protein</p></div>
            <div className="row">
              <button className="btn ghost" onClick={() => run(() => api(`/meal-plans/${id}`, { method: "PUT", body: { is_saved: !plan.is_saved } }), plan.is_saved ? "Unsaved." : "Saved.")}>{plan.is_saved ? "★ Saved" : "☆ Save"}</button>
              <button className="btn" onClick={async () => { try { const g = await api(`/grocery/from-plan/${id}`, { method: "POST", body: {} }); nav(`/grocery?list=${g.id}`); } catch (e) { setErr(e); } }}>Grocery list</button>
              <button className="btn danger" onClick={async () => { if (window.confirm("Delete this plan?")) { await api(`/meal-plans/${id}`, { method: "DELETE" }); nav("/plans"); } }}>Delete</button>
            </div></div>
          <ErrorMsg error={err} />{msg && <Notice>{msg}</Notice>}
          {plan.warnings?.map((w, i) => <Notice key={i} kind="warn">{w}</Notice>)}
          <div className="tabs">{plan.days.map((x, i) => <button key={i} className={"tab" + (i === day ? " on" : "")} onClick={() => setDay(i)}>Day {i + 1}</button>)}</div>
          <Card title={`Day ${d.day_index + 1} totals`}>
            <p><strong>{num(d.totals.calories)}</strong> kcal · {num(d.totals.protein_g)} g protein · {num(d.totals.carbs_g)} g carbs · {num(d.totals.fat_g)} g fat · ≈ ₹{num(d.cost_inr)}</p>
            <small>Fit vs target: calories {d.fit_pct.calories}%, protein {d.fit_pct.protein_g}%</small>
          </Card>
          <div className="grid g2">{d.meals.map((m) => (
            <Card key={m.id} title={`${label(m.slot)} · ${m.name}`} actions={<>
              <button className="btn ghost sm" onClick={() => run(() => api(`/meal-plans/${id}/regenerate-meal`, { method: "POST", body: { day_index: d.day_index, slot: m.slot } }), "Meal regenerated.")}>Regenerate</button>
              <button className="btn sm" onClick={() => run(() => api(`/meal-plans/${id}/meals/${m.id}/log`, { method: "POST", body: { log_date: todayISO() } }), "Logged to today’s diary.")}>Log</button></>}>
              <table><tbody>{m.items.map((it) => (
                <tr key={it.id}><td>{it.food_name}</td><td className="num">{it.display_qty}</td><td className="num">{num(it.nutrients.calories)} kcal</td><td className="num">{num(it.nutrients.protein_g, 1)} g P</td></tr>))}</tbody></table>
            </Card>))}</div>
        </>
      );
    }}</Async>
  );
}
