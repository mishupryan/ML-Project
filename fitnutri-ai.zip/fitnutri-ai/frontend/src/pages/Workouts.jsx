import { useState } from "react";
import { api, num, todayISO } from "../api.js";
import { Async, BarChart, Card, ErrorMsg, Field, Notice, useAsync } from "../ui.jsx";

const blank = () => ({ name: "", sets: "", reps: "", weight_kg: "" });

export default function Workouts() {
  const list = useAsync(() => api("/workouts", { params: { limit: 20 } }));
  const sum = useAsync(() => api("/workouts/summary", { params: { weeks: 8 } }));
  const [f, setF] = useState({ workout_type: "strength", duration_min: 60, perceived_exertion: 7, notes: "", workout_date: todayISO() });
  const [ex, setEx] = useState([blank()]);
  const [err, setErr] = useState(null);
  const refresh = () => { list.reload(); sum.reload(); };

  async function save(e) {
    e.preventDefault(); setErr(null);
    try {
      const exercises = ex.filter((x) => x.name.trim()).map((x) => ({ name: x.name.trim(), ...(x.sets && { sets: +x.sets }), ...(x.reps && { reps: +x.reps }), ...(x.weight_kg && { weight_kg: +x.weight_kg }) }));
      await api("/workouts", { method: "POST", body: { workout_type: f.workout_type, workout_date: f.workout_date, duration_min: +f.duration_min, perceived_exertion: +f.perceived_exertion, notes: f.notes || undefined, exercises } });
      setEx([blank()]); setF({ ...f, notes: "" }); refresh();
    } catch (x) { setErr(x); }
  }
  const upd = (i, k, v) => setEx(ex.map((x, j) => (j === i ? { ...x, [k]: v } : x)));

  return (
    <>
      <h1>Workouts</h1>
      <Async state={sum}>{(s) => (
        <Card title="Sessions per week"><BarChart items={s.weeks.map((w) => ({ label: w.week_start.slice(5), value: w.sessions }))} />
          <small>{s.note}</small></Card>)}</Async>
      <Card title="Log a workout">
        <form onSubmit={save} className="grid">
          <div className="form">
            <Field label="Date"><input type="date" value={f.workout_date} onChange={(e) => setF({ ...f, workout_date: e.target.value })} /></Field>
            <Field label="Type"><input required value={f.workout_type} onChange={(e) => setF({ ...f, workout_type: e.target.value })} /></Field>
            <Field label="Minutes"><input type="number" min="1" max="600" value={f.duration_min} onChange={(e) => setF({ ...f, duration_min: e.target.value })} /></Field>
            <Field label="Effort (1–10)"><input type="number" min="1" max="10" value={f.perceived_exertion} onChange={(e) => setF({ ...f, perceived_exertion: e.target.value })} /></Field>
          </div>
          {ex.map((x, i) => (
            <div className="form" key={i}>
              <Field label={i === 0 ? "Exercise" : " "}><input value={x.name} onChange={(e) => upd(i, "name", e.target.value)} placeholder="Squat" /></Field>
              <Field label={i === 0 ? "Sets" : " "}><input type="number" min="1" value={x.sets} onChange={(e) => upd(i, "sets", e.target.value)} /></Field>
              <Field label={i === 0 ? "Reps" : " "}><input type="number" min="1" value={x.reps} onChange={(e) => upd(i, "reps", e.target.value)} /></Field>
              <Field label={i === 0 ? "Weight (kg)" : " "}><input type="number" min="0" step="0.5" value={x.weight_kg} onChange={(e) => upd(i, "weight_kg", e.target.value)} /></Field>
            </div>))}
          <div className="row"><button type="button" className="btn ghost sm" onClick={() => setEx([...ex, blank()])}>+ exercise</button><button className="btn">Save workout</button></div>
          <ErrorMsg error={err} />
        </form>
      </Card>
      <Async state={list}>{(d) => (
        <Card title="Recent workouts">
          {!d.items.length && <p className="muted">No workouts yet.</p>}
          <div className="list">{d.items.map((w) => (
            <div key={w.id} className="item"><div><strong>{w.workout_date} · {w.workout_type}</strong> <small>{w.duration_min} min · effort {w.perceived_exertion ?? "–"} · volume {num(w.total_volume_kg)} kg</small><br />
              <small>{w.exercises.map((x) => `${x.name} ${x.sets ?? ""}×${x.reps ?? ""}${x.weight_kg != null ? " @ " + x.weight_kg + " kg" : ""}`).join(" · ")}</small></div>
              <button className="btn danger sm" aria-label="Delete workout" onClick={async () => { await api(`/workouts/${w.id}`, { method: "DELETE" }); refresh(); }}>✕</button></div>))}</div>
        </Card>)}</Async>
      <Notice>Training and nutrition are shown side by side; this does not show that one caused the other.</Notice>
    </>
  );
}
