import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { Async, Card, ErrorMsg, Field, Notice, csvList, useAsync } from "../ui.jsx";

export default function Plans() {
  const nav = useNavigate();
  const types = useAsync(() => api("/meal-plans/plan-types"));
  const list = useAsync(() => api("/meal-plans"));
  const [f, setF] = useState({ plan_type: "muscle_gain", days: 3, daily_budget_inr: "", diet: "", exclude: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function generate(e) {
    e.preventDefault(); setBusy(true); setErr(null);
    try {
      const body = { plan_type: f.plan_type, days: +f.days, exclude_foods: csvList(f.exclude) };
      if (f.daily_budget_inr) body.daily_budget_inr = +f.daily_budget_inr;
      if (f.diet) body.diet = f.diet;
      const p = await api("/meal-plans/generate", { method: "POST", body });
      nav(`/plans/${p.id}`);
    } catch (x) { setErr(x); setBusy(false); }
  }
  return (
    <>
      <h1>Meal plans</h1>
      <Card title="Generate a plan">
        <form className="form" onSubmit={generate}>
          <Field label="Plan type"><select value={f.plan_type} onChange={set("plan_type")}>
            {(types.data?.items || []).map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}</select></Field>
          <Field label="Days"><select value={f.days} onChange={set("days")}>{[1, 2, 3, 4, 5, 6, 7].map((d) => <option key={d}>{d}</option>)}</select></Field>
          <Field label="Diet (optional)"><select value={f.diet} onChange={set("diet")}><option value="">From my profile</option>
            {["vegan", "vegetarian", "eggetarian", "pescatarian", "non_vegetarian"].map((d) => <option key={d}>{d}</option>)}</select></Field>
          <Field label="Budget ₹/day (optional)"><input type="number" min="0" value={f.daily_budget_inr} onChange={set("daily_budget_inr")} /></Field>
          <Field label="Exclude foods (comma separated)"><input value={f.exclude} onChange={set("exclude")} placeholder="e.g. tofu, oats" /></Field>
          <button className="btn" disabled={busy}>{busy ? "Generating…" : "Generate plan"}</button>
        </form>
        <ErrorMsg error={err} />
        <Notice>Plans use your profile's targets, diet, allergies and budget. Complete your profile first for best results.</Notice>
      </Card>
      <Async state={list}>{(d) => (
        <Card title="Your plans">
          {!d.items.length && <p className="muted">No plans yet.</p>}
          <div className="list">{d.items.map((p) => (
            <div key={p.id} className="item"><div><Link to={`/plans/${p.id}`}><strong>{p.name}</strong></Link> {p.is_saved && <span className="pill">saved</span>}<br />
              <small>{p.plan_label} · {p.num_days} day(s) · ≈ ₹{Math.round(p.total_cost_inr || 0)}</small></div></div>))}</div>
        </Card>)}</Async>
    </>
  );
}
