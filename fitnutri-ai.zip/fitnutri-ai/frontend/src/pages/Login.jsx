import { useState } from "react";
import { api } from "../api.js";
import { ErrorMsg, Field } from "../ui.jsx";

export default function Login({ onAuth }) {
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ email: "", password: "", display_name: "" });
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr(null);
    try {
      const body = mode === "login" ? { email: f.email, password: f.password } : f;
      onAuth(await api(`/auth/${mode === "login" ? "login" : "register"}`, { method: "POST", body }));
    } catch (x) { setErr(x); } finally { setBusy(false); }
  }
  return (
    <div className="auth">
      <div><h1 style={{ color: "var(--accent)" }}>FitNutri AI</h1><p className="muted">Diet tracker and nutrition planner for building muscle, losing fat or eating better.</p></div>
      <form className="card" onSubmit={submit}>
        <h2>{mode === "login" ? "Log in" : "Create your account"}</h2>
        {mode === "register" && <Field label="Name"><input required value={f.display_name} onChange={set("display_name")} autoComplete="name" /></Field>}
        <Field label="Email"><input required type="email" value={f.email} onChange={set("email")} autoComplete="email" /></Field>
        <Field label="Password" hint={mode === "register" ? "8–72 characters" : null}>
          <input required type="password" minLength={mode === "register" ? 8 : undefined} maxLength={72} value={f.password} onChange={set("password")} autoComplete={mode === "login" ? "current-password" : "new-password"} />
        </Field>
        <ErrorMsg error={err} />
        <button className="btn" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Log in" : "Sign up"}</button>
        <button type="button" className="btn ghost" onClick={() => { setMode(mode === "login" ? "register" : "login"); setErr(null); }}>
          {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
        </button>
      </form>
    </div>
  );
}
