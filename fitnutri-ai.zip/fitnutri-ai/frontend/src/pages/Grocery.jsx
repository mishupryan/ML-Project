import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api, download, num } from "../api.js";
import { Async, Card, ErrorMsg, Field, useAsync } from "../ui.jsx";

export default function Grocery() {
  const [sp, setSp] = useSearchParams();
  const lists = useAsync(() => api("/grocery"));
  const [sel, setSel] = useState(sp.get("list"));
  const [err, setErr] = useState(null);
  const [item, setItem] = useState({ name: "", quantity_g: "" });
  useEffect(() => { if (!sel && lists.data?.items?.length) setSel(String(lists.data.items[0].id)); }, [lists.data, sel]);
  const cur = useAsync(() => (sel ? api(`/grocery/${sel}`) : Promise.resolve({ empty: true })), [sel]);
  const run = async (fn) => { setErr(null); try { await fn(); cur.reload(); } catch (e) { setErr(e); } };

  return (
    <>
      <h1>Grocery lists</h1>
      <ErrorMsg error={err} />
      <Async state={lists}>{(d) => (!d.items.length ? <Card><p className="muted">No lists yet. Open a meal plan and choose “Grocery list”.</p></Card> : (
        <div className="tabs">{d.items.map((l) => <button key={l.id} className={"tab" + (String(l.id) === sel ? " on" : "")} onClick={() => { setSel(String(l.id)); setSp({ list: l.id }); }}>{l.name}</button>)}</div>))}</Async>
      {sel && <Async state={cur}>{(g) => g.empty ? null : (
        <Card title={g.name} actions={<>
          <button className="btn ghost sm" onClick={() => download(`/grocery/${g.id}/export.csv`, `grocery-${g.id}.csv`).catch(setErr)}>Export CSV</button>
          <button className="btn danger sm" onClick={async () => { if (window.confirm("Delete this list?")) { await api(`/grocery/${g.id}`, { method: "DELETE" }); setSel(null); setSp({}); lists.reload(); } }}>Delete</button></>}>
          <div className="list">{g.items.map((i) => (
            <label key={i.id} className="item" style={{ cursor: "pointer" }}>
              <span className="row"><input type="checkbox" checked={i.purchased} onChange={() => run(() => api(`/grocery/${g.id}/items/${i.id}`, { method: "PATCH", body: { purchased: !i.purchased } }))} />
                <span style={{ textDecoration: i.purchased ? "line-through" : "none" }}>{i.name} <small>{i.display_qty}</small></span></span>
              <small>≈ ₹{num(i.est_cost_inr)}</small>
            </label>))}</div>
          <p className="muted">Estimated total ≈ ₹{num(g.items.reduce((s, i) => s + (i.est_cost_inr || 0), 0))} (illustrative prices)</p>
          <form className="form" onSubmit={(e) => { e.preventDefault(); run(async () => { await api(`/grocery/${g.id}/items`, { method: "POST", body: { name: item.name, quantity_g: +item.quantity_g } }); setItem({ name: "", quantity_g: "" }); }); }}>
            <Field label="Add item"><input required value={item.name} onChange={(e) => setItem({ ...item, name: e.target.value })} /></Field>
            <Field label="Grams"><input required type="number" min="1" value={item.quantity_g} onChange={(e) => setItem({ ...item, quantity_g: e.target.value })} /></Field>
            <button className="btn">Add</button>
          </form>
        </Card>)}</Async>}
    </>
  );
}
