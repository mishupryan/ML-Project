import { useState } from "react";
import { Link } from "react-router-dom";
import { api, label, num } from "../api.js";
import { useAuth } from "../App.jsx";
import { Async, Bar, Card, ErrorMsg, Notice, useAsync } from "../ui.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const s = useAsync(() => api("/nutrition/daily-summary"));
  const [err, setErr] = useState(null);
  const addWater = async (ml) => { try { await api("/water-logs", { method: "POST", body: { amount_ml: ml } }); s.reload(); } catch (e) { setErr(e); } };

  return (
    <>
      <div className="page-h"><h1>Hi, {user.display_name.split(" ")[0]}</h1><Link className="btn" to="/diary">Log food</Link></div>
      <Async state={s}>{(d) => (
        <>
          {!d.targets && <Notice>Add your age, height, weight and goal in your <Link to="/profile">profile</Link> to get calorie and protein targets.</Notice>}
          <div className="grid g2">
            <Card title={`Today · ${d.date}`}>
              {d.targets ? <>
                <Bar label="Calories" value={d.consumed.calories} max={d.targets.calories} unit=" kcal" />
                <Bar label="Protein" value={d.consumed.protein_g} max={d.targets.protein_g} unit=" g" />
                <Bar label="Carbs" value={d.consumed.carbs_g} max={d.targets.carbs_g} unit=" g" />
                <Bar label="Fat" value={d.consumed.fat_g} max={d.targets.fat_g} unit=" g" />
                <Bar label="Fibre" value={d.consumed.fiber_g} max={d.targets.fiber_g} unit=" g" />
              </> : <p><strong>{num(d.consumed.calories)}</strong> kcal · {num(d.consumed.protein_g, 1)} g protein · {num(d.consumed.carbs_g, 1)} g carbs · {num(d.consumed.fat_g, 1)} g fat</p>}
              {!d.entries_count && <p className="muted">Nothing logged yet today. Unlogged is not the same as zero.</p>}
            </Card>
            <div className="grid">
              <Card title="Water">
                <Bar label="Water" value={d.water_ml} max={d.water_target_ml || 2500} unit=" ml" />
                <div className="row">{[250, 500, 750].map((ml) => <button key={ml} className="btn ghost sm" onClick={() => addWater(ml)}>+{ml} ml</button>)}</div>
                <ErrorMsg error={err} />
              </Card>
              <Card title="This week">
                <p>Logged <strong>{d.weekly_consistency?.days_logged_last_7 ?? 0}</strong> of the last 7 days; <strong>{d.weekly_consistency?.days_within_10pct_of_calorie_target ?? 0}</strong> within 10% of your calorie target.</p>
                {d.weight_trend && <p className="muted">Latest weight {num(d.weight_trend.latest_kg, 1)} kg ({d.weight_trend.change_kg_over_7d_or_more >= 0 ? "+" : ""}{num(d.weight_trend.change_kg_over_7d_or_more, 1)} kg). {d.weight_trend.note}</p>}
              </Card>
            </div>
          </div>
          {d.next_meal?.remaining && (
            <Card title={`Next up: ${label(d.next_meal.slot)}`}>
              <p className="muted">{label(d.next_meal.reason)}. Remaining: {num(d.next_meal.remaining.calories)} kcal, {num(d.next_meal.remaining.protein_g)} g protein.</p>
              <div className="list">{(d.next_meal.suggestions || []).slice(0, 3).map((x, i) => (
                <div key={i}><strong>{x.name}</strong> <span className="pill">{x.display_qty}</span><br /><small>{x.explanation}</small></div>
              ))}</div>
            </Card>
          )}
        </>
      )}</Async>
    </>
  );
}
