import { createContext, useContext, useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { api, token } from "./api.js";
import { Spinner } from "./ui.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Diary from "./pages/Diary.jsx";
import Foods from "./pages/Foods.jsx";
import Plans from "./pages/Plans.jsx";
import PlanDetail from "./pages/PlanDetail.jsx";
import Grocery from "./pages/Grocery.jsx";
import Progress from "./pages/Progress.jsx";
import Workouts from "./pages/Workouts.jsx";
import Insights from "./pages/Insights.jsx";
import Profile from "./pages/Profile.jsx";

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

const NAV = [["/", "Today"], ["/diary", "Diary"], ["/foods", "Foods"], ["/plans", "Meal plans"], ["/grocery", "Grocery"],
  ["/progress", "Progress"], ["/workouts", "Workouts"], ["/insights", "Insights"], ["/profile", "Profile"]];

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(!token.get());
  const nav = useNavigate();

  useEffect(() => {
    if (token.get()) api("/auth/me").then(setUser).catch(() => token.clear()).finally(() => setReady(true));
    const out = () => { setUser(null); nav("/login"); };
    window.addEventListener("fn:logout", out);
    return () => window.removeEventListener("fn:logout", out);
    // eslint-disable-next-line
  }, []);

  const login = (res) => { token.set(res.access_token); setUser(res.user); nav("/"); };
  const logout = async () => { try { await api("/auth/logout", { method: "POST" }); } catch { /* ignore */ } token.clear(); setUser(null); nav("/login"); };

  if (!ready) return <Spinner />;
  if (!user) return (
    <Routes>
      <Route path="/login" element={<Login onAuth={login} />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
  return (
    <AuthCtx.Provider value={{ user, logout }}>
      <header className="topbar"><div className="topbar-in">
        <NavLink to="/" className="brand">FitNutri AI</NavLink>
        <nav className="nav" aria-label="Main">{NAV.map(([to, t]) => <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => (isActive ? "active" : "")}>{t}</NavLink>)}</nav>
        <button className="btn ghost sm" onClick={logout}>Log out</button>
      </div></header>
      <main className="shell page">
        {user.is_demo && <div className="alert warn">You are using the demo account. Its data is synthetic sample data.</div>}
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/diary" element={<Diary />} />
          <Route path="/foods" element={<Foods />} />
          <Route path="/plans" element={<Plans />} />
          <Route path="/plans/:id" element={<PlanDetail />} />
          <Route path="/grocery" element={<Grocery />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/workouts" element={<Workouts />} />
          <Route path="/insights" element={<Insights />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <p className="footer">Nutrition numbers are estimates, not medical advice. Food values are approximate and prices are illustrative.</p>
      </main>
    </AuthCtx.Provider>
  );
}
