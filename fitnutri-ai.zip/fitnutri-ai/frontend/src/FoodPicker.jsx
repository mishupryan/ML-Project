import { useEffect, useState } from "react";
import { api, label, num, todayISO } from "./api.js";
import { ErrorMsg, Field, Modal, Notice } from "./ui.jsx";

export const MEALS = ["breakfast", "mid_morning_snack", "lunch", "evening_snack", "pre_workout", "post_workout", "dinner", "custom"];

/** Search foods, choose quantity + meal, and log to the diary. */
export default function FoodPicker({ onClose, onLogged, date, defaultMeal = "breakfast", preselected = null }) {
  const [q, setQ] = useState("");
  const [items, setItems] = useState([]);
  const [unverified, setUnverified] = useState(false);
  const [food, setFood] = useState(preselected);
  const [grams, setGrams] = useState(100);
  const [meal, setMeal] = useState(defaultMeal);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (food) return;
    const t = setTimeout(() => api("/foods", { params: { q, limit: 15, include_unverified: unverified, sort: "relevance" } }).then((r) => setItems(r.items)).catch(setErr), 250);
    return () => clearTimeout(t);
  }, [q, unverified, food]);

  useEffect(() => { if (food?.serving_g) setGrams(Math.round(food.serving_g)); }, [food]);

  async function log() {
    setBusy(true); setErr(null);
    try {
      await api("/diary", { method: "POST", body: { food_id: food.id, quantity_g: +grams, meal_type: meal, log_date: date || todayISO() } });
      onLogged?.(); onClose();
    } catch (e) { setErr(e); } finally { setBusy(false); }
  }
  const p = food?.per_100g;
  const k = (+grams || 0) / 100;
  return (
    <Modal title={food ? "Log " + food.name : "Add food"} onClose={onClose}>
      {!food ? (
        <>
          <input autoFocus placeholder="Search foods (e.g. paneer, oats, chicken)…" value={q} onChange={(e) => setQ(e.target.value)} />
          <label className="row"><input type="checkbox" checked={unverified} onChange={(e) => setUnverified(e.target.checked)} /> Include imported, unverified records</label>
          <ErrorMsg error={err} />
          <div className="list">
            {items.map((f) => (
              <div key={f.id} className="item">
                <div><strong>{f.name}</strong> <small>{f.serving_desc}</small><br /><small>{num(f.per_100g.calories)} kcal · {num(f.per_100g.protein_g, 1)} g protein per 100 g</small></div>
                <button className="btn sm" onClick={() => setFood(f)}>Select</button>
              </div>
            ))}
            {!items.length && <p className="muted">No foods found.</p>}
          </div>
        </>
      ) : (
        <>
          {food.data_confidence === "imported-unverified" && <Notice kind="warn">Imported record: allergens and diet type are unverified. Check the label.</Notice>}
          <div className="form">
            <Field label="Quantity (grams)"><input type="number" min="1" max="10000" value={grams} onChange={(e) => setGrams(e.target.value)} /></Field>
            <Field label="Meal"><select value={meal} onChange={(e) => setMeal(e.target.value)}>{MEALS.map((m) => <option key={m} value={m}>{label(m)}</option>)}</select></Field>
          </div>
          {p && <p className="muted">{num(p.calories * k)} kcal · {num((p.protein_g ?? 0) * k, 1)} g protein · {num((p.carbs_g ?? 0) * k, 1)} g carbs · {num((p.fat_g ?? 0) * k, 1)} g fat</p>}
          <ErrorMsg error={err} />
          <div className="row"><button className="btn" disabled={busy || !(+grams > 0)} onClick={log}>Add to diary</button>
            {!preselected && <button className="btn ghost" onClick={() => setFood(null)}>Back</button>}</div>
        </>
      )}
    </Modal>
  );
}
